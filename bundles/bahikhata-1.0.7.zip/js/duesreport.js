// Receivables (money customers owe you) and payables (money you owe), with ageing, as a list, PDF or Excel.

const AGE_BUCKETS = [['0–30 days', 0, 30], ['31–60 days', 31, 60], ['61–90 days', 61, 90], ['90+ days', 91, Infinity]];

// Splits what a party owes (or is owed) by how old each unpaid entry is, paying off the oldest first
function partyAgeing(pid, side) {
  const bal = partyBalance(pid);
  const owed = side === 'receivable' ? Math.max(bal, 0) : Math.max(-bal, 0);
  const debitKind = side === 'receivable' ? 'gave' : 'got';
  const queue = [];
  let pool = 0, lastPay = null;
  for (const t of partyTxns(pid)) {
    if (t.kind === debitKind) {
      let amt = t.amount;
      const use = Math.min(pool, amt);
      pool -= use; amt -= use;
      if (amt > 0.001) queue.push({ left: amt, date: t.date });
    } else {
      lastPay = t.date;
      let amt = t.amount;
      while (amt > 0.001 && queue.length) {
        const g = queue[0];
        const use = Math.min(g.left, amt);
        g.left -= use; amt -= use;
        if (g.left <= 0.001) queue.shift();
      }
      pool += amt;
    }
  }
  const buckets = [0, 0, 0, 0];
  let left = owed, oldest = null;
  // newest first, so any rounding difference with the balance lands on the oldest entries
  for (const g of queue.slice().reverse()) {
    if (left <= 0.001) break;
    const use = Math.min(g.left, left);
    const age = Math.max(0, daysBetween(g.date, today()));
    buckets[AGE_BUCKETS.findIndex(([, lo, hi]) => age >= lo && age <= hi)] += use;
    left -= use;
    oldest = age;
  }
  if (left > 0.01) buckets[0] += left;
  return { owed: r2(owed), buckets: buckets.map(r2), oldest, lastPay };
}

function duesRows(side) {
  return DB.data.parties.map((p) => {
    const bal = partyBalance(p.id);
    if (side === 'receivable' ? bal <= 0 : bal >= 0) return null;
    return Object.assign({ party: p }, partyAgeing(p.id, side));
  }).filter(Boolean).sort((a, b) => b.owed - a.owed);
}
function duesTotals() {
  const rec = duesRows('receivable'), pay = duesRows('payable');
  const sum = (rows) => r2(rows.reduce((a, r) => a + r.owed, 0));
  return { rec, pay, recTotal: sum(rec), payTotal: sum(pay) };
}

function duesCard() {
  const t = duesTotals();
  return '<div class="card stack"><div class="sh-grid">' +
    '<button class="dues-mini" data-act="dues" data-v="receivable"><span class="label">Receivable</span><span class="sh-v pos">' + money(t.recTotal) + '</span><span class="small muted">' + t.rec.length + ' parties ›</span></button>' +
    '<button class="dues-mini" data-act="dues" data-v="payable"><span class="label">Payable</span><span class="sh-v neg">' + money(t.payTotal) + '</span><span class="small muted">' + t.pay.length + ' parties ›</span></button></div></div>';
}

function duesSheet() {
  const side = UI.duesSide === 'payable' ? 'payable' : 'receivable';
  const t = duesTotals();
  const rows = side === 'receivable' ? t.rec : t.pay;
  const total = side === 'receivable' ? t.recTotal : t.payTotal;
  const buckets = [0, 1, 2, 3].map((i) => r2(rows.reduce((a, r) => a + r.buckets[i], 0)));
  const maxB = Math.max(1, ...buckets);
  const net = r2(t.recTotal - t.payTotal);
  return {
    title: 'Receivables & payables',
    body:
      '<div class="tiles three"><div class="tile"><span class="label">Receivable</span><span class="v pos">' + money(t.recTotal) + '</span><span class="small muted">' + t.rec.length + ' parties</span></div>' +
      '<div class="tile"><span class="label">Payable</span><span class="v neg">' + money(t.payTotal) + '</span><span class="small muted">' + t.pay.length + ' parties</span></div>' +
      '<div class="tile"><span class="label">Net</span><span class="v ' + (net >= 0 ? 'pos' : 'neg') + '">' + money(net, true) + '</span><span class="small muted">' + (net >= 0 ? 'to receive' : 'to pay') + '</span></div></div>' +
      '<div class="seg"><button class="' + (side === 'receivable' ? 'on' : '') + '" data-act="dues-side" data-v="receivable">Receivable (' + t.rec.length + ')</button>' +
      '<button class="' + (side === 'payable' ? 'on' : '') + '" data-act="dues-side" data-v="payable">Payable (' + t.pay.length + ')</button></div>' +
      '<div class="card stack"><span class="label">' + (side === 'receivable' ? 'How old the money owed to you is' : 'How old the money you owe is') + '</span>' +
      AGE_BUCKETS.map(([l], i) => '<div class="bar-row"><span>' + l + '</span><span class="track"><span class="fill' + (i >= 2 ? ' late' : '') + '" style="display:block;width:' + Math.max(buckets[i] ? 3 : 0, (buckets[i] / maxB) * 100) + '%"></span></span><span class="num">' + money(buckets[i]) + '</span></div>').join('') + '</div>' +
      '<div class="table-wrap card" style="padding:0"><table class="sr-table"><thead><tr><th>Party</th><th class="r">' + (side === 'receivable' ? 'To receive' : 'To pay') + '</th><th class="r">Oldest</th><th class="r">Last paid</th></tr></thead><tbody>' +
      (rows.length ? rows.map((r) => '<tr data-act="open-party" data-id="' + r.party.id + '"><td><b>' + esc(r.party.name) + '</b><br><span class="small muted">' + (r.party.type === 'supplier' ? 'Supplier' : 'Customer') + (r.party.phone ? ' · ' + esc(r.party.phone) : '') + '</span></td>' +
        '<td class="r"><b class="' + (side === 'receivable' ? 'pos' : 'neg') + '">' + money(r.owed) + '</b></td>' +
        '<td class="r' + (r.oldest > 60 ? ' neg' : '') + '">' + (r.oldest == null ? '—' : r.oldest + ' d') + '</td><td class="r small">' + (r.lastPay ? fmtDateShort(r.lastPay) : 'never') + '</td></tr>').join('')
        : '<tr><td colspan="4" class="empty">' + (side === 'receivable' ? 'Nobody owes you money.' : 'You don\'t owe anyone.') + '</td></tr>') +
      '</tbody><tfoot><tr><td><b>Total (' + rows.length + ')</b></td><td class="r"><b>' + money(total) + '</b></td><td></td><td></td></tr></tfoot></table></div>' +
      '<p class="small muted">Oldest = days since the oldest unpaid entry. Tap a party to open its ledger.' + (side === 'payable' ? ' Payable includes customers who paid you in advance.' : '') + '</p>' +
      '<div class="inv-actions"><button class="btn wa" data-act="dues-pdf">' + ic('send') + 'Share PDF</button><button class="btn" data-act="dues-csv">' + ic('file') + 'Excel (CSV)</button></div>' +
      (side === 'receivable' && rows.length ? '<button class="btn block" data-act="reminders">' + ic('bell') + 'Send payment reminders</button>' : ''),
  };
}

function duesHtml() {
  const s = DB.data.settings;
  const side = UI.duesSide === 'payable' ? 'payable' : 'receivable';
  const t = duesTotals();
  const rows = side === 'receivable' ? t.rec : t.pay;
  const total = side === 'receivable' ? t.recTotal : t.payTotal;
  return '<div class="iv-doc">' +
    '<div class="iv-top"><div><div class="iv-shop">' + esc(s.shopName) + '</div><div class="iv-sub">' + esc([s.city, STATES[s.stateCode]].filter(Boolean).join(', ')) + (s.phone ? ' · +91 ' + esc(s.phone) : '') + '</div></div>' +
    '<div class="iv-title"><div>' + (side === 'receivable' ? 'RECEIVABLES' : 'PAYABLES') + '</div><span class="iv-sub">As on ' + fmtDate(today()) + '</span></div></div>' +
    '<div class="iv-meta"><div><div class="iv-lbl">Total receivable</div><div class="iv-to" style="color:#146c43">' + money(t.recTotal) + '</div><div class="iv-sub">' + t.rec.length + ' parties</div></div>' +
    '<div class="iv-right"><div class="iv-lbl">Total payable</div><div class="iv-to" style="color:#b42318">' + money(t.payTotal) + '</div><div class="iv-sub">' + t.pay.length + ' parties</div></div></div>' +
    '<table class="iv-table"><thead><tr><th>#</th><th>Party</th><th>Mobile</th>' + AGE_BUCKETS.map(([l]) => '<th class="r">' + l + '</th>').join('') + '<th class="r">Total</th></tr></thead><tbody>' +
    rows.map((r, i) => '<tr><td>' + (i + 1) + '</td><td class="iv-name">' + esc(r.party.name) + '</td><td>' + esc(r.party.phone || '') + '</td>' +
      r.buckets.map((b) => '<td class="r">' + (b ? money(b) : '—') + '</td>').join('') + '<td class="r"><b>' + money(r.owed) + '</b></td></tr>').join('') +
    '</tbody></table>' +
    '<div class="iv-bottom"><div class="iv-words"><div class="iv-lbl">Ageing</div><div>Amounts are split by how old each unpaid entry is, oldest paid off first.</div></div>' +
    '<div class="iv-totals">' + AGE_BUCKETS.map(([l], i) => '<div><span>' + l + '</span><span>' + money(r2(rows.reduce((a, r) => a + r.buckets[i], 0))) + '</span></div>').join('') +
    '<div class="iv-grand"><span>Total ' + side + '</span><span>' + money(total) + '</span></div></div></div>' +
    '<div class="iv-brand">Made with BahiKhata+</div></div>';
}
function duesCsv() {
  const side = UI.duesSide === 'payable' ? 'payable' : 'receivable';
  const rows = duesTotals()[side === 'receivable' ? 'rec' : 'pay'];
  return toCSV([['Party', 'Type', 'Mobile', 'GSTIN'].concat(AGE_BUCKETS.map(([l]) => l), ['Total ' + side, 'Oldest (days)', 'Last payment'])]
    .concat(rows.map((r) => [r.party.name, r.party.type, r.party.phone || '', r.party.gstin || ''].concat(r.buckets, [r.owed, r.oldest == null ? '' : r.oldest, r.lastPay || '']))));
}
async function shareDuesPdf() {
  const side = UI.duesSide === 'payable' ? 'payable' : 'receivable';
  const blob = await makeDocPdf(duesHtml(), side === 'receivable' ? 'Receivables' : 'Payables');
  const file = new File([blob], (side === 'receivable' ? 'Receivables_' : 'Payables_') + today() + '.pdf', { type: 'application/pdf' });
  return shareOrDownload([file], (side === 'receivable' ? 'Receivables' : 'Payables') + ' · ' + DB.data.settings.shopName);
}

// Onboarding (splash, intro slides, business type, details, PIN) and the PIN login screen.

const LOGO_SVG =
  '<svg class="logo-mark" viewBox="0 0 120 120" aria-hidden="true">' +
  '<rect class="lm-bg" x="4" y="4" width="112" height="112" rx="30"/>' +
  '<rect class="lm-page" x="32" y="26" width="58" height="70" rx="8"/>' +
  '<rect class="lm-spine" x="32" y="26" width="12" height="70" rx="4"/>' +
  '<path class="lm-line l1" d="M52 44h28"/><path class="lm-line l2" d="M52 57h28"/><path class="lm-line l3" d="M52 70h18"/>' +
  '<g class="lm-plus"><circle cx="90" cy="88" r="15"/><path d="M90 81v14M83 88h14"/></g>' +
  '</svg>';

const INTRO_SLIDES = [
  {
    title: 'Every rupee, on record',
    text: 'Write credit and payments in seconds, or just say it: "Gave 500 to Ramesh".',
    art: '<div class="art art-ledger"><div class="al-row"><span>Ramesh</span><b class="neg">₹500</b></div><div class="al-row"><span>Sunita</span><b class="pos">₹1,200</b></div><div class="al-row"><span>Vikas</span><b class="neg">₹4,700</b></div></div>',
  },
  {
    title: 'Get paid on time',
    text: 'Smart reminders learn when each customer usually pays and tell you the best time to ask.',
    art: '<div class="art art-remind"><div class="ar-bubble">Hello Vikas, ₹4,700 is due. Pay by UPI.</div><div class="ar-bubble me">Paid ✓</div></div>',
  },
  {
    title: 'Stock, bills, profit, GST',
    text: 'Low-stock and expiry alerts, GST bills, daily profit and GST reports for your CA.',
    art: '<div class="art art-chart"><span style="--h:40%"></span><span style="--h:65%"></span><span style="--h:52%"></span><span style="--h:80%"></span><span style="--h:94%"></span></div>',
  },
];

const OB = { step: 'splash', slide: 0, timer: null, data: {}, pin: '', pin1: '', mode: 'setup' };

function authRoot() { return document.getElementById('auth-root'); }
function showAuth(html, cls) {
  const r = authRoot();
  r.className = 'auth ' + (cls || '');
  r.innerHTML = html;
  r.hidden = false;
  document.body.style.overflow = 'hidden';
}
function hideAuth(animated) {
  const r = authRoot();
  const done = () => { r.hidden = true; r.innerHTML = ''; r.className = 'auth'; document.body.style.overflow = ''; };
  if (animated && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
    r.classList.add('leaving');
    setTimeout(done, 650);
  } else done();
}
function progress(n) {
  const total = Cloud.available() ? 5 : 4;
  if (n > total) n = total;
  const dots = Array.from({ length: total }, (_, i) => i + 1);
  return '<div class="ob-progress" style="grid-template-columns:repeat(' + total + ',1fr)" aria-label="Step ' + n + ' of ' + total + '">' + dots.map((i) => '<span class="' + (i <= n ? 'on' : '') + '"></span>').join('') + '</div>';
}
function afterPinStep() { obGo(Cloud.available() ? 'cloud' : 'done'); }

/* ---------- Splash ---------- */
function startOnboarding() {
  showAuth('<div class="splash">' + LOGO_SVG +
    '<h1 class="wordmark">' + 'BahiKhata'.split('').map((c, i) => '<span style="--i:' + i + '">' + c + '</span>').join('') + '<span class="wm-plus" style="--i:9">+</span></h1>' +
    '<p class="tagline">The digital bahi-khata for every shop</p></div>', 'dark');
  setTimeout(() => obGo('welcome'), matchMedia('(prefers-reduced-motion: reduce)').matches ? 300 : 2300);
}

function obGo(step) {
  OB.step = step;
  clearInterval(OB.timer);
  const screens = { welcome: obWelcome, type: obType, details: obDetails, pin: obPin, cloud: obCloud, done: obDone };
  screens[step]();
}

/* ---------- Intro slides ---------- */
function obWelcome() {
  showAuth('<div class="ob welcome-screen"><div class="ob-top">' + LOGO_SVG.replace('logo-mark', 'logo-mark small still') + '<b>BahiKhata+</b></div>' +
    '<div class="slides" id="ob-slides">' + INTRO_SLIDES.map((s, i) =>
      '<section class="slide" aria-hidden="' + (i !== OB.slide) + '"><div class="slide-art">' + s.art + '</div><h2>' + s.title + '</h2><p>' + s.text + '</p></section>').join('') + '</div>' +
    '<div class="dots">' + INTRO_SLIDES.map((s, i) => '<button data-ob="slide" data-i="' + i + '" aria-label="Slide ' + (i + 1) + '"></button>').join('') + '</div>' +
    '<div class="ob-actions"><button class="btn primary block big" data-ob="to-type">Get started</button>' +
    '<label class="btn block">Restore from backup file<input type="file" accept=".json,application/json" id="ob-restore" hidden></label></div>' +
    '<p class="small muted center">Free. Works offline. Optional daily cloud backup.</p></div>');
  setSlide(OB.slide);
  OB.timer = setInterval(() => setSlide((OB.slide + 1) % INTRO_SLIDES.length), 3800);
  swipe(document.getElementById('ob-slides'), (dir) => { clearInterval(OB.timer); setSlide((OB.slide + dir + INTRO_SLIDES.length) % INTRO_SLIDES.length); });
}
function setSlide(i) {
  OB.slide = i;
  const box = document.getElementById('ob-slides');
  if (!box) return;
  box.style.setProperty('--slide', i);
  box.querySelectorAll('.slide').forEach((s, k) => { s.classList.toggle('on', k === i); s.setAttribute('aria-hidden', k !== i); });
  document.querySelectorAll('.dots button').forEach((d, k) => d.classList.toggle('on', k === i));
}
function swipe(el, cb) {
  let x0 = null;
  el.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
  el.addEventListener('touchend', (e) => {
    if (x0 == null) return;
    const dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 40) cb(dx < 0 ? 1 : -1);
    x0 = null;
  });
}

/* ---------- Business type ---------- */
function obType() {
  const sel = OB.data.businessType;
  showAuth('<div class="ob">' + progress(1) +
    '<div class="ob-head"><h2>What kind of business do you run?</h2><p class="muted">We\'ll set up categories, units and GST to match. You can change it later.</p></div>' +
    '<div class="type-grid">' + BUSINESS_TYPES.map((t, i) =>
      '<button class="type-card' + (sel === t.id ? ' on' : '') + '" style="--i:' + i + '" data-ob="type" data-id="' + t.id + '"><span class="tc-icon">' + typeIcon(t.id) + '</span><span>' + esc(t.label) + '</span></button>').join('') + '</div>' +
    '<div class="ob-actions sticky"><button class="btn primary block big" data-ob="to-details"' + (sel ? '' : ' disabled') + '>Continue</button></div></div>');
}

/* ---------- Business details ---------- */
function obDetails() {
  const d = OB.data;
  const t = BUSINESS_TYPES.find((x) => x.id === d.businessType);
  const stateOpts = '<option value="">Choose state</option>' + Object.entries(STATES).map(([c, n]) => '<option value="' + c + '"' + (d.stateCode === c ? ' selected' : '') + '>' + n + '</option>').join('');
  showAuth('<div class="ob">' + progress(2) +
    '<div class="ob-head"><span class="chip new">' + typeIcon(t.id, 14) + ' ' + esc(t.label) + '</span><h2>Tell us about your business</h2><p class="muted">This appears on bills and reminders.</p></div>' +
    '<form class="stack ob-form" id="ob-form">' +
    '<label class="field" style="--i:0"><span>Business name</span><input name="shopName" required autocomplete="organization" value="' + esc(d.shopName || '') + '" placeholder="e.g. Sharma General Store"></label>' +
    '<label class="field" style="--i:1"><span>Your name</span><input name="ownerName" required autocomplete="name" value="' + esc(d.ownerName || '') + '"></label>' +
    '<label class="field" style="--i:2"><span>Mobile number</span><input name="phone" type="tel" inputmode="tel" required value="' + esc(d.phone || '') + '" placeholder="10 digits"></label>' +
    '<div class="fields" style="--i:3"><label class="field"><span>City</span><input name="city" value="' + esc(d.city || '') + '"></label>' +
    '<label class="field"><span>State</span><select name="stateCode" required>' + stateOpts + '</select></label></div>' +
    '<label class="check" style="--i:4"><input type="checkbox" name="hasGst" id="ob-hasgst"' + (d.gstin ? ' checked' : '') + '>I am GST registered</label>' +
    '<label class="field" id="ob-gst-field" style="--i:5"' + (d.gstin ? '' : ' hidden') + '><span>GSTIN</span><input name="gstin" maxlength="15" style="text-transform:uppercase" value="' + esc(d.gstin || '') + '"></label>' +
    '<label class="field" style="--i:6"><span>UPI ID (optional, for payment links)</span><input name="upi" value="' + esc(d.upi || '') + '" placeholder="yourname@upi"></label>' +
    '<div class="ob-actions sticky"><button class="btn primary block big" type="submit">Continue</button><button class="btn block" type="button" data-ob="back-type">Back</button></div></form></div>');
}

/* ---------- PIN (setup, change and login) ---------- */
function pinPad(title, sub, extra) {
  return '<div class="pin-screen"><div class="pin-head">' + LOGO_SVG.replace('logo-mark', 'logo-mark small breathe') + '<h2>' + title + '</h2><p class="muted" id="pin-sub">' + sub + '</p></div>' +
    '<div class="pin-dots" id="pin-dots">' + [0, 1, 2, 3].map(() => '<span></span>').join('') + '</div>' +
    '<div class="pin-pad">' + [1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => '<button data-pin="' + n + '">' + n + '</button>').join('') +
    '<span></span><button data-pin="0">0</button><button data-pin="del" aria-label="Delete">⌫</button></div>' + (extra || '') + '</div>';
}
function obPin() {
  OB.pin = ''; OB.pin1 = ''; OB.mode = 'setup';
  showAuth('<div class="ob">' + progress(3) + pinPad('Set a 4-digit PIN', 'Keeps your accounts private if someone else uses your phone.',
    '<button class="btn block" data-ob="skip-pin">Skip for now</button>') + '</div>');
}
function openPinChange() {
  OB.pin = ''; OB.pin1 = ''; OB.mode = 'change';
  showAuth(pinPad('Set a new PIN', 'Enter 4 digits', '<button class="btn block" data-ob="cancel-pin">Cancel</button>'));
}
function showLock() {
  OB.pin = ''; OB.mode = 'login';
  const s = DB.data.settings;
  const first = (s.ownerName || '').split(' ')[0];
  showAuth(pinPad('Welcome back' + (first ? ', ' + esc(first) : ''), esc(s.shopName || 'Enter your PIN'),
    '<button class="link-btn" data-ob="forgot">Forgot PIN?</button>'), 'lock');
}
function renderDots(state) {
  const box = document.getElementById('pin-dots');
  if (!box) return;
  box.querySelectorAll('span').forEach((d, i) => d.classList.toggle('on', i < OB.pin.length));
  box.classList.remove('shake', 'ok');
  if (state) { void box.offsetWidth; box.classList.add(state); }
}
function setPinSub(t) { const el = document.getElementById('pin-sub'); if (el) el.textContent = t; }

async function hashPin(pin, salt) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(salt + ':' + pin));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}
async function savePin(pin) {
  const salt = Cloud.randomHex(8);
  // Recovery code: the only way to reset a forgotten PIN (the mobile number alone is printed on every invoice)
  const abc = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const rnd = new Uint8Array(8);
  crypto.getRandomValues(rnd);
  const code = Array.from(rnd).map((b) => abc[b % abc.length]).join('');
  DB.data.settings.pinSalt = salt;
  DB.data.settings.pinHash = await hashPin(pin, salt);
  DB.data.settings.recHash = await hashPin(code, salt + ':rec');
  DB.save();
  OB.recovery = code.slice(0, 4) + '-' + code.slice(4);
}

/* ---------- Wrong-PIN throttle: 5 tries, then a growing wait ---------- */
const PinGuard = {
  get() { try { return JSON.parse(localStorage.getItem('bk_pin_guard') || '{}'); } catch (e) { return {}; } },
  set(v) { try { localStorage.setItem('bk_pin_guard', JSON.stringify(v)); } catch (e) { /* private mode */ } },
  waitLeft() { const g = this.get(); return Math.max(0, Math.ceil(((g.until || 0) - Date.now()) / 1000)); },
  fail() {
    const g = this.get();
    g.fails = (g.fails || 0) + 1;
    if (g.fails >= 5) g.until = Date.now() + 30000 * Math.pow(2, Math.min(g.fails - 5, 6));
    this.set(g);
  },
  reset() { this.set({}); },
};

function obRecovery() {
  const s = DB.data.settings;
  const msg = 'BahiKhata+ recovery code for ' + s.shopName + ': ' + OB.recovery + '. Keep it safe. You need it if you forget your PIN.';
  showAuth('<div class="ob">' + (OB.mode === 'setup' ? progress(3) : '') +
    '<div class="ob-head"><h2>Save your recovery code</h2><p class="muted">If you ever forget your PIN, this code is the only way to reset it on this phone. Write it down or send it to yourself.</p></div>' +
    '<div class="card" style="text-align:center;padding:22px"><div class="label">Recovery code</div><div style="font-size:2rem;font-weight:800;letter-spacing:0.12em" class="num" id="rec-code">' + esc(OB.recovery) + '</div></div>' +
    '<div class="btns">' + (s.phone ? '<a class="btn" target="_blank" rel="noopener" href="' + waLink(s.phone, msg) + '">' + ic('chat') + 'Send to my WhatsApp</a>' : '') +
    '<button class="btn" data-ob="rec-copy">Copy code</button></div>' +
    '<div class="ob-actions"><button class="btn primary block big" data-ob="rec-done">I have saved it</button></div></div>');
}

/* ---------- Cloud backup consent (only when this build has a backup server) ---------- */
function obCloud() {
  showAuth('<div class="ob">' + progress(4) +
    '<div class="ob-head"><h2>Keep your data safe</h2><p class="muted">Phones get lost. A daily backup means you never lose your accounts.</p></div>' +
    '<div class="card stack"><b>Daily cloud backup</b><span class="small">' + esc(CLOUD_NOTICE) + '</span></div>' +
    '<div class="ob-actions"><button class="btn primary block big" data-ob="cloud-yes">Turn on cloud backup</button>' +
    '<button class="btn block" data-ob="cloud-no">Not now</button></div></div>');
}

async function pinDigit(k) {
  if (k === 'del') { OB.pin = OB.pin.slice(0, -1); renderDots(); return; }
  if (OB.pin.length >= 4) return;
  OB.pin += k;
  renderDots();
  if (OB.pin.length < 4) return;
  const pin = OB.pin;
  await new Promise((r) => setTimeout(r, 160));
  if (OB.mode === 'login') {
    const s = DB.data.settings;
    const wait = PinGuard.waitLeft();
    if (wait) { OB.pin = ''; renderDots('shake'); setPinSub('Too many wrong tries. Wait ' + wait + ' seconds.'); return; }
    if ((await hashPin(pin, s.pinSalt)) === s.pinHash) {
      PinGuard.reset();
      renderDots('ok');
      unlock();
    } else {
      PinGuard.fail();
      OB.pin = '';
      renderDots('shake');
      if (navigator.vibrate) navigator.vibrate([60, 40, 60]);
      const w = PinGuard.waitLeft();
      setPinSub(w ? 'Too many wrong tries. Wait ' + w + ' seconds.' : 'Wrong PIN. Try again.');
    }
    return;
  }
  if (!OB.pin1) { OB.pin1 = pin; OB.pin = ''; renderDots(); setPinSub('Enter the same PIN again to confirm'); return; }
  if (pin !== OB.pin1) { OB.pin1 = ''; OB.pin = ''; renderDots('shake'); setPinSub('PINs didn\'t match. Enter a new PIN.'); return; }
  await savePin(pin);
  renderDots('ok');
  setTimeout(obRecovery, 450);
}

let unlockedAt = 0;
function unlock() {
  unlockedAt = Date.now();
  setTimeout(() => {
    UI.animate = true;
    render();
    hideAuth(true);
    afterUnlock();
  }, 350);
}
function isLocked() { return !authRoot().hidden; }
function lockIfNeeded() {
  // Ask for the PIN again when the app comes back after a minute in the background
  if (DB.data.settings.pinHash && DB.data.onboarded && authRoot().hidden && Date.now() - lastHidden > 60000) showLock();
}
let lastHidden = Date.now();
document.addEventListener('visibilitychange', () => {
  if (document.hidden) lastHidden = Date.now();
  else lockIfNeeded();
});

/* ---------- Done ---------- */
function obDone() {
  const d = DB.data.settings;
  const colors = ['var(--accent)', 'var(--gave)', 'var(--got)', 'var(--warn)'];
  const confetti = Array.from({ length: 28 }, (_, i) =>
    '<i style="--x:' + (Math.round(Math.random() * 240) - 120) + 'px;--y:' + (-(Math.round(Math.random() * 180) + 80)) + 'px;--r:' + Math.round(Math.random() * 540) + 'deg;--d:' + (Math.random() * 0.25).toFixed(2) + 's;background:' + colors[i % 4] + '"></i>').join('');
  showAuth('<div class="ob done-screen">' + progress(5) +
    '<div class="done-art"><div class="confetti">' + confetti + '</div><svg class="check" viewBox="0 0 80 80"><circle cx="40" cy="40" r="34"/><path d="M25 41l10 10 20-22"/></svg></div>' +
    '<h2>' + esc(d.shopName) + ' is ready</h2><p class="muted">Your ' + esc(currentPreset().label.toLowerCase()) + ' ledger is set up with matching categories and GST.</p>' +
    '<div class="ob-actions"><button class="btn primary block big" data-ob="finish">Start my ledger</button>' +
    '<button class="btn block" data-ob="finish-demo">Explore with sample data first</button></div>' +
    '<p class="small muted center">Sample data can be removed with one tap later.</p></div>');
}

/* ---------- Events ---------- */
document.addEventListener('click', (e) => {
  const pinBtn = e.target.closest('[data-pin]');
  if (pinBtn && isLocked()) { pinDigit(pinBtn.dataset.pin); return; }
  const el = e.target.closest('[data-ob]');
  if (!el) return;
  const a = el.dataset.ob;
  if (a === 'slide') { clearInterval(OB.timer); setSlide(Number(el.dataset.i)); }
  if (a === 'to-type') obGo('type');
  if (a === 'type') {
    OB.data.businessType = el.dataset.id;
    document.querySelectorAll('.type-card').forEach((c) => c.classList.toggle('on', c === el));
    const btn = document.querySelector('[data-ob="to-details"]');
    if (btn) btn.disabled = false;
  }
  if (a === 'to-details') obGo('details');
  if (a === 'back-type') { readObForm(); obGo('type'); }
  if (a === 'skip-pin') afterPinStep();
  if (a === 'rec-copy') {
    const done = () => toast('Recovery code copied.', 'good');
    if (navigator.clipboard) navigator.clipboard.writeText(OB.recovery).then(done, () => toast(OB.recovery)); else toast(OB.recovery);
  }
  if (a === 'rec-done') {
    if (OB.mode === 'change') { hideAuth(true); toast('PIN saved.', 'good'); } else afterPinStep();
  }
  if (a === 'cloud-yes' || a === 'cloud-no') { Cloud.setConsent(a === 'cloud-yes'); obGo('done'); }
  if (a === 'forgot-erase') {
    if (OB.eraseArmed) { DB.data = DB.empty(); DB.save(); PinGuard.reset(); location.reload(); return; }
    OB.eraseArmed = true;
    el.textContent = 'Tap again: erase everything on this phone';
    setTimeout(() => { OB.eraseArmed = false; }, 5000);
  }
  if (a === 'cancel-pin') hideAuth(true);
  if (a === 'finish' || a === 'finish-demo') {
    DB.data.onboarded = true;
    DB.data.welcomed = true;
    if (a === 'finish-demo') seedDemo(); else DB.save();
    unlockedAt = Date.now();
    UI.animate = true;
    render();
    hideAuth(true);
    afterUnlock();
    toast(a === 'finish-demo' ? 'Sample data loaded. Try the mic: "Gave 500 to Ramesh".' : 'Welcome! Add your first customer with the Party button.', 'good');
  }
  if (a === 'forgot') showForgot();
  if (a === 'forgot-back') showLock();
});
document.addEventListener('keydown', (e) => {
  if (!isLocked() || !document.getElementById('pin-dots')) return;
  if (/^[0-9]$/.test(e.key)) pinDigit(e.key);
  if (e.key === 'Backspace') pinDigit('del');
});
function readObForm() {
  const f = document.getElementById('ob-form');
  if (!f) return;
  const fd = new FormData(f);
  for (const k of ['shopName', 'ownerName', 'phone', 'city', 'stateCode', 'gstin', 'upi']) OB.data[k] = (fd.get(k) || '').trim();
  if (fd.get('hasGst') !== 'on') OB.data.gstin = '';
}
document.addEventListener('change', async (e) => {
  if (e.target.id === 'ob-hasgst') document.getElementById('ob-gst-field').hidden = !e.target.checked;
  if (e.target.id === 'ob-restore' && e.target.files[0]) {
    try {
      DB.restore(JSON.parse(await e.target.files[0].text()));
      DB.data.onboarded = true;
      DB.save();
      applyTheme();
      render();
      hideAuth(true);
      afterUnlock();
      toast('Your data has been restored.', 'good');
    } catch (err) { toast(err.message, 'bad'); }
  }
});
document.addEventListener('submit', (e) => {
  if (e.target.id === 'ob-form') {
    e.preventDefault();
    readObForm();
    const d = OB.data;
    if (cleanPhone(d.phone).length !== 12) return toast('Enter a 10-digit mobile number.', 'bad');
    if (d.gstin && d.gstin.length !== 15) return toast('A GSTIN has 15 characters.', 'bad');
    const s = DB.data.settings;
    const t = BUSINESS_TYPES.find((x) => x.id === d.businessType);
    Object.assign(s, {
      businessType: d.businessType, shopName: d.shopName, ownerName: d.ownerName, phone: d.phone, city: d.city,
      stateCode: d.stateCode, gstin: d.gstin.toUpperCase(), upi: d.upi, defaultGst: t.gst,
      invoicePrefix: (d.shopName.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'INV') + '/',
    });
    DB.save();
    obGo('pin');
  }
  if (e.target.id === 'forgot-form') {
    e.preventDefault();
    checkForgot(new FormData(e.target));
  }
});
function showForgot() {
  const hasCode = !!DB.data.settings.recHash;
  showAuth('<div class="pin-screen"><div class="pin-head">' + LOGO_SVG.replace('logo-mark', 'logo-mark small still') + '<h2>Reset your PIN</h2>' +
    '<p class="muted">' + (hasCode ? 'Enter your mobile number and the recovery code you saved when you set the PIN.' : 'Enter the mobile number you used when setting up this business.') + '</p></div>' +
    '<form class="stack" id="forgot-form" style="width:100%;max-width:340px"><label class="field"><span>Mobile number</span><input name="phone" type="tel" inputmode="tel" required></label>' +
    (hasCode ? '<label class="field"><span>Recovery code</span><input name="code" required autocomplete="off" style="text-transform:uppercase;letter-spacing:0.1em" placeholder="XXXX-XXXX"></label>' : '') +
    '<button class="btn primary block" type="submit">Reset PIN</button><button class="btn block" type="button" data-ob="forgot-back">Back</button>' +
    '<button class="link-btn" type="button" data-ob="forgot-erase">Lost the code? Erase this phone and restore from a backup</button></form></div>', 'lock');
}
async function checkForgot(fd) {
  const s = DB.data.settings;
  const wait = PinGuard.waitLeft();
  if (wait) return toast('Too many wrong tries. Wait ' + wait + ' seconds.', 'bad');
  const phoneOk = !!s.phone && cleanPhone(fd.get('phone')) === cleanPhone(s.phone);
  let codeOk = true;
  if (s.recHash) {
    const code = String(fd.get('code') || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    codeOk = (await hashPin(code, s.pinSalt + ':rec')) === s.recHash;
  }
  if (!phoneOk || !codeOk) {
    PinGuard.fail();
    return toast(!phoneOk ? 'That number does not match this business.' : 'That recovery code is not right.', 'bad');
  }
  PinGuard.reset();
  delete s.pinHash;
  delete s.recHash;
  DB.save();
  toast('PIN removed. Set a new one in Settings › Security.', 'good');
  unlock();
}

// Runs once the app is visible (after onboarding or PIN): backups and updates
function afterUnlock() {
  if (typeof armDailyBackup === 'function') armDailyBackup();
  // Businesses that signed up before cloud backup existed are asked once
  if (Cloud.available() && DB.data.settings.cloudConsent === undefined && !DB.data.demo) {
    setTimeout(() => { if (!UI.stack.length) openSheet(cloudConsentSheet); }, 900);
  }
  Cloud.autoCheck();
}

/* ---------- Start ---------- */
function startAuth() {
  if (!DB.data.onboarded) {
    // Older data without the flag but with a business already set up counts as onboarded
    if (DB.data.parties.length || DB.data.settings.shopName) { DB.data.onboarded = true; DB.save(); }
    else { startOnboarding(); return false; }
  }
  if (DB.data.settings.pinHash) { showLock(); return false; }
  return true;
}

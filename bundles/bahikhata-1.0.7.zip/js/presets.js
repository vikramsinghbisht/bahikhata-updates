// Business types. Each one sets sensible defaults: expense categories, units, GST rate,
// whether to track expiry, WhatsApp offer templates and the sample items used for demo data.
// Sample items: [name, unit, HSN/SAC, GST %, purchase price, selling price, low-stock level, qty, expiry in days or null]

const BASE_EXPENSES = ['Rent', 'Electricity', 'Staff salary', 'Transport', 'Tea & snacks', 'Phone/Internet', 'Repair'];

const TYPE_ICONS = {
  kirana: '<path d="M4 9h16l-1.5 11h-13z"/><path d="M8 9V7a4 4 0 0 1 8 0v2"/>',
  medical: '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="M12 8v8M8 12h8"/>',
  clothing: '<path d="M8 4 4 7l2 4 2-1v10h8V10l2 1 2-4-4-3a4 4 0 0 1-8 0z"/>',
  electronics: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18h2"/>',
  hardware: '<path d="M14 6a4 4 0 0 0 5 5l-9 9a2 2 0 0 1-3-3z"/><path d="m15 5 4 4"/>',
  bakery: '<path d="M4 20h16v-6a3 3 0 0 0-3-3H7a3 3 0 0 0-3 3z"/><path d="M4 16c2 1 4-1 6 0s4 1 6 0 3-1 4 0"/><path d="M12 11V6M10 4h4"/>',
  stationery: '<path d="M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h10"/>',
  party: '<path d="M12 3a5 5 0 0 1 5 5c0 4-5 8-5 8s-5-4-5-8a5 5 0 0 1 5-5z"/><path d="M12 16v5"/>',
  salon: '<circle cx="6.5" cy="17.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/><path d="M8.5 16 18 4M15.5 16 6 4"/>',
  restaurant: '<path d="M6 3v8a2 2 0 0 0 4 0V3M8 11v10"/><path d="M17 21V3c-2 1-3 4-3 7h3"/>',
  services: '<path d="M4 20 14 10"/><path d="M14 4a6 6 0 0 0 6 6l-3 3-6-6z"/>',
  other: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
};

const BUSINESS_TYPES = [
  {
    id: 'kirana', label: 'Kirana / General store', short: 'Kirana', units: ['PCS', 'KGS', 'PAC', 'BOX', 'LTR', 'DOZ'], gst: 5, expiry: true,
    expenses: BASE_EXPENSES.concat(['Packing', 'Other']),
    items: [
      ['Basmati rice 1 kg', 'PAC', '1006', 5, 95, 130, 10, 40, null], ['Toor dal 1 kg', 'PAC', '0713', 0, 120, 150, 10, 25, null],
      ['Sugar 1 kg', 'PAC', '1701', 5, 40, 48, 15, 60, null], ['Sunflower oil 1 L', 'PAC', '1512', 5, 125, 155, 8, 5, null],
      ['Tea 250 g', 'PAC', '0902', 5, 95, 130, 6, 18, 200], ['Biscuits family pack', 'PAC', '1905', 5, 32, 45, 12, 30, 20],
      ['Detergent powder 1 kg', 'PAC', '3402', 18, 85, 115, 6, 14, null], ['Milk 500 ml', 'PAC', '0401', 0, 26, 30, 10, 12, 2],
    ],
    offers: [['Weekly savings', 'Hello {name}! This week at {shop}: extra savings on rice, dal and oil. Free home delivery on orders above ₹500. Order on WhatsApp!']],
  },
  {
    id: 'medical', label: 'Medical / Pharmacy', short: 'Medical', units: ['STRIP', 'BOTTLE', 'PCS', 'BOX', 'TUBE'], gst: 5, expiry: true,
    expenses: BASE_EXPENSES.concat(['Licence & fees', 'Other']),
    items: [
      ['Paracetamol 650 (strip)', 'STRIP', '3004', 5, 18, 30, 20, 80, 400], ['Cough syrup 100 ml', 'BOTTLE', '3004', 5, 70, 110, 8, 14, 25],
      ['Vitamin C tablets', 'STRIP', '3004', 5, 25, 40, 10, 30, 300], ['ORS sachet', 'PCS', '3004', 5, 15, 22, 20, 12, 180],
      ['Crepe bandage', 'PCS', '3005', 5, 45, 80, 5, 20, null], ['Hand sanitizer 100 ml', 'BOTTLE', '3808', 18, 30, 50, 10, 24, 12],
      ['Digital thermometer', 'PCS', '9025', 18, 120, 199, 3, 6, null], ['Face masks (box of 50)', 'BOX', '6307', 5, 90, 150, 4, 2, null],
    ],
    offers: [['Health check reminder', 'Hello {name}! {shop} reminds you to refill your regular medicines on time. Home delivery available. Just send your prescription on WhatsApp.']],
  },
  {
    id: 'clothing', label: 'Clothing / Garments', short: 'Clothing', units: ['PCS', 'SET', 'MTR', 'PAIR'], gst: 5, expiry: false,
    expenses: BASE_EXPENSES.concat(['Tailoring', 'Packing', 'Other']),
    items: [
      ['Men\'s cotton shirt', 'PCS', '6205', 5, 380, 699, 5, 24, null], ['Denim jeans', 'PCS', '6203', 5, 520, 999, 5, 18, null],
      ['Printed kurti', 'PCS', '6204', 5, 290, 549, 6, 30, null], ['Cotton saree', 'PCS', '5208', 5, 650, 1199, 3, 10, null],
      ['Kids T-shirt', 'PCS', '6109', 5, 120, 249, 8, 4, null], ['Socks (pair)', 'PAIR', '6115', 5, 30, 69, 12, 40, null],
      ['Leggings', 'PCS', '6104', 5, 110, 229, 8, 22, null], ['Dupatta', 'PCS', '6214', 5, 140, 299, 5, 15, null],
    ],
    offers: [['New collection', 'Hello {name}! The new season collection has arrived at {shop}: kurtis, shirts and kids wear. Flat 10% off this week. Visit us!']],
  },
  {
    id: 'electronics', label: 'Mobile & Electronics', short: 'Electronics', units: ['PCS', 'BOX', 'SET'], gst: 18, expiry: false,
    expenses: BASE_EXPENSES.concat(['Spare parts', 'Other']),
    items: [
      ['Fast charger 25W', 'PCS', '8504', 18, 280, 499, 5, 16, null], ['USB-C cable 1 m', 'PCS', '8544', 18, 60, 149, 10, 40, null],
      ['Wired earphones', 'PCS', '8518', 18, 110, 249, 6, 20, null], ['Power bank 10000 mAh', 'PCS', '8507', 18, 650, 1099, 3, 7, null],
      ['Tempered glass', 'PCS', '3919', 18, 25, 149, 15, 60, null], ['Phone back cover', 'PCS', '3926', 18, 40, 199, 15, 8, null],
      ['LED bulb 9W', 'PCS', '8539', 18, 55, 99, 10, 30, null], ['Extension board 4-socket', 'PCS', '8536', 18, 180, 329, 4, 9, null],
    ],
    offers: [['New arrivals', 'Hello {name}! New chargers, earphones and power banks just arrived at {shop}. Free screen guard fitting with every phone cover this week!']],
  },
  {
    id: 'hardware', label: 'Hardware & Paint', short: 'Hardware', units: ['PCS', 'KGS', 'LTR', 'BOX', 'MTR', 'BAG'], gst: 18, expiry: false,
    expenses: BASE_EXPENSES.concat(['Loading & labour', 'Other']),
    items: [
      ['Wall emulsion 1 L', 'PCS', '3209', 18, 210, 320, 6, 20, null], ['Cement bag 50 kg', 'BAG', '2523', 18, 330, 390, 20, 60, null],
      ['PVC pipe 1 inch (3 m)', 'PCS', '3917', 18, 140, 210, 10, 35, null], ['Wood screws (box)', 'BOX', '7318', 18, 60, 110, 5, 14, null],
      ['Door hinge (pair)', 'PCS', '8302', 18, 45, 90, 10, 6, null], ['Claw hammer', 'PCS', '8205', 18, 150, 260, 3, 8, null],
      ['Copper wire 90 m', 'PCS', '8544', 18, 1150, 1450, 3, 5, null], ['Bathroom tap', 'PCS', '8481', 18, 260, 450, 4, 12, null],
    ],
    offers: [['Season offer', 'Hello {name}! Painting season offer at {shop}: special rates on wall paints and putty. Contractors get extra discount. Call or WhatsApp us!']],
  },
  {
    id: 'bakery', label: 'Bakery & Sweets', short: 'Bakery', units: ['PCS', 'KGS', 'BOX', 'PAC'], gst: 5, expiry: true,
    expenses: BASE_EXPENSES.concat(['Gas cylinder', 'Raw material', 'Packing', 'Other']),
    items: [
      ['Chocolate cake 1 kg', 'PCS', '1905', 5, 380, 650, 2, 3, 2], ['White bread', 'PAC', '1905', 0, 28, 40, 10, 15, 3],
      ['Butter cookies 500 g', 'BOX', '1905', 5, 120, 200, 5, 14, 45], ['Kaju katli 500 g', 'BOX', '1704', 5, 380, 550, 4, 8, 12],
      ['Rasgulla tin 1 kg', 'PCS', '2106', 5, 150, 240, 4, 10, 120], ['Namkeen 400 g', 'PAC', '2106', 5, 70, 110, 8, 25, 60],
      ['Pastry', 'PCS', '1905', 5, 25, 50, 10, 6, 1], ['Birthday candles', 'BOX', '3406', 18, 25, 60, 10, 30, null],
    ],
    offers: [['Festival sweets', 'Hello {name}! Festival sweet boxes are ready at {shop}: kaju katli, rasgulla and dry-fruit boxes. Pre-order now for the best choice!']],
  },
  {
    id: 'stationery', label: 'Stationery & Books', short: 'Stationery', units: ['PCS', 'BOX', 'PAC', 'SET', 'REAM'], gst: 18, expiry: false,
    expenses: BASE_EXPENSES.concat(['Packing', 'Other']),
    items: [
      ['Notebook 200 pages', 'PCS', '4820', 5, 35, 60, 20, 80, null], ['Ball pen (box of 10)', 'BOX', '9608', 18, 50, 90, 8, 25, null],
      ['Pencil box', 'PCS', '9609', 18, 30, 60, 10, 30, null], ['Geometry box', 'PCS', '9017', 18, 75, 140, 5, 12, null],
      ['A4 paper ream', 'REAM', '4802', 18, 230, 310, 5, 4, null], ['Stapler', 'PCS', '8472', 18, 70, 130, 4, 10, null],
      ['Glue stick', 'PCS', '3506', 18, 18, 35, 15, 40, null], ['School bag', 'PCS', '4202', 18, 380, 699, 3, 7, null],
    ],
    offers: [['Back to school', 'Hello {name}! Back-to-school sale at {shop}: notebooks, bags and complete stationery kits. Get 10% off on orders above ₹1,000!']],
  },
  {
    id: 'party', label: 'Party & Gift shop', short: 'Party & gifts', units: ['PCS', 'PAC', 'BOX', 'SET'], gst: 18, expiry: true,
    expenses: BASE_EXPENSES.concat(['Packing', 'Decoration material', 'Other']),
    items: [
      ['Latex balloons (pack of 50)', 'PAC', '9505', 18, 120, 199, 15, 40, null], ['Foil number balloon', 'PCS', '9505', 18, 45, 99, 10, 8, null],
      ['Happy Birthday banner', 'PCS', '4911', 18, 60, 149, 5, 25, null], ['Cake candles (box)', 'BOX', '3406', 18, 25, 60, 10, 30, null],
      ['Party hats (set of 10)', 'SET', '4823', 18, 55, 120, 6, 4, null], ['Chocolate gift box', 'BOX', '1806', 5, 160, 220, 6, 10, 20],
      ['Return gift set', 'PCS', '9503', 5, 70, 149, 10, 35, null], ['Party poppers', 'PCS', '9505', 18, 30, 70, 10, 22, null],
    ],
    offers: [['Birthday package', 'Hello {name}! Birthday coming up? {shop}\'s complete party package (decoration + return gifts) now starts at ₹1,999. Reply to book.']],
  },
  {
    id: 'salon', label: 'Salon & Beauty', short: 'Salon', units: ['SERVICE', 'PCS', 'BOTTLE'], gst: 18, expiry: true,
    expenses: BASE_EXPENSES.concat(['Products', 'Laundry', 'Other']),
    items: [
      ['Haircut', 'SERVICE', '9997', 18, 0, 150, 0, 999, null], ['Facial', 'SERVICE', '9997', 18, 120, 600, 0, 999, null],
      ['Hair colour', 'SERVICE', '9997', 18, 250, 900, 0, 999, null], ['Beard trim', 'SERVICE', '9997', 18, 0, 80, 0, 999, null],
      ['Shampoo 180 ml', 'BOTTLE', '3305', 18, 110, 175, 4, 10, 300], ['Hair oil 200 ml', 'BOTTLE', '3305', 18, 90, 140, 4, 3, 360],
      ['Face wash 100 ml', 'PCS', '3304', 18, 95, 160, 4, 8, 240], ['Wax (pack)', 'PCS', '3304', 18, 150, 250, 2, 5, 25],
    ],
    offers: [['Festive glow', 'Hello {name}! Get festive-ready at {shop}: facial + haircut combo at a special price this week. Reply to book your slot!']],
  },
  {
    id: 'restaurant', label: 'Restaurant / Cafe / Dhaba', short: 'Restaurant', units: ['PLATE', 'PCS', 'CUP', 'BOTTLE', 'KGS'], gst: 5, expiry: true,
    expenses: BASE_EXPENSES.concat(['Gas cylinder', 'Raw material', 'Cleaning', 'Other']),
    items: [
      ['Veg thali', 'PLATE', '9963', 5, 60, 150, 0, 999, null], ['Masala tea', 'CUP', '9963', 5, 6, 20, 0, 999, null],
      ['Cold coffee', 'CUP', '9963', 5, 25, 80, 0, 999, null], ['Samosa (2 pcs)', 'PLATE', '9963', 5, 10, 30, 0, 999, null],
      ['Paneer roll', 'PCS', '9963', 5, 40, 110, 0, 999, null], ['Cold drink 250 ml', 'BOTTLE', '2202', 40, 15, 25, 24, 60, 90],
      ['Water bottle 1 L', 'BOTTLE', '2201', 18, 9, 20, 24, 12, 180], ['Instant noodles', 'PCS', '1902', 18, 12, 40, 10, 30, 150],
    ],
    offers: [['Weekend special', 'Hello {name}! Weekend special at {shop}: family thali combo with free cold drinks. Dine in or order on WhatsApp!']],
  },
  {
    id: 'services', label: 'Repair & Services', short: 'Services', units: ['SERVICE', 'PCS', 'HOUR'], gst: 18, expiry: false,
    expenses: BASE_EXPENSES.concat(['Spare parts', 'Tools', 'Other']),
    items: [
      ['Service visit charge', 'SERVICE', '9987', 18, 0, 299, 0, 999, null], ['Mobile screen replacement', 'SERVICE', '9987', 18, 900, 1800, 0, 999, null],
      ['Battery replacement', 'SERVICE', '9987', 18, 450, 900, 0, 999, null], ['AC service', 'SERVICE', '9987', 18, 150, 599, 0, 999, null],
      ['Stitching (per piece)', 'SERVICE', '9988', 5, 60, 250, 0, 999, null], ['Spare: charging port', 'PCS', '8517', 18, 120, 250, 5, 3, null],
      ['Spare: speaker', 'PCS', '8518', 18, 90, 200, 5, 9, null], ['Spare: capacitor', 'PCS', '8532', 18, 110, 250, 5, 12, null],
    ],
    offers: [['Service reminder', 'Hello {name}! It\'s time for your regular service. {shop} offers doorstep service with genuine parts. Reply to book a visit!']],
  },
  {
    id: 'other', label: 'Other business', short: 'Business', units: ['PCS', 'BOX', 'KGS', 'LTR', 'MTR', 'SET', 'SERVICE'], gst: 18, expiry: false,
    expenses: BASE_EXPENSES.concat(['Packing', 'Other']),
    items: [
      ['Product A', 'PCS', '', 18, 100, 150, 10, 40, null], ['Product B', 'PCS', '', 18, 200, 290, 5, 4, null],
      ['Product C', 'BOX', '', 5, 60, 95, 10, 25, null], ['Service charge', 'SERVICE', '', 18, 0, 300, 0, 999, null],
    ],
    offers: [],
  },
];

const GENERIC_OFFERS = [
  ['Festival sale', 'Hello {name}! Festival special at {shop}: great discounts on our best products. This week only. Visit us today!'],
  ['Thank you', 'Hello {name}! Thank you for shopping with {shop}. We value you as a customer. Save this number for quick orders on WhatsApp!'],
  ['Custom message', ''],
];

function currentPreset() {
  const id = DB.data && DB.data.settings.businessType;
  return BUSINESS_TYPES.find((t) => t.id === id) || BUSINESS_TYPES[BUSINESS_TYPES.length - 1];
}
function typeIcon(id, size) {
  return '<svg viewBox="0 0 24 24" width="' + (size || 28) + '" height="' + (size || 28) + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (TYPE_ICONS[id] || TYPE_ICONS.other) + '</svg>';
}
function presetOffers() {
  return currentPreset().offers.concat(GENERIC_OFFERS);
}
function presetUnits() {
  const u = currentPreset().units.slice();
  for (const extra of ['PCS', 'BOX', 'KGS', 'LTR', 'MTR', 'SET', 'NOS', 'DOZ', 'PAC']) if (!u.includes(extra)) u.push(extra);
  return u;
}

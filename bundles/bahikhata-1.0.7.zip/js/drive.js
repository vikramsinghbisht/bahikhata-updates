// Google Drive par roz ka automatic backup.
// "drive.file" permission: app sirf apni banayi files dekh sakta hai, aapki baaki Drive nahi.

const Drive = {
  FOLDER: 'BahiKhata+ Backups',
  token: null,
  tokenExp: 0,
  client: null,
  loading: null,

  loadGis() {
    if (window.google && google.accounts && google.accounts.oauth2) return Promise.resolve();
    if (this.loading) return this.loading;
    this.loading = new Promise((resolve, reject) => {
      const sc = document.createElement('script');
      sc.src = 'https://accounts.google.com/gsi/client';
      sc.async = true;
      sc.onload = () => resolve();
      sc.onerror = () => { this.loading = null; reject(new Error('Could not load Google sign-in. Check your internet connection.')); };
      document.head.appendChild(sc);
    });
    return this.loading;
  },

  async getToken(interactive) {
    if (this.token && Date.now() < this.tokenExp - 60000) return this.token;
    const cid = googleClientId();
    if (!cid) throw new Error('Add your Google Client ID in Settings.');
    if (location.protocol === 'file:') throw new Error('To use Drive backup, open the app via start.bat (localhost) or from its website.');
    await this.loadGis();
    return new Promise((resolve, reject) => {
      this.client = google.accounts.oauth2.initTokenClient({
        client_id: cid,
        scope: 'https://www.googleapis.com/auth/drive.file',
        prompt: interactive ? 'consent' : '',
        callback: (resp) => {
          if (resp.error) return reject(new Error('Google declined: ' + resp.error));
          this.token = resp.access_token;
          this.tokenExp = Date.now() + (Number(resp.expires_in) || 3600) * 1000;
          resolve(this.token);
        },
        error_callback: (err) => reject(new Error(err && err.type === 'popup_closed' ? 'The Google window was closed.' : 'Google sign-in failed. Allow pop-ups for this site.')),
      });
      this.client.requestAccessToken({ prompt: interactive ? 'consent' : '' });
    });
  },

  async api(path, opts) {
    const token = await this.getToken(false);
    const res = await fetch('https://www.googleapis.com' + path, Object.assign({}, opts, {
      headers: Object.assign({ Authorization: 'Bearer ' + token }, (opts && opts.headers) || {}),
    }));
    if (!res.ok) {
      const txt = await res.text();
      throw new Error('Drive error ' + res.status + ': ' + txt.slice(0, 140));
    }
    return res;
  },

  async folderId() {
    const cached = DB.data.meta.driveFolderId;
    if (cached) {
      try {
        const r = await this.api('/drive/v3/files/' + cached + '?fields=id,trashed');
        const j = await r.json();
        if (!j.trashed) return cached;
      } catch (e) { /* folder mita diya gaya, naya banao */ }
    }
    const q = encodeURIComponent("name='" + this.FOLDER + "' and mimeType='application/vnd.google-apps.folder' and trashed=false");
    const r = await this.api('/drive/v3/files?q=' + q + '&fields=files(id)');
    const j = await r.json();
    let id = j.files && j.files[0] && j.files[0].id;
    if (!id) {
      const c = await this.api('/drive/v3/files?fields=id', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: this.FOLDER, mimeType: 'application/vnd.google-apps.folder' }),
      });
      id = (await c.json()).id;
    }
    DB.data.meta.driveFolderId = id;
    DB.save();
    return id;
  },

  async backup() {
    const folder = await this.folderId();
    const snap = JSON.stringify(DB.snapshot());
    const name = 'bahikhata-backup-' + today() + '.json';
    // Aaj ki file pehle se ho to usi ko update karo (ek din = ek file)
    const q = encodeURIComponent("name='" + name + "' and '" + folder + "' in parents and trashed=false");
    const ex = await (await this.api('/drive/v3/files?q=' + q + '&fields=files(id)')).json();
    const existing = ex.files && ex.files[0] && ex.files[0].id;
    const boundary = 'mbk' + Math.random().toString(36).slice(2);
    const meta = existing ? { name } : { name, parents: [folder], mimeType: 'application/json' };
    const body = '--' + boundary + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + JSON.stringify(meta) +
      '\r\n--' + boundary + '\r\nContent-Type: application/json\r\n\r\n' + snap + '\r\n--' + boundary + '--';
    await this.api('/upload/drive/v3/files' + (existing ? '/' + existing : '') + '?uploadType=multipart&fields=id', {
      method: existing ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'multipart/related; boundary=' + boundary },
      body,
    });
    await this.prune(folder);
    DB.data.meta.lastDriveBackup = new Date().toISOString();
    DB.data.meta.lastDriveError = null;
    DB.save();
    return name;
  },

  async prune(folder) {
    const keep = Number(DB.data.settings.driveKeep) || 30;
    const list = await this.list(folder);
    for (const f of list.slice(keep)) {
      try { await this.api('/drive/v3/files/' + f.id, { method: 'DELETE' }); } catch (e) { /* agli baar */ }
    }
  },

  async list(folder) {
    folder = folder || (await this.folderId());
    const q = encodeURIComponent("'" + folder + "' in parents and trashed=false");
    const r = await this.api('/drive/v3/files?q=' + q + '&orderBy=createdTime desc&pageSize=100&fields=files(id,name,size,modifiedTime)');
    return (await r.json()).files || [];
  },

  async download(id) {
    const r = await this.api('/drive/v3/files/' + id + '?alt=media');
    return r.json();
  },

  // Roz ek baar: app khulte hi aur app khula rahe to har ghante check
  async autoCheck() {
    const s = DB.data.settings;
    if (!s.driveAutoBackup || !googleClientId() || !navigator.onLine || location.protocol === 'file:') return;
    const last = DB.data.meta.lastDriveBackup;
    if (last && ymd(new Date(last)) === today()) return;
    try {
      await this.getToken(false);
      const name = await this.backup();
      toast("Today's backup saved to Google Drive (" + name + ').', 'good');
    } catch (e) {
      DB.data.meta.lastDriveError = e.message;
      DB.save();
    }
    if (window.renderHeader) renderHeader();
  },
};

// Invoices: PDF (A4), WhatsApp message, UPI QR. The PDF libraries ship with the app and load on first use,
// so invoices work offline too.

function loadScript(src) {
  loadScript.cache = loadScript.cache || {};
  if (!loadScript.cache[src]) {
    loadScript.cache[src] = new Promise((resolve, reject) => {
      const sc = document.createElement('script');
      sc.src = src;
      sc.onload = resolve;
      sc.onerror = () => { delete loadScript.cache[src]; reject(new Error('Could not load ' + src)); };
      document.head.appendChild(sc);
    });
  }
  return loadScript.cache[src];
}

/* ---------- Amount in words (Indian system) ---------- */
function amountInWords(n) {
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const two = (x) => (x < 20 ? ones[x] : tens[Math.floor(x / 10)] + (x % 10 ? ' ' + ones[x % 10] : ''));
  const three = (x) => (x >= 100 ? ones[Math.floor(x / 100)] + ' Hundred' + (x % 100 ? ' ' + two(x % 100) : '') : two(x));
  let rupees = Math.floor(Math.abs(n));
  const paise = Math.round((Math.abs(n) - rupees) * 100);
  if (rupees === 0 && paise === 0) return 'Zero Rupees Only';
  const parts = [];
  const crore = Math.floor(rupees / 10000000); rupees %= 10000000;
  const lakh = Math.floor(rupees / 100000); rupees %= 100000;
  const thousand = Math.floor(rupees / 1000); rupees %= 1000;
  if (crore) parts.push(three(crore) + ' Crore');
  if (lakh) parts.push(two(lakh) + ' Lakh');
  if (thousand) parts.push(two(thousand) + ' Thousand');
  if (rupees) parts.push(three(rupees));
  let out = (parts.length ? parts.join(' ') + ' Rupees' : '') + (paise ? (parts.length ? ' and ' : '') + two(paise) + ' Paise' : '');
  return out + ' Only';
}

/* ---------- Helpers ---------- */
function invoiceParty(inv) { return inv.partyId ? DB.get('parties', inv.partyId) : null; }
function invoicePhone(inv) {
  const p = invoiceParty(inv);
  return (p && p.phone) || inv.customerPhone || '';
}
function invoiceStatus(inv) {
  if (inv.cancelled) return { label: 'Cancelled', cls: 'bad' };
  if (inv.payMode === 'udhaar') return { label: 'On credit', cls: 'ok' };
  return { label: 'Paid · ' + (inv.payMode === 'upi' ? 'UPI' : 'Cash'), cls: 'good' };
}
function upiLink(amount, note) {
  const s = DB.data.settings;
  if (!s.upi) return '';
  return 'upi://pay?pa=' + encodeURIComponent(s.upi) + '&pn=' + encodeURIComponent(s.shopName) + '&am=' + r2(amount) + '&cu=INR' + (note ? '&tn=' + encodeURIComponent(note) : '');
}
function invoiceFileName(inv) {
  return 'Invoice_' + inv.no.replace(/[^A-Za-z0-9-]+/g, '-') + '.pdf';
}

/* ---------- WhatsApp text ---------- */
function invoiceText(inv) {
  const s = DB.data.settings;
  const lines = inv.lines.map((l, i) => (i + 1) + '. ' + l.name + ' × ' + l.qty + ' @ ' + money(l.rate) + ' = ' + money(l.total)).join('\n');
  const tax = r2(inv.lines.reduce((a, l) => a + l.cgst + l.sgst + l.igst, 0));
  let t = '*' + s.shopName + '*\n' + (s.gstin ? 'GSTIN ' + s.gstin + '\n' : '') +
    'Invoice *' + inv.no + '* · ' + fmtDate(inv.date) + '\n' +
    (inv.customerName ? 'To: ' + inv.customerName + '\n' : '') + '\n' + lines + '\n\n' +
    (tax ? 'GST: ' + money(tax) + '\n' : '') + '*Total: ' + money(inv.total) + '*\n';
  if (inv.payMode === 'udhaar') {
    t += 'Status: Due (added to your account)\n';
    const link = upiLink(inv.total, 'Invoice ' + inv.no);
    if (link) t += 'Pay by UPI: ' + s.upi + '\n' + link + '\n';
  } else t += 'Paid by ' + (inv.payMode === 'upi' ? 'UPI' : 'cash') + '. Thank you!\n';
  return t + '\nThank you for your business.';
}

/* ---------- Printable invoice (HTML that becomes the PDF) ---------- */
function invoiceHtml(inv) {
  const s = DB.data.settings;
  const p = invoiceParty(inv);
  const pos = inv.pos || s.stateCode;
  const inter = inv.lines.some((l) => l.igst > 0);
  const sum = inv.lines.reduce((a, l) => ({ taxable: a.taxable + l.taxable, cgst: a.cgst + l.cgst, sgst: a.sgst + l.sgst, igst: a.igst + l.igst }), { taxable: 0, cgst: 0, sgst: 0, igst: 0 });
  const title = s.gstin ? 'TAX INVOICE' : 'INVOICE';
  const st = invoiceStatus(inv);
  let qr = '';
  const link = inv.payMode === 'udhaar' && !inv.cancelled ? upiLink(inv.total, 'Invoice ' + inv.no) : '';
  if (link && window.qrcode) {
    const q = qrcode(0, 'M');
    q.addData(link);
    q.make();
    qr = '<div class="iv-qr"><img src="' + q.createDataURL(4, 0) + '" alt=""><div><b>Scan to pay ' + money(inv.total) + '</b><br>' + esc(s.upi) + '</div></div>';
  }
  const rows = inv.lines.map((l, i) =>
    '<tr><td>' + (i + 1) + '</td><td class="iv-name">' + esc(l.name) + '</td><td>' + esc(l.hsn || '') + '</td><td class="r">' + l.qty + ' ' + esc(l.unit || '') + '</td>' +
    '<td class="r">' + money(l.rate) + '</td><td class="r">' + money(l.taxable) + '</td><td class="r">' + l.gstRate + '%</td><td class="r">' + money(l.total) + '</td></tr>').join('');
  const stateName = STATES[s.stateCode] || '';
  const addr = [s.city, s.city && s.city.toLowerCase() === stateName.toLowerCase() ? '' : stateName].filter(Boolean).join(', ');
  return '<div class="iv-doc">' +
    '<div class="iv-top"><div><div class="iv-shop">' + esc(s.shopName) + '</div><div class="iv-sub">' + esc(addr) + (s.phone ? ' · +91 ' + esc(s.phone) : '') + '</div>' +
    (s.gstin ? '<div class="iv-sub">GSTIN: <b>' + esc(s.gstin) + '</b></div>' : '') + '</div>' +
    '<div class="iv-title"><div>' + title + '</div><span class="iv-status ' + st.cls + '">' + esc(st.label) + '</span></div></div>' +
    '<div class="iv-meta"><div><div class="iv-lbl">Bill to</div><div class="iv-to">' + esc(inv.customerName || 'Walk-in customer') + '</div>' +
    (invoicePhone(inv) ? '<div class="iv-sub">+91 ' + esc(invoicePhone(inv)) + '</div>' : '') +
    (inv.customerGstin ? '<div class="iv-sub">GSTIN: ' + esc(inv.customerGstin) + '</div>' : '') +
    (pos ? '<div class="iv-sub">Place of supply: ' + esc(posLabel(pos)) + '</div>' : '') + '</div>' +
    '<div class="iv-right"><div><span class="iv-lbl">Invoice no.</span> <b>' + esc(inv.no) + '</b></div><div><span class="iv-lbl">Date</span> <b>' + fmtDate(inv.date) + '</b></div></div></div>' +
    '<table class="iv-table"><thead><tr><th>#</th><th>Item</th><th>HSN</th><th class="r">Qty</th><th class="r">Rate</th><th class="r">Taxable</th><th class="r">GST</th><th class="r">Amount</th></tr></thead><tbody>' + rows + '</tbody></table>' +
    '<div class="iv-bottom"><div class="iv-words"><div class="iv-lbl">Amount in words</div><div>' + amountInWords(inv.total) + '</div>' + qr + '</div>' +
    '<div class="iv-totals"><div><span>Taxable value</span><span>' + money(sum.taxable) + '</span></div>' +
    (sum.igst + sum.cgst + sum.sgst === 0 ? '' : inter ? '<div><span>IGST</span><span>' + money(sum.igst) + '</span></div>' : '<div><span>CGST</span><span>' + money(sum.cgst) + '</span></div><div><span>SGST</span><span>' + money(sum.sgst) + '</span></div>') +
    (inv.roundOff ? '<div><span>Round off</span><span>' + money(inv.roundOff, true) + '</span></div>' : '') +
    '<div class="iv-grand"><span>Total</span><span>' + money(inv.total) + '</span></div></div></div>' +
    '<div class="iv-foot"><div>Thank you for your business!</div><div class="iv-sign">For ' + esc(s.shopName) + '<br><br>Authorised signatory</div></div>' +
    '<div class="iv-brand">Made with BahiKhata+</div></div>';
}

/* ---------- PDF ---------- */
async function makeInvoicePdf(inv) {
  await loadScript('js/vendor/qrcode.min.js');
  return makeDocPdf(invoiceHtml(inv), 'Invoice ' + inv.no);
}
// Any A4 document built from .iv-doc HTML (invoices, stock report) becomes a PDF
async function makeDocPdf(html, title) {
  await Promise.all([loadScript('js/vendor/jspdf.umd.min.js'), loadScript('js/vendor/html2canvas.min.js')]);
  const host = document.createElement('div');
  host.className = 'iv-host';
  host.innerHTML = html;
  document.body.appendChild(host);
  try {
    await new Promise((r) => setTimeout(r, 60)); // let the QR image decode
    const canvas = await html2canvas(host.firstChild, { scale: 2, backgroundColor: '#ffffff', logging: false, useCORS: true });
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF({ unit: 'mm', format: 'a4', compress: true });
    const pageW = 210, pageH = 297;
    const imgH = (canvas.height * pageW) / canvas.width;
    if (imgH <= pageH) {
      pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, pageW, imgH);
    } else {
      // Long invoice: slice the image into A4 pages
      const sliceH = Math.floor((canvas.width * pageH) / pageW);
      for (let y = 0, page = 0; y < canvas.height; y += sliceH, page++) {
        const c = document.createElement('canvas');
        c.width = canvas.width;
        c.height = Math.min(sliceH, canvas.height - y);
        c.getContext('2d').drawImage(canvas, 0, -y);
        if (page) pdf.addPage();
        pdf.addImage(c.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, pageW, (c.height * pageW) / canvas.width);
      }
    }
    pdf.setProperties({ title, subject: DB.data.settings.shopName, creator: 'BahiKhata+' });
    return pdf.output('blob');
  } finally {
    host.remove();
  }
}

async function shareInvoicePdf(inv) {
  const blob = await makeInvoicePdf(inv);
  const file = new File([blob], invoiceFileName(inv), { type: 'application/pdf' });
  const text = 'Invoice ' + inv.no + ' from ' + DB.data.settings.shopName + ' · ' + money(inv.total);
  if (isNative()) { await nativeShareFiles([file], text); return 'shared'; }
  try {
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], text, title: file.name });
      return 'shared';
    }
  } catch (e) {
    if (e.name === 'AbortError') return 'cancelled';
  }
  downloadFile(file);
  return 'downloaded';
}

// Stock in hand and the stock report (positive / zero / negative stock), with PDF and CSV export.

const SR_RANGES = [['month', 'This month'], ['last', 'Last month'], ['fy', 'This FY'], ['all', 'All time']];
const SR_FILTERS = [['all', 'All'], ['pos', 'In stock'], ['zero', 'Zero'], ['neg', 'Negative']];

function srRange(key) {
  const t = today();
  if (key === 'last') {
    const d = new Date(Number(t.slice(0, 4)), Number(t.slice(5, 7)) - 2, 1);
    const from = ymd(d);
    return { from, to: addDays(t.slice(0, 8) + '01', -1) };
  }
  if (key === 'fy') {
    const d = new Date();
    const y = d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
    return { from: y + '-04-01', to: t };
  }
  if (key === 'all') return { from: '0000-01-01', to: t };
  return { from: t.slice(0, 8) + '01', to: t };
}

// One row per stock-tracked item: what came in and went out in the period, and what is in hand now
function stockRows(rangeKey) {
  const { from, to } = srRange(rangeKey);
  const inQ = {}, outQ = {};
  for (const p of activePurchases()) {
    if (p.date < from || p.date > to) continue;
    for (const l of p.lines) if (l.itemId) inQ[l.itemId] = (inQ[l.itemId] || 0) + l.qty;
  }
  for (const s of activeSales()) {
    if (s.date < from || s.date > to) continue;
    for (const l of s.lines) if (l.itemId) outQ[l.itemId] = (outQ[l.itemId] || 0) + l.qty;
  }
  return DB.data.items.filter((it) => tracksStock(it)).map((it) => {
    const hand = itemQty(it);
    const cost = Number(it.costPrice) || 0;
    const sale = Number(it.salePrice) || 0;
    return {
      item: it, name: it.name, unit: it.unit || 'PCS', inQty: r2(inQ[it.id] || 0), outQty: r2(outQ[it.id] || 0), hand,
      cost, value: hand > 0 ? r2(hand * cost) : 0, saleValue: hand > 0 ? r2(hand * sale) : 0,
      status: hand > 0 ? 'pos' : hand < 0 ? 'neg' : 'zero',
    };
  }).sort((a, b) => (a.status === 'neg' ? -1 : 0) - (b.status === 'neg' ? -1 : 0) || a.name.localeCompare(b.name));
}
function stockSummary(rows) {
  rows = rows || stockRows('month');
  return {
    pos: rows.filter((r) => r.status === 'pos').length,
    zero: rows.filter((r) => r.status === 'zero').length,
    neg: rows.filter((r) => r.status === 'neg').length,
    value: r2(rows.reduce((a, r) => a + r.value, 0)),
    saleValue: r2(rows.reduce((a, r) => a + r.saleValue, 0)),
    units: r2(rows.reduce((a, r) => a + Math.max(0, r.hand), 0)),
  };
}

/* ---------- Stock tab card ---------- */
function stockHandCard() {
  const sum = stockSummary();
  return '<button class="card stock-hand" data-act="stock-report">' +
    '<div class="row"><span class="label grow">Stock in hand</span><span class="go small">Stock report ›</span></div>' +
    '<div class="sh-grid"><div><span class="sh-v" data-count="' + sum.value + '">' + money(sum.value) + '</span><span class="small muted">value at cost</span></div>' +
    '<div><span class="sh-v">' + money(sum.saleValue) + '</span><span class="small muted">at selling price</span></div></div>' +
    '<div class="row wrap small"><span class="chip good">' + sum.pos + ' in stock</span><span class="chip">' + sum.zero + ' zero</span>' +
    '<span class="chip ' + (sum.neg ? 'bad' : '') + '">' + sum.neg + ' negative</span></div></button>';
}

/* ---------- Report panel ---------- */
function stockReportSheet() {
  const range = UI.srRange || 'month';
  const filter = UI.srFilter || 'all';
  const rows = stockRows(range);
  const sum = stockSummary(rows);
  const shown = rows.filter((r) => filter === 'all' || r.status === filter);
  const count = { all: rows.length, pos: sum.pos, zero: sum.zero, neg: sum.neg };
  const q = (n) => (Number.isInteger(n) ? n : r2(n));
  return {
    title: 'Stock report',
    body:
      '<div class="tiles three"><div class="tile"><span class="label">Value in hand</span><span class="v">' + money(sum.value) + '</span><span class="small muted">at cost</span></div>' +
      '<div class="tile"><span class="label">Items in stock</span><span class="v pos">' + sum.pos + '</span><span class="small muted">of ' + rows.length + '</span></div>' +
      '<div class="tile"><span class="label">Negative</span><span class="v ' + (sum.neg ? 'neg' : '') + '">' + sum.neg + '</span><span class="small muted">items</span></div></div>' +
      '<div class="seg">' + SR_RANGES.map(([k, l]) => '<button class="' + (range === k ? 'on' : '') + '" data-act="sr-range" data-v="' + k + '">' + l + '</button>').join('') + '</div>' +
      '<div class="row wrap">' + SR_FILTERS.map(([k, l]) => '<button class="chip sr-filter' + (filter === k ? ' on' : '') + (k === 'neg' && sum.neg ? ' bad' : '') + '" data-act="sr-filter" data-v="' + k + '">' + l + ' (' + count[k] + ')</button>').join('') + '</div>' +
      (sum.neg ? '<div class="banner">Negative stock means more was sold than recorded. Record the missing purchase, or fix the quantity from the item page.</div>' : '') +
      '<div class="table-wrap card" style="padding:0"><table class="sr-table"><thead><tr><th>Item</th><th class="r">In</th><th class="r">Out</th><th class="r">In hand</th><th class="r">Value</th></tr></thead><tbody>' +
      (shown.length ? shown.map((r) =>
        '<tr data-act="open-item" data-id="' + r.item.id + '"><td><b>' + esc(r.name) + '</b><br><span class="small muted">' + esc(r.unit) + ' · cost ' + money(r.cost) + '</span></td>' +
        '<td class="r">' + q(r.inQty) + '</td><td class="r">' + q(r.outQty) + '</td>' +
        '<td class="r"><b class="' + (r.status === 'neg' ? 'neg' : r.status === 'pos' ? 'pos' : 'muted') + '">' + (r.hand > 0 ? '+' : '') + q(r.hand) + '</b></td>' +
        '<td class="r">' + money(r.value) + '</td></tr>').join('') : '<tr><td colspan="5" class="empty">No items here.</td></tr>') +
      '</tbody><tfoot><tr><td><b>Total (' + shown.length + ' items)</b></td><td class="r">' + q(r2(shown.reduce((a, r) => a + r.inQty, 0))) + '</td><td class="r">' + q(r2(shown.reduce((a, r) => a + r.outQty, 0))) + '</td>' +
      '<td></td><td class="r"><b>' + money(r2(shown.reduce((a, r) => a + r.value, 0))) + '</b></td></tr></tfoot></table></div>' +
      '<p class="small muted">In = bought on purchases, Out = sold on invoices in the chosen period (cancelled ones left out). In hand = stock right now. Value = in-hand quantity × purchase price. Items that don\'t track stock (services) are not listed.</p>' +
      '<div class="inv-actions"><button class="btn wa" data-act="sr-pdf">' + ic('send') + 'Share PDF</button><button class="btn" data-act="sr-csv">' + ic('file') + 'Excel (CSV)</button></div>',
  };
}

/* ---------- PDF and CSV ---------- */
function stockReportHtml() {
  const s = DB.data.settings;
  const range = UI.srRange || 'month';
  const filter = UI.srFilter || 'all';
  const rows = stockRows(range).filter((r) => filter === 'all' || r.status === filter);
  const sum = stockSummary(stockRows(range));
  const { from, to } = srRange(range);
  const label = SR_RANGES.find((x) => x[0] === range)[1] + (range === 'all' ? '' : ' (' + fmtDate(from) + ' – ' + fmtDate(to) + ')');
  const q = (n) => (Number.isInteger(n) ? n : r2(n));
  return '<div class="iv-doc">' +
    '<div class="iv-top"><div><div class="iv-shop">' + esc(s.shopName) + '</div><div class="iv-sub">' + esc([s.city, STATES[s.stateCode]].filter(Boolean).join(', ')) + (s.gstin ? ' · GSTIN ' + esc(s.gstin) : '') + '</div></div>' +
    '<div class="iv-title"><div>STOCK REPORT</div><span class="iv-sub">As on ' + fmtDate(today()) + '</span></div></div>' +
    '<div class="iv-meta"><div><div class="iv-lbl">Movement period</div><div>' + esc(label) + '</div><div class="iv-sub">Showing: ' + esc(SR_FILTERS.find((x) => x[0] === filter)[1]) + '</div></div>' +
    '<div class="iv-right"><div><span class="iv-lbl">Value in hand</span> <b>' + money(sum.value) + '</b></div><div><span class="iv-lbl">In stock / zero / negative</span> <b>' + sum.pos + ' / ' + sum.zero + ' / ' + sum.neg + '</b></div></div></div>' +
    '<table class="iv-table"><thead><tr><th>#</th><th>Item</th><th>Unit</th><th class="r">In</th><th class="r">Out</th><th class="r">In hand</th><th class="r">Cost rate</th><th class="r">Value</th></tr></thead><tbody>' +
    rows.map((r, i) => '<tr><td>' + (i + 1) + '</td><td class="iv-name">' + esc(r.name) + '</td><td>' + esc(r.unit) + '</td><td class="r">' + q(r.inQty) + '</td><td class="r">' + q(r.outQty) + '</td>' +
      '<td class="r" style="font-weight:800;color:' + (r.status === 'neg' ? '#b42318' : r.status === 'pos' ? '#146c43' : '#5b6962') + '">' + (r.hand > 0 ? '+' : '') + q(r.hand) + '</td>' +
      '<td class="r">' + money(r.cost) + '</td><td class="r">' + money(r.value) + '</td></tr>').join('') +
    '</tbody></table>' +
    '<div class="iv-bottom"><div class="iv-words"><div class="iv-lbl">Note</div><div>Negative quantities mean more was sold than recorded in stock.</div></div>' +
    '<div class="iv-totals"><div><span>Items listed</span><span>' + rows.length + '</span></div><div><span>At selling price</span><span>' + money(sum.saleValue) + '</span></div>' +
    '<div class="iv-grand"><span>Value at cost</span><span>' + money(r2(rows.reduce((a, r) => a + r.value, 0))) + '</span></div></div></div>' +
    '<div class="iv-brand">Made with BahiKhata+</div></div>';
}
function stockReportCsv() {
  const range = UI.srRange || 'month';
  const filter = UI.srFilter || 'all';
  const rows = stockRows(range).filter((r) => filter === 'all' || r.status === filter);
  const head = [['Item', 'Unit', 'HSN', 'In (period)', 'Out (period)', 'In hand', 'Status', 'Cost rate', 'Value at cost', 'Selling price', 'Value at selling price']];
  return toCSV(head.concat(rows.map((r) => [r.name, r.unit, r.item.hsn || '', r.inQty, r.outQty, r.hand, { pos: 'In stock', zero: 'Zero', neg: 'Negative' }[r.status],
    r.cost, r.value, Number(r.item.salePrice) || 0, r.saleValue])));
}
async function shareStockReportPdf() {
  const blob = await makeDocPdf(stockReportHtml(), 'Stock report');
  const file = new File([blob], 'Stock_report_' + today() + '.pdf', { type: 'application/pdf' });
  return shareOrDownload([file], 'Stock report · ' + DB.data.settings.shopName);
}

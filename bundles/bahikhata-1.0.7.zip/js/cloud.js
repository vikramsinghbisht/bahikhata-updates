// Daily cloud backup to BahiKhata+ (a Google Apps Script that saves each company's data in the owner's Drive).
// Runs only after the user agrees. The phone never gets Drive access; it only sends its own data.

const Cloud = {
  busy: false,

  url() {
    return ((DB.data && DB.data.settings.cloudUrl) || (typeof CLOUD_BACKUP_URL !== 'undefined' ? CLOUD_BACKUP_URL : '') || '').trim();
  },
  available() { return !!this.url(); },
  enabled() { return this.available() && DB.data.settings.cloudConsent === true; },

  randomHex(bytes) {
    const a = new Uint8Array(bytes);
    crypto.getRandomValues(a);
    return Array.from(a).map((b) => b.toString(16).padStart(2, '0')).join('');
  },
  ensureIds() {
    const s = DB.data.settings;
    if (!s.companyId) s.companyId = this.randomHex(16);
    if (!s.companySecret) s.companySecret = this.randomHex(24);
    DB.save();
  },

  payload() {
    this.ensureIds();
    const s = DB.data.settings;
    const data = DB.snapshot();
    // Never send the PIN, recovery code or this phone's cloud secret inside the backup itself
    for (const k of ['pinHash', 'pinSalt', 'recHash', 'companySecret', 'googleClientId']) delete data.settings[k];
    return {
      companyId: s.companyId,
      secret: s.companySecret,
      date: today(),
      appVersion: typeof APP_VERSION !== 'undefined' ? APP_VERSION : '',
      profile: {
        shopName: s.shopName, ownerName: s.ownerName, phone: s.phone, city: s.city, state: STATES[s.stateCode] || '',
        businessType: currentPreset().label, gstin: s.gstin,
      },
      stats: {
        customers: DB.data.parties.filter((p) => p.type === 'customer').length,
        invoices: DB.data.sales.length,
        items: DB.data.items.length,
      },
      data,
    };
  },

  async backup(manual) {
    if (this.busy) return;
    if (!this.available()) { if (manual) toast('Cloud backup is not set up in this version yet.', 'warn'); return; }
    if (!navigator.onLine) { if (manual) toast('You are offline. The backup will run when you are back online.', 'warn'); return; }
    this.busy = true;
    const m = DB.data.meta;
    try {
      const body = JSON.stringify(this.payload());
      let res;
      try {
        // text/plain keeps this a "simple" request, which Google Apps Script accepts from any app
        res = await fetch(this.url(), { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body, redirect: 'follow' });
      } catch (e) {
        throw new Error('Could not reach the backup server. Check the internet connection.');
      }
      let out = null;
      try { out = await res.json(); } catch (e) { out = null; }
      if (!res.ok || !out || !out.ok) throw new Error((out && out.error) ? 'Backup refused: ' + out.error : 'Backup server returned ' + res.status);
      m.lastCloudBackup = new Date().toISOString();
      m.lastCloudError = null;
      DB.save();
      if (manual) toast('Backed up to the cloud.', 'good');
    } catch (e) {
      m.lastCloudError = e.message;
      DB.save();
      if (manual) toast(e.message, 'bad');
    } finally {
      this.busy = false;
      if (window.renderHeader) renderHeader();
    }
  },

  // Once a day: on app open, when coming back online, and every hour while open
  autoCheck() {
    if (!this.enabled() || !navigator.onLine) return;
    const last = DB.data.meta.lastCloudBackup;
    if (last && ymd(new Date(last)) === today()) return;
    this.backup(false);
  },

  setConsent(on) {
    DB.data.settings.cloudConsent = !!on;
    DB.data.settings.cloudAskedAt = new Date().toISOString();
    if (on) this.ensureIds(); else DB.save();
    if (on) this.backup(false);
  },
};

const CLOUD_NOTICE =
  'Once a day, a copy of this business\'s data (business profile, customers and suppliers with their phone numbers, ledger entries, ' +
  'invoices, stock and expenses) is sent to BahiKhata+ and stored in a private Google Drive run by the BahiKhata+ team, so it can be ' +
  'restored if this phone is lost or damaged. Your PIN is never sent. You can switch this off any time in Settings › Cloud backup.';

function cloudConsentSheet() {
  return {
    title: 'Keep your data safe',
    body:
      '<div class="card stack"><b>Turn on daily cloud backup?</b><span class="small">' + esc(CLOUD_NOTICE) + '</span></div>' +
      '<div class="btns"><button class="btn primary" data-act="cloud-yes">' + ic('cloud') + 'Turn on cloud backup</button>' +
      '<button class="btn" data-act="cloud-no">Not now</button></div>',
  };
}

// Offline mode: app ki files phone mein cache ho jaati hain, isliye bina internet ke bhi app khulta hai.
const CACHE = 'bahikhata-v4';
const SHELL = [
  './', 'index.html', 'manifest.json', 'icons/icon.svg', 'css/app.css', 'css/theme.css', 'css/auth.css', 'css/invoice.css',
  'js/db.js', 'js/logic.js', 'js/cloud.js', 'js/presets.js', 'js/onboarding.js', 'js/invoice.js', 'js/stockreport.js',
  'js/vendor/jspdf.umd.min.js', 'js/vendor/html2canvas.min.js', 'js/vendor/qrcode.min.js', 'js/drive.js', 'js/demo.js', 'js/version.js', 'js/native.js', 'js/app.js',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  // Google login/Drive API ko kabhi cache mat karo
  if (url.hostname.endsWith('googleapis.com') && !url.hostname.startsWith('fonts')) return;
  if (url.hostname === 'accounts.google.com') return;

  const isFont = url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com';
  if (url.origin === location.origin || isFont) {
    // Network pehle (naya version mile), fail ho to cache
    e.respondWith(
      fetch(e.request)
        .then((res) => {
          if (res.ok || res.type === 'opaque') {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(e.request, copy));
          }
          return res;
        })
        .catch(() => caches.match(e.request, { ignoreSearch: true }).then((r) => r || caches.match('index.html')))
    );
  }
});

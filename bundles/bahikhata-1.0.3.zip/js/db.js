// Local-first data store. Sab data phone/computer ke andar (localStorage) rehta hai,
// isliye app bina internet ke bhi poora chalta hai. Har badlav "outbox" mein bhi jaata hai
// taaki internet aane par server se sync ho sake (agar Sync URL set ho).

const DB_KEY = 'bahikhata_v1';

const DB = {
  data: null,

  empty() {
    return {
      version: 1,
      demo: false,
      settings: {
        shopName: '',
        businessType: '',
        city: '',
        defaultGst: 18,
        ownerName: '',
        phone: '',
        gstin: '',
        stateCode: '',
        upi: '',
        invoicePrefix: 'INV/',
        pricesIncludeGst: true,
        verifyMode: 'smart', // off | smart | all
        creditDays: 15,
        expiryAlertDays: 30,
        caName: '',
        caPhone: '',
        caEmail: '',
        syncUrl: '',
        googleClientId: '',
        driveAutoBackup: false,
        driveKeep: 30,
      },
      parties: [],
      txns: [],
      items: [],
      sales: [],
      purchases: [],
      expenses: [],
      outbox: [],
      seq: { invoice: 1 },
      meta: { lastSync: null, lastDriveBackup: null, lastDriveError: null, lastLocalBackup: null },
    };
  },

  load() {
    let parsed = null;
    try {
      const raw = localStorage.getItem(DB_KEY);
      parsed = raw ? JSON.parse(raw) : null;
    } catch (e) {
      parsed = null;
    }
    this.data = parsed || this.empty();
    this.migrate();
    return this.data;
  },

  migrate() {
    const fresh = this.empty();
    for (const k of Object.keys(fresh)) {
      if (this.data[k] === undefined) this.data[k] = fresh[k];
    }
    this.data.settings = Object.assign({}, fresh.settings, this.data.settings);
    this.data.meta = Object.assign({}, fresh.meta, this.data.meta);
    this.data.seq = Object.assign({}, fresh.seq, this.data.seq);
  },

  save() {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(this.data));
      return true;
    } catch (e) {
      console.error('Save failed', e);
      if (window.toast) toast('Could not save. Device storage may be full. Take a backup and clear old data.', 'bad');
      return false;
    }
  },

  id() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  },

  queue(op, coll, rec) {
    if (!this.data.settings.syncUrl) return;
    this.data.outbox.push({ op, coll, id: rec.id, at: new Date().toISOString(), rec: op === 'remove' ? null : rec });
  },

  add(coll, rec) {
    rec.id = rec.id || this.id();
    rec.createdAt = rec.createdAt || new Date().toISOString();
    this.data[coll].push(rec);
    this.queue('add', coll, rec);
    this.save();
    return rec;
  },

  get(coll, id) {
    return this.data[coll].find((r) => r.id === id);
  },

  update(coll, id, patch) {
    const rec = this.get(coll, id);
    if (!rec) return null;
    Object.assign(rec, patch, { updatedAt: new Date().toISOString() });
    this.queue('update', coll, rec);
    this.save();
    return rec;
  },

  remove(coll, id) {
    const i = this.data[coll].findIndex((r) => r.id === id);
    if (i < 0) return;
    const [rec] = this.data[coll].splice(i, 1);
    this.queue('remove', coll, rec);
    this.save();
  },

  snapshot() {
    const copy = JSON.parse(JSON.stringify(this.data));
    copy.outbox = [];
    copy.exportedAt = new Date().toISOString();
    copy.app = 'BahiKhata+';
    return copy;
  },

  restore(obj) {
    if (!obj || !Array.isArray(obj.parties) || !Array.isArray(obj.txns)) {
      throw new Error('This file is not a BahiKhata+ backup.');
    }
    const keepDrive = {
      googleClientId: this.data.settings.googleClientId,
      driveAutoBackup: this.data.settings.driveAutoBackup,
    };
    this.data = obj;
    this.migrate();
    if (!this.data.settings.googleClientId) Object.assign(this.data.settings, keepDrive);
    this.save();
  },
};

// Offline -> online sync. Server ho to outbox POST hota hai; na ho to data sirf is device par rehta hai.
async function syncNow(manual) {
  const s = DB.data.settings;
  if (!navigator.onLine) {
    if (manual) toast('You are offline. Changes will sync automatically when you are back online.', 'warn');
    return;
  }
  if (!s.syncUrl) {
    if (manual) toast('No sync server set. Add a Sync URL in Settings.', 'warn');
    return;
  }
  if (!DB.data.outbox.length) {
    if (manual) toast('Everything is already synced.');
    return;
  }
  const batch = DB.data.outbox.slice();
  try {
    const res = await fetch(s.syncUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ shop: s.shopName, phone: s.phone, changes: batch }),
    });
    if (!res.ok) throw new Error('Server returned ' + res.status);
    DB.data.outbox.splice(0, batch.length);
    DB.data.meta.lastSync = new Date().toISOString();
    DB.save();
    if (manual) toast(batch.length + ' changes synced.', 'good');
  } catch (e) {
    if (manual) toast('Sync failed: ' + e.message, 'bad');
  }
  if (window.renderHeader) renderHeader();
}

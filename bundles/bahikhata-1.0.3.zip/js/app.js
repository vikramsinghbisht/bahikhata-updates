// BahiKhata+: UI. All screens are rendered here.

const $ = (s, r) => (r || document).querySelector(s);

const ICON = {
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 1-3-3z"/><path d="M4 17a3 3 0 0 1 3-3h11"/><path d="M8 8h6"/></svg>',
  box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5"/><path d="M12 13v8"/></svg>',
  wallet: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7h15a3 3 0 0 1 3 3v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 7l12-4v4"/><circle cx="16.5" cy="14" r="1.2"/></svg>',
  chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20H2"/></svg>',
  grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
  mic: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0"/><path d="M12 18v4"/></svg>',
  plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
  x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8.5 8.5 0 0 1-12.6 7.4L3 21l1.6-5.2A8.5 8.5 0 1 1 21 12z"/></svg>',
  phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>',
  cloud: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 19H7a5 5 0 1 1 .9-9.9A6 6 0 0 1 19.5 11 4 4 0 0 1 17.5 19z"/><path d="M12 12v5M9.5 14.5 12 12l2.5 2.5"/></svg>',
  send: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4z"/></svg>',
  file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/></svg>',
  bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
  shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>',
  receipt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 2v20l3-2 2 2 2-2 2 2 2-2 3 2V2l-3 2-2-2-2 2-2-2-2 2z"/><path d="M9 8h6M9 12h6"/></svg>',
};
const ic = (n) => ICON[n] || '';

const UI = {
  tab: 'khata', filter: 'customer', q: '', stockQ: '', gran: 'day',
  gstMonth: today().slice(0, 7), expMonth: today().slice(0, 7),
  stack: [], voice: null, bill: null, purchase: null, offer: null, armed: {},
};

function toast(msg, kind) {
  const box = $('#toast-box');
  box.innerHTML = '<div class="toast ' + (kind || '') + '">' + esc(msg) + '</div>';
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (box.innerHTML = ''), 3800);
}
window.toast = toast;

function applyTheme() {
  const t = DB.data.settings.theme;
  if (t === 'light' || t === 'dark') document.documentElement.setAttribute('data-theme', t);
  else document.documentElement.removeAttribute('data-theme');
}

function relTime(iso) {
  if (!iso) return 'never';
  const d = new Date(iso);
  const t = pad2(d.getHours()) + ':' + pad2(d.getMinutes());
  return ymd(d) === today() ? 'today ' + t : fmtDateShort(ymd(d)) + ' ' + t;
}
const PAY_LABEL = { cash: 'Cash', upi: 'UPI', udhaar: 'Credit' };

/* ================= Header, tabs, FAB ================= */
function renderHeader() {
  const s = DB.data.settings, m = DB.data.meta;
  const chips = [];
  chips.push(navigator.onLine ? '<span>Online</span>' : '<span class="off">Offline · saving on this device</span>');
  if (s.syncUrl && DB.data.outbox.length) chips.push('<span>' + DB.data.outbox.length + ' to sync</span>');
  if (s.driveAutoBackup) {
    const done = m.lastDriveBackup && ymd(new Date(m.lastDriveBackup)) === today();
    chips.push(done ? '<span>Drive backup ' + relTime(m.lastDriveBackup) + '</span>' : '<span class="off">Today\'s Drive backup pending</span>');
  }
  if (DB.data.demo) chips.push('<span class="off">Demo data</span>');
  const h = new Date().getHours();
  const hello = (h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening') + (s.ownerName ? ', ' + s.ownerName.split(' ')[0] : '');
  $('#top').innerHTML =
    '<div class="brand"><span class="hello">' + esc(hello) + '</span><h1>' + esc(s.shopName || 'BahiKhata+') + '</h1><div class="status">' + chips.join('') + '</div></div>' +
    '<button class="icon-btn" data-act="open-settings" aria-label="Settings">' + ic('gear') + '</button>';
}
window.renderHeader = renderHeader;

const TABS = [
  ['khata', 'Ledger', 'book'], ['bills', 'Invoices', 'receipt'], ['stock', 'Stock', 'box'], ['report', 'Reports', 'chart'], ['more', 'More', 'grid'],
];
function renderTabs() {
  $('#tabs').innerHTML = TABS.map(([k, label, icon]) =>
    '<button class="' + (UI.tab === k ? 'on' : '') + '" data-act="tab" data-tab="' + k + '" aria-current="' + (UI.tab === k ? 'page' : 'false') + '">' + ic(icon) + label + '</button>').join('');
}
function renderFabs() {
  const f = $('#fabs');
  if (UI.tab === 'khata' && (DB.data.welcomed || DB.data.parties.length)) {
    f.innerHTML = '<button class="fab mic round" data-act="voice" aria-label="Voice entry" title="Voice entry">' + ic('mic') + '</button>';
  } else f.innerHTML = '';
}

function render() {
  document.body.className = 'tab-' + UI.tab;
  renderHeader();
  renderTabs();
  const view = $('#view');
  view.innerHTML = VIEWS[UI.tab]();
  if (UI.animate) {
    UI.animate = false;
    view.classList.remove('enter');
    void view.offsetWidth;
    view.classList.add('enter');
    countUp(view);
  } else view.classList.remove('enter');
  renderFabs();
}
// Numbers roll up to their value when a screen opens
function countUp(root) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  root.querySelectorAll('[data-count]').forEach((el) => {
    const target = Number(el.dataset.count) || 0;
    const t0 = performance.now(), dur = 700;
    const step = (t) => {
      const k = Math.min(1, (t - t0) / dur);
      el.textContent = money(Math.round(target * (1 - Math.pow(1 - k, 3))));
      if (k < 1) requestAnimationFrame(step); else el.textContent = money(target);
    };
    requestAnimationFrame(step);
  });
}
function avatarClass(name) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return 'av' + (h % 6);
}

/* ================= Sheets (bottom panels) ================= */
function openSheet(fn) { UI.stack.push(fn); renderSheet(); }
function replaceSheet(fn) { UI.stack.pop(); UI.stack.push(fn); renderSheet(); }
function closeSheet() { UI.stack.pop(); renderSheet(); render(); }
function closeAll() { UI.stack = []; renderSheet(); render(); }
function refreshSheet() { renderSheet(true); }
function renderSheet(keepScroll) {
  const root = $('#sheet-root');
  const fn = UI.stack[UI.stack.length - 1];
  if (!fn) { root.innerHTML = ''; document.body.style.overflow = ''; return; }
  const prev = root.querySelector('.sheet');
  const scroll = keepScroll && prev ? prev.scrollTop : 0;
  const s = fn();
  root.innerHTML =
    '<div class="sheet-wrap" data-act="backdrop"><div class="sheet" role="dialog" aria-modal="true" aria-label="' + esc(s.title) + '">' +
    '<div class="sheet-head">' + (UI.stack.length > 1 ? '<button class="icon-btn" data-act="close-sheet" aria-label="Back">' + ic('back') + '</button>' : '') +
    '<h2>' + esc(s.title) + '</h2><button class="icon-btn" data-act="close-all" aria-label="Close">' + ic('x') + '</button></div>' +
    '<div class="sheet-body">' + s.body + '</div></div></div>';
  document.body.style.overflow = 'hidden';
  const sh = root.querySelector('.sheet');
  sh.scrollTop = scroll;
  if (s.mount) s.mount(sh);
}

/* ================= Ledger tab ================= */
function lastTxnDate(pid) {
  let last = null;
  for (const t of DB.data.txns) if (t.partyId === pid && (!last || t.date > last)) last = t.date;
  return last;
}
function initials(name) {
  const t = /[ऀ-ॿ]/.test(name) ? name : name.toUpperCase();
  return t.trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join('');
}
function balLabel(b) { return b > 0 ? 'You\'ll get' : b < 0 ? 'You\'ll give' : 'Settled'; }
function partyRow(p) {
  const b = partyBalance(p.id);
  const st = p.type === 'customer' ? partyStats(p.id) : null;
  const last = lastTxnDate(p.id);
  const chip = st && (b > 0 || st.payments) ? ' · <span class="chip ' + st.rating + '">' + RATING_LABEL[st.rating] + '</span>' : '';
  return '<button class="item" data-act="open-party" data-id="' + p.id + '">' +
    '<span class="avatar ' + avatarClass(p.name) + (p.type === 'supplier' ? ' sup' : '') + '">' + esc(initials(p.name)) + '</span>' +
    '<span class="grow"><span class="t" style="display:block">' + esc(p.name) + '</span><span class="s">' + (last ? fmtDate(last) : 'No entries yet') + chip + '</span></span>' +
    '<span class="amt ' + (b > 0 ? 'pos' : b < 0 ? 'neg' : '') + '">' + (b === 0 ? '—' : money(b)) + '<small>' + balLabel(b) + '</small></span></button>';
}
function partyListHtml() {
  const q = UI.q.trim().toLowerCase();
  const qk = q ? nameKey(q) : '';
  const list = DB.data.parties
    .filter((p) => p.type === UI.filter)
    .filter((p) => !q || p.name.toLowerCase().includes(q) || (p.phone || '').includes(q) || (qk && nameKey(p.name).startsWith(qk)))
    .sort((a, b) => Math.abs(partyBalance(b.id)) - Math.abs(partyBalance(a.id)) || a.name.localeCompare(b.name));
  if (!list.length) return '<div class="empty">' + (q ? 'No party matches that name.' : 'No ' + UI.filter + 's yet. Tap "Party" below to add one.') + '</div>';
  return list.map(partyRow).join('');
}

function welcomeView() {
  return '<div class="card welcome">' +
    '<h2>Welcome! Start your digital ledger</h2>' +
    '<p class="muted">Credit, stock, expenses, profit and GST in one place. Works without internet too.</p>' +
    '<label class="field"><span>Shop name</span><input id="w-shop" value="' + esc(DB.data.settings.shopName) + '"></label>' +
    '<div class="btns"><button class="btn primary" data-act="welcome-start">Start my ledger</button>' +
    '<button class="btn" data-act="welcome-demo">Try with demo data</button></div>' +
    '<p class="small muted">Demo data includes sample customers, stock and bills. You can remove it with one tap from Settings.</p></div>';
}

function khataView() {
  if (!DB.data.welcomed && !DB.data.parties.length) return welcomeView();
  const t = totals();
  const due = reminderList().filter((x) => x.stats.due);
  const pending = DB.data.txns.filter((x) => x.verifyStatus === 'pending').length;
  const disputed = DB.data.txns.filter((x) => x.verifyStatus === 'disputed').length;
  const al = stockAlerts();
  const nudges = [];
  const icon24 = (n) => ic(n).replace('<svg', '<svg width="24" height="24"');
  if (DB.data.demo) nudges.push('<div class="banner">This is demo data, not real accounts.<button class="btn sm" data-act="clear-demo">Remove demo</button></div>');
  if (due.length) {
    const sum = due.reduce((s, x) => s + x.stats.outstanding, 0);
    nudges.push('<button class="nudge" data-act="reminders">' + icon24('bell') +
      '<span><strong>' + due.length + (due.length === 1 ? ' customer needs' : ' customers need') + ' a reminder</strong><span class="small muted">' + money(sum) + ' pending · best time picked from their payment history</span></span><span class="go">View</span></button>');
  }
  if (pending || disputed) {
    const bits = [];
    if (pending) bits.push(pending + ' awaiting customer confirmation');
    if (disputed) bits.push(disputed + ' disputed by customer');
    nudges.push('<button class="nudge info" data-act="verifications">' + icon24('shield') +
      '<span><strong>' + bits.join(' · ') + '</strong><span class="small muted">Two-way verification</span></span><span class="go">View</span></button>');
  }
  if (al.low.length + al.expiring.length + al.expired.length) {
    const bits = [];
    if (al.expired.length) bits.push(al.expired.length + ' expired');
    if (al.expiring.length) bits.push(al.expiring.length + ' expiring soon');
    if (al.low.length) bits.push(al.low.length + ' low on stock');
    nudges.push('<button class="nudge" data-act="tab" data-tab="stock">' + icon24('box') +
      '<span><strong>Stock alerts</strong><span class="small muted">' + bits.join(' · ') + '</span></span><span class="go">View</span></button>');
  }
  const arrow = (dir) => '<span class="arrow ' + dir + '"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">' +
    (dir === 'in' ? '<path d="M17 7 7 17M7 9v8h8"/>' : '<path d="M7 17 17 7M9 7h8v8"/>') + '</svg></span>';
  const qa = (act, cls, icon, label, extra) => '<button data-act="' + act + '"' + (extra || '') + '><span class="qi ' + cls + '">' + ic(icon) + '</span>' + label + '</button>';
  return '<div class="summary"><div><span class="label">' + arrow('in') + 'You\'ll get</span><span class="big pos" data-count="' + t.lena + '">' + money(t.lena) + '</span><span class="small muted">from customers</span></div>' +
    '<div><span class="label">' + arrow('out') + 'You\'ll give</span><span class="big neg" data-count="' + t.dena + '">' + money(t.dena) + '</span><span class="small muted">to suppliers</span></div></div>' +
    '<div class="quick">' + qa('quick-txn', 'q-gave', 'send', 'You gave', ' data-kind="gave"') + qa('quick-txn', 'q-got', 'wallet', 'You got', ' data-kind="got"') +
    qa('new-bill', 'q-bill', 'receipt', 'Invoice') + qa('tab', 'q-exp', 'file', 'Expense', ' data-tab="kharcha"') + '</div>' +
    nudges.join('') +
    '<div class="section"><div class="section-head"><h2>Parties</h2><button class="btn sm" data-act="new-party">' + ic('plus') + 'Add party</button></div><div class="seg" role="tablist">' +
    '<button class="' + (UI.filter === 'customer' ? 'on' : '') + '" data-act="filter" data-v="customer">Customers (' + DB.data.parties.filter((p) => p.type === 'customer').length + ')</button>' +
    '<button class="' + (UI.filter === 'supplier' ? 'on' : '') + '" data-act="filter" data-v="supplier">Suppliers (' + DB.data.parties.filter((p) => p.type === 'supplier').length + ')</button></div>' +
    '<div class="search field">' + ic('search') + '<input id="party-q" type="search" placeholder="Search by name or phone" value="' + esc(UI.q) + '" aria-label="Search parties"></div>' +
    '<div class="list" id="party-list">' + partyListHtml() + '</div></div>';
}

/* ---------- Party detail ---------- */
function verifyChip(t) {
  if (t.verifyStatus === 'pending') return '<span class="chip ok">Awaiting confirmation</span>';
  if (t.verifyStatus === 'confirmed') return '<span class="chip good">Confirmed by customer</span>';
  if (t.verifyStatus === 'disputed') return '<span class="chip bad">Disputed by customer</span>';
  return '';
}
function waLink(phone, text) {
  return 'https://wa.me/' + cleanPhone(phone) + '?text=' + encodeURIComponent(text);
}
function smsLink(phone, text) {
  return 'sms:+' + cleanPhone(phone) + '?body=' + encodeURIComponent(text);
}

function partySheet(pid) {
  const p = DB.get('parties', pid);
  if (!p) return { title: 'Party', body: '<div class="empty">This party no longer exists.</div>' };
  const b = partyBalance(pid);
  const isCust = p.type === 'customer';
  const st = isCust ? partyStats(pid) : null;
  let advice = '';
  if (st && st.outstanding > 0) {
    const a = reminderAdvice(st);
    advice = '<div class="advice"><div class="row"><strong>Smart reminder</strong><span class="chip ' + st.rating + '">' + RATING_LABEL[st.rating] + '</span></div>' +
      '<span class="small">' + esc(a.reason) + ' Oldest unpaid credit is ' + st.age + ' days old.</span><span class="small"><b>' + esc(a.action) + '</b></span></div>';
  } else if (st && st.payments) {
    advice = '<div class="advice"><div class="row"><strong>Payment record</strong><span class="chip ' + st.rating + '">' + RATING_LABEL[st.rating] + '</span></div><span class="small">' + esc(reminderAdvice(Object.assign({}, st, { due: false, oldest: today() })).reason) + '</span></div>';
  }
  const contact = [];
  if (p.phone) {
    contact.push('<a class="btn sm" href="tel:+' + cleanPhone(p.phone) + '">' + ic('phone') + 'Call</a>');
    if (isCust && b > 0) contact.push('<a class="btn sm" target="_blank" rel="noopener" data-act="mark-reminded" data-id="' + p.id + '" href="' + waLink(p.phone, reminderMessage(p)) + '">' + ic('chat') + 'WhatsApp reminder</a>');
  }
  contact.push('<button class="btn sm" data-act="edit-party" data-id="' + p.id + '">Edit party</button>');

  const tx = partyTxns(pid);
  let run = 0;
  const rows = tx.map((t) => { run += t.kind === 'gave' ? t.amount : -t.amount; return { t, run: r2(run) }; }).reverse();
  const txHtml = rows.length
    ? '<div class="list"><div class="tx-head label"><span style="text-align:left;min-width:0">Entry</span><span>You gave</span><span>You got</span></div>' +
      rows.map(({ t, run }) =>
        '<div class="tx" data-act="open-txn" data-id="' + t.id + '" role="button" tabindex="0"><div><div class="small">' + fmtDate(t.date) + ' ' + verifyChip(t) + '</div>' +
        '<div class="small muted">' + (t.note ? esc(t.note) + ' · ' : '') + 'Bal. ' + money(run, true) + '</div></div>' +
        '<div class="col neg">' + (t.kind === 'gave' ? money(t.amount) : '') + '</div><div class="col pos">' + (t.kind === 'got' ? money(t.amount) : '') + '</div></div>').join('') + '</div>'
    : '<div class="empty card">No entries yet. Tap You gave or You got above.</div>';

  return {
    title: p.name,
    body:
      '<div class="card hero-bal"><span class="label">' + balLabel(b) + '</span><div class="big ' + (b > 0 ? 'pos' : b < 0 ? 'neg' : '') + '">' + money(b) + '</div>' +
      '<span class="small muted">' + (isCust ? 'Customer' : 'Supplier') + (p.phone ? ' · ' + esc(p.phone) : ' · no phone number') + '</span></div>' +
      '<div class="btns"><button class="btn gave" data-act="add-txn" data-id="' + p.id + '" data-kind="gave">You gave (credit / payment)</button>' +
      '<button class="btn got" data-act="add-txn" data-id="' + p.id + '" data-kind="got">You got (payment / goods)</button></div>' +
      advice + '<div class="btns">' + contact.join('') + '</div>' + txHtml,
  };
}

function txnFormSheet(pid, kind, pre) {
  const p = DB.get('parties', pid);
  pre = pre || {};
  const verify = needsVerify(p);
  return {
    title: (kind === 'gave' ? 'You gave: ' : 'You got: ') + p.name,
    body:
      '<form class="stack" data-form="txn" data-id="' + pid + '" data-kind="' + kind + '">' +
      '<label class="field"><span>Amount (₹)</span><input name="amount" type="number" inputmode="decimal" step="0.01" min="0.01" required value="' + esc(pre.amount || '') + '"></label>' +
      '<div class="fields"><label class="field"><span>Date</span><input name="date" type="date" value="' + (pre.date || today()) + '" required></label>' +
      '<label class="field"><span>Mode</span><select name="mode"><option value="cash">Cash</option><option value="upi">UPI / Bank</option></select></label></div>' +
      '<label class="field"><span>Note (optional)</span><input name="note" placeholder="e.g. 2 dozen balloons" value="' + esc(pre.note || '') + '"></label>' +
      (verify ? '<p class="small muted">A confirmation message will go to this customer (verification: ' + (p.verify === 'always' ? 'always on' : 'smart mode') + ').</p>' : '') +
      '<button class="btn block ' + kind + '" type="submit">Save</button></form>',
    mount: (sh) => { const i = sh.querySelector('input[name=amount]'); if (i && !i.value) i.focus(); },
  };
}

function createTxn(party, o) {
  const t = {
    partyId: party.id, kind: o.kind, amount: r2(o.amount), date: o.date || today(), note: o.note || '', mode: o.mode || 'cash',
    refType: o.refType || null, refId: o.refId || null, verifyStatus: 'na',
  };
  if (needsVerify(party)) {
    t.verifyStatus = 'pending';
    t.code = String(Math.floor(1000 + Math.random() * 9000));
  }
  return DB.add('txns', t);
}
function afterTxn(t, replace) {
  if (t.verifyStatus === 'pending') {
    const fn = () => verifySheet(t.id);
    if (replace) replaceSheet(fn); else openSheet(fn);
  } else {
    toast((t.kind === 'gave' ? 'You gave ' : 'You got ') + money(t.amount) + ' saved.', 'good');
    if (replace) closeSheet(); else refreshSheet();
  }
}

function verifySheet(tid) {
  const t = DB.get('txns', tid);
  if (!t) return { title: 'Verification', body: '<div class="empty">Entry not found.</div>' };
  const p = DB.get('parties', t.partyId);
  const msg = verifyMessage(t, p);
  const send = p.phone
    ? '<div class="btns"><a class="btn primary" href="' + smsLink(p.phone, msg) + '">' + ic('send') + 'Send SMS</a>' +
      '<a class="btn" target="_blank" rel="noopener" href="' + waLink(p.phone, msg) + '">' + ic('chat') + 'Send on WhatsApp</a></div>'
    : '<div class="banner">' + esc(p.name) + ' has no phone number.<button class="btn sm" data-act="edit-party" data-id="' + p.id + '">Add number</button></div>';
  return {
    title: 'Get customer confirmation',
    body:
      '<p>' + money(t.amount) + ' ' + (t.kind === 'gave' ? 'credit' : 'payment') + ' saved. Send this message to the customer. When they reply "OK ' + t.code + '", tap Confirmed below.</p>' +
      '<label class="field"><span>Message</span><textarea readonly id="verify-msg">' + esc(msg) + '</textarea></label>' + send +
      '<button class="btn sm" data-act="copy" data-target="verify-msg">Copy message</button>' +
      '<div class="section"><span class="label">Customer\'s reply</span><div class="btns">' +
      '<button class="btn got" data-act="verify-set" data-id="' + t.id + '" data-v="confirmed">Replied OK: Confirmed</button>' +
      '<button class="btn gave" data-act="verify-set" data-id="' + t.id + '" data-v="disputed">Customer disputed it</button></div>' +
      '<button class="btn block" data-act="close-sheet">Later</button></div>' +
      '<p class="small muted">Status: ' + (verifyChip(t) || 'Not verified') + '. In smart mode, customers who pay on time are not asked to confirm. You can change this in Settings.</p>',
  };
}

function txnSheet(tid) {
  const t = DB.get('txns', tid);
  if (!t) return { title: 'Entry', body: '<div class="empty">This entry has been deleted.</div>' };
  const p = DB.get('parties', t.partyId);
  const linked = t.refType ? '<p class="small muted">This entry is linked to a ' + (t.refType === 'sale' ? 'bill' : 'purchase') + '. Change it from there.</p>' : '';
  const confirmDel = UI.confirm === 'txn:' + t.id;
  return {
    title: (t.kind === 'gave' ? 'You gave ' : 'You got ') + money(t.amount),
    body:
      '<div class="card stack"><div class="row"><span class="grow muted">Party</span><b>' + esc(p ? p.name : '—') + '</b></div>' +
      '<div class="row"><span class="grow muted">Date</span><b>' + fmtDate(t.date) + '</b></div>' +
      '<div class="row"><span class="grow muted">Mode</span><b>' + (t.mode === 'upi' ? 'UPI / Bank' : 'Cash') + '</b></div>' +
      (t.note ? '<div class="row"><span class="grow muted">Note</span><b>' + esc(t.note) + '</b></div>' : '') +
      '<div class="row"><span class="grow muted">Verification</span>' + (verifyChip(t) || '<span class="chip">Not sent</span>') + '</div></div>' + linked +
      '<div class="btns">' + (p && p.type === 'customer' ? '<button class="btn" data-act="verify-open" data-id="' + t.id + '">' + ic('shield') + (t.verifyStatus === 'na' ? 'Send confirmation' : 'Verification') + '</button>' : '') +
      (t.refType ? '' : '<button class="btn gave" data-act="del-txn" data-id="' + t.id + '">' + (confirmDel ? 'Tap again to delete' : 'Delete') + '</button>') + '</div>',
  };
}

function partyFormSheet(pid, preset) {
  const p = pid ? DB.get('parties', pid) : Object.assign({ type: UI.filter, verify: 'auto' }, preset || {});
  const confirmDel = pid && UI.confirm === 'party:' + pid;
  const stateOpts = '<option value="">Same as my shop (default)</option>' + Object.entries(STATES).map(([c, n]) => '<option value="' + c + '"' + (p.state === c ? ' selected' : '') + '>' + c + ' ' + n + '</option>').join('');
  return {
    title: pid ? 'Edit party' : 'New party',
    body:
      '<form class="stack" data-form="party" data-id="' + (pid || '') + '">' +
      '<div class="seg"><button type="button" class="' + (p.type === 'customer' ? 'on' : '') + '" data-act="ptype" data-v="customer">Customer</button>' +
      '<button type="button" class="' + (p.type === 'supplier' ? 'on' : '') + '" data-act="ptype" data-v="supplier">Supplier</button></div>' +
      '<input type="hidden" name="type" value="' + p.type + '">' +
      '<label class="field"><span>Name</span><input name="name" required value="' + esc(p.name || '') + '" autocomplete="off"></label>' +
      '<label class="field"><span>Mobile number</span><input name="phone" type="tel" inputmode="tel" value="' + esc(p.phone || '') + '" placeholder="10 digits"></label>' +
      '<div class="fields"><label class="field"><span>GSTIN (optional)</span><input name="gstin" maxlength="15" value="' + esc(p.gstin || '') + '" style="text-transform:uppercase"></label>' +
      '<label class="field"><span>State</span><select name="state">' + stateOpts + '</select></label></div>' +
      '<label class="field"><span>Prices on invoices</span><select name="priceType">' +
      '<option value="retail"' + (p.priceType !== 'wholesale' ? ' selected' : '') + '>Retail price</option>' +
      '<option value="wholesale"' + (p.priceType === 'wholesale' ? ' selected' : '') + '>Wholesale price</option></select></label>' +
      '<label class="field"><span>Ask customer to confirm entries</span><select name="verify">' +
      '<option value="auto"' + (p.verify === 'auto' || !p.verify ? ' selected' : '') + '>As per Settings (smart)</option>' +
      '<option value="always"' + (p.verify === 'always' ? ' selected' : '') + '>Always</option>' +
      '<option value="never"' + (p.verify === 'never' ? ' selected' : '') + '>Never (trusted)</option></select></label>' +
      '<button class="btn primary block" type="submit">Save</button></form>' +
      (pid ? '<button class="btn gave" data-act="del-party" data-id="' + pid + '">' + (confirmDel ? 'Tap again: all entries will be deleted too' : 'Delete party') + '</button>' : ''),
  };
}

function pickPartySheet(kind) {
  const q = (UI.pickQ || '').trim().toLowerCase();
  const list = DB.data.parties.filter((p) => !q || p.name.toLowerCase().includes(q) || (p.phone || '').includes(q))
    .sort((a, b) => (lastTxnDate(b.id) || '').localeCompare(lastTxnDate(a.id) || '') || a.name.localeCompare(b.name));
  return {
    title: kind === 'gave' ? 'You gave to…' : 'You got from…',
    body: '<div class="search field">' + ic('search') + '<input id="pick-q" type="search" placeholder="Search party" value="' + esc(UI.pickQ || '') + '" aria-label="Search party"></div>' +
      '<div class="list">' + (list.length ? list.map((p) => '<button class="item" data-act="pick-party" data-kind="' + kind + '" data-id="' + p.id + '"><span class="avatar ' + avatarClass(p.name) + (p.type === 'supplier' ? ' sup' : '') + '">' + esc(initials(p.name)) + '</span>' +
        '<span class="grow"><span class="t" style="display:block">' + esc(p.name) + '</span><span class="s">' + (p.type === 'supplier' ? 'Supplier' : 'Customer') + '</span></span>' +
        '<span class="amt">' + money(partyBalance(p.id)) + '<small>' + balLabel(partyBalance(p.id)) + '</small></span></button>').join('') : '<div class="empty">No party found.</div>') + '</div>' +
      '<button class="btn block" data-act="new-party">' + ic('plus') + 'Add a new party</button>',
    mount: (sh) => { const i = sh.querySelector('#pick-q'); if (i && !('ontouchstart' in window)) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } },
  };
}

function remindersSheet() {
  const list = reminderList();
  const body = list.length ? list.map(({ party: p, stats: st }) => {
    const a = reminderAdvice(st);
    const sentToday = p.lastReminded === today();
    return '<div class="card stack"><div class="row"><span class="avatar">' + esc(initials(p.name)) + '</span><span class="grow"><b>' + esc(p.name) + '</b><br><span class="chip ' + st.rating + '">' + RATING_LABEL[st.rating] + '</span> <span class="small muted">' + st.age + ' days old</span></span>' +
      '<span class="amt pos num" style="font-weight:800">' + money(st.outstanding) + '</span></div>' +
      '<span class="small">' + esc(a.reason) + '</span><span class="small"><b>' + esc(a.action) + '</b></span>' +
      '<div class="btns">' + (p.phone
        ? '<a class="btn sm primary" target="_blank" rel="noopener" data-act="mark-reminded" data-id="' + p.id + '" href="' + waLink(p.phone, reminderMessage(p)) + '">' + ic('chat') + (sentToday ? 'Send again' : 'WhatsApp') + '</a>' +
          '<a class="btn sm" data-act="mark-reminded" data-id="' + p.id + '" href="' + smsLink(p.phone, reminderMessage(p)) + '">SMS</a>'
        : '<button class="btn sm" data-act="edit-party" data-id="' + p.id + '">Add phone number</button>') +
      '<button class="btn sm" data-act="open-party" data-id="' + p.id + '">Ledger</button></div>' +
      (sentToday ? '<span class="small muted">Reminder sent today.</span>' : '') + '</div>';
  }).join('') : '<div class="empty card">No customer has pending credit.</div>';
  return {
    title: 'Smart reminders',
    body: '<p class="small muted">Based on each customer\'s past payments: how many days they usually take, and on which day and time they pay. Most urgent first.</p>' + body,
  };
}

function verificationsSheet() {
  const list = DB.data.txns.filter((t) => t.verifyStatus === 'pending' || t.verifyStatus === 'disputed').sort((a, b) => b.date.localeCompare(a.date));
  return {
    title: 'Customer confirmations',
    body: list.length ? '<div class="list">' + list.map((t) => {
      const p = DB.get('parties', t.partyId);
      return '<button class="item" data-act="verify-open" data-id="' + t.id + '"><span class="grow"><span class="t" style="display:block">' + esc(p ? p.name : '—') + '</span><span class="s">' + fmtDate(t.date) + ' · ' + verifyChip(t) + '</span></span>' +
        '<span class="amt ' + (t.kind === 'gave' ? 'neg' : 'pos') + '">' + money(t.amount) + '<small>' + (t.kind === 'gave' ? 'You gave' : 'You got') + '</small></span></button>';
    }).join('') + '</div>' : '<div class="empty card">No confirmations pending.</div>',
  };
}

/* ---------- Voice entry ---------- */
const VOICE_EXAMPLES = ['Gave 500 to Ramesh', 'Received 1200 from Sunita', 'Ramesh ko 500 udhaar diya', 'Electricity bill 2400 expense', 'विकास से दो हज़ार मिले'];
const VOICE_LANGS = [['en-IN', 'English / Hinglish'], ['hi-IN', 'Hindi']];

function voiceSheet() {
  const v = UI.voice;
  const lang = DB.data.settings.voiceLang || 'en-IN';
  const hasSR = isNative() || !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  let card = '';
  if (v.draft) card = draftCard(v.draft);
  if (v.error) card = '<div class="banner">' + esc(v.error) + '</div>' + card;
  return {
    title: 'Voice entry',
    body:
      '<div class="seg">' + VOICE_LANGS.map(([k, l]) => '<button class="' + (lang === k ? 'on' : '') + '" data-act="v-lang" data-v="' + k + '">' + l + '</button>').join('') + '</div>' +
      '<button class="mic-big ' + (v.listening ? 'live' : '') + '" data-act="mic" aria-label="' + (v.listening ? 'Stop listening' : 'Start speaking') + '">' + ic('mic') + '</button>' +
      '<div class="transcript" aria-live="polite" id="v-transcript">' + (v.listening && !v.text ? '<span class="muted">Listening… speak now</span>' : esc(v.text || '')) + '</div>' +
      (!v.text ? '<p class="small muted" style="text-align:center">Tap the mic and speak in English, Hindi or Hinglish. ' + (hasSR ? (navigator.onLine ? '' : 'Voice needs internet; type below while offline.') : 'Voice is not supported in this browser (use Chrome). You can type below.') + '</p>' +
        '<div class="examples">' + VOICE_EXAMPLES.map((e) => '<button data-act="v-example" data-t="' + esc(e) + '">' + esc(e) + '</button>').join('') + '</div>' : '') +
      '<form class="row" data-form="voice-text"><input class="inp grow" name="t" placeholder="Or type: Gave 500 to Ramesh" value="' + esc(v.typed || '') + '" aria-label="Type an entry"><button class="btn" type="submit">Read</button></form>' +
      card,
  };
}

function draftCard(d) {
  if (d.type === 'expense') {
    return '<form class="card stack parsed" data-form="voice-save">' +
      '<div class="row"><span class="label grow">Understood as an expense</span><button type="button" class="btn sm" data-act="v-switch" data-v="khata">It\'s a ledger entry</button></div>' +
      '<div class="fields"><label class="field"><span>Amount (₹)</span><input name="amount" type="number" step="0.01" min="0.01" required value="' + (d.amount || '') + '"></label>' +
      '<label class="field"><span>Category</span><select name="category">' + expenseCats(d.category).map((c) => '<option' + (c === d.category ? ' selected' : '') + '>' + esc(c) + '</option>').join('') + '</select></label></div>' +
      '<label class="field"><span>Note</span><input name="note" value="' + esc(d.note || '') + '"></label>' +
      '<button class="btn primary block" type="submit">Save expense</button></form>';
  }
  const parties = DB.data.parties.slice().sort((a, b) => a.name.localeCompare(b.name));
  const opts = (d.newName ? '<option value="__new"' + (!d.partyId ? ' selected' : '') + '>Create new party: ' + esc(d.newName) + '</option>' : '<option value="">Choose party</option>') +
    parties.map((p) => '<option value="' + p.id + '"' + (p.id === d.partyId ? ' selected' : '') + '>' + esc(p.name) + (p.type === 'supplier' ? ' (supplier)' : '') + '</option>').join('');
  return '<form class="card stack parsed" data-form="voice-save">' +
    '<div class="row"><span class="label grow">Check and save</span><button type="button" class="btn sm" data-act="v-switch" data-v="expense">It\'s an expense</button></div>' +
    '<div class="seg"><button type="button" class="gave ' + (d.kind === 'gave' ? 'on' : '') + '" data-act="v-kind" data-v="gave">You gave (credit)</button>' +
    '<button type="button" class="got ' + (d.kind === 'got' ? 'on' : '') + '" data-act="v-kind" data-v="got">You got (payment)</button></div>' +
    (d.kindGuessed ? '<p class="small muted">Couldn\'t tell if you gave or got money. Pick the right one above.</p>' : '') +
    '<label class="field"><span>Party</span><select name="party" required>' + opts + '</select></label>' +
    (d.matchedFrom ? '<p class="small muted">Heard "' + esc(d.matchedFrom) + '", matched to ' + esc((DB.get('parties', d.partyId) || {}).name || '') + '.</p>' : '') +
    '<div class="fields"><label class="field"><span>Amount (₹)</span><input name="amount" type="number" step="0.01" min="0.01" required value="' + (d.amount || '') + '"></label>' +
    '<label class="field"><span>Date</span><input name="date" type="date" value="' + d.date + '"></label></div>' +
    '<label class="field"><span>Note</span><input name="note" value="' + esc(d.note || '') + '"></label>' +
    '<button class="btn block ' + d.kind + '" type="submit">Save "' + (d.kind === 'gave' ? 'You gave' : 'You got') + '"</button></form>';
}

function applyVoiceText(text) {
  const v = UI.voice;
  v.text = text;
  v.error = null;
  const r = parseVoice(text);
  if (r.type === 'expense') {
    v.draft = { type: 'expense', amount: r.amount, category: r.category, note: text };
  } else {
    const match = matchParty(r.name);
    v.draft = {
      type: 'khata', kind: r.kind || 'gave', kindGuessed: !r.kind, amount: r.amount,
      partyId: match ? match.id : '', newName: !match && r.name ? titleCase(r.name) : '',
      matchedFrom: match && r.name && nameKey(r.name) !== nameKey(match.name) ? r.name : '', date: today(), note: '',
    };
    if (!r.name && !match) v.error = 'Couldn\'t catch the name. Choose the party below.';
  }
  if (!r.amount) v.error = 'Couldn\'t catch the amount. Enter it below.';
  refreshSheet();
}

let recognizer = null;
async function toggleMicNative() {
  const v = UI.voice;
  if (v.listening) { nativeStopListening(); v.listening = false; refreshSheet(); return; }
  if (!navigator.onLine) { v.error = 'Voice recognition may need internet. While offline, type the entry below.'; }
  v.listening = true; v.text = ''; v.draft = null; v.error = null;
  refreshSheet();
  try {
    const matches = await nativeListen(DB.data.settings.voiceLang || 'en-IN');
    v.listening = false;
    if (!matches.length) { v.error = "Didn't hear anything. Tap the mic and try again."; refreshSheet(); return; }
    let pick = matches[0];
    for (const m of matches) {
      const p = parseVoice(m);
      if (p.amount && (p.type === 'expense' || matchParty(p.name))) { pick = m; break; }
    }
    applyVoiceText(pick.trim());
  } catch (e) {
    v.listening = false;
    v.error = /no match|didn.t understand|no speech/i.test(e.message || '') ? "Didn't catch that. Tap the mic and try again." : e.message;
    refreshSheet();
  }
}
function toggleMic() {
  if (isNative()) return toggleMicNative();
  const v = UI.voice;
  if (v.listening && recognizer) { recognizer.stop(); return; }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { v.error = 'Voice is not supported in this browser. Use Chrome on Android, or type below.'; refreshSheet(); return; }
  if (!navigator.onLine) { v.error = 'Voice recognition needs internet. While offline, type the entry below; it will be saved on this device.'; refreshSheet(); return; }
  recognizer = new SR();
  recognizer.lang = DB.data.settings.voiceLang || 'en-IN';
  recognizer.interimResults = true;
  recognizer.maxAlternatives = 4;
  recognizer.continuous = false;
  v.listening = true; v.text = ''; v.draft = null; v.error = null;
  recognizer.onresult = (e) => {
    let finalText = '', interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const res = e.results[i];
      if (res.isFinal) {
        let pick = res[0].transcript;
        for (let a = 0; a < res.length; a++) {
          const p = parseVoice(res[a].transcript);
          if (p.amount && (p.type === 'expense' || matchParty(p.name))) { pick = res[a].transcript; break; }
        }
        finalText += pick;
      } else interim += res[0].transcript;
    }
    const el = $('#v-transcript');
    if (el) el.textContent = finalText || interim;
    if (finalText) { v.listening = false; applyVoiceText(finalText.trim()); }
  };
  recognizer.onerror = (e) => {
    v.listening = false;
    v.error = {
      'not-allowed': 'Microphone permission was denied. Allow the mic in your browser settings.',
      'service-not-allowed': 'Microphone permission was denied. Allow the mic in your browser settings.',
      'no-speech': 'Didn\'t hear anything. Tap the mic and try again.',
      network: 'Voice needs internet. Type the entry for now.',
      'audio-capture': 'No microphone found.',
    }[e.error] || 'Voice error: ' + e.error;
    refreshSheet();
  };
  recognizer.onend = () => { if (v.listening) { v.listening = false; refreshSheet(); } };
  try { recognizer.start(); } catch (err) { v.listening = false; v.error = 'Could not start the mic: ' + err.message; }
  refreshSheet();
}

/* ================= Stock tab ================= */
function stockView() {
  const al = stockAlerts();
  const q = UI.stockQ.trim().toLowerCase();
  const alertRows = [];
  for (const x of al.expired) alertRows.push(['bad', x.item, 'Expired on ' + fmtDateShort(x.batch.expiry) + ' · remove ' + x.batch.qty + ' ' + (x.item.unit || 'PCS')]);
  for (const x of al.expiring) alertRows.push(['ok', x.item, 'Expires ' + (x.left === 0 ? 'today' : 'in ' + x.left + (x.left === 1 ? ' day' : ' days')) + ' · sell ' + x.batch.qty + ' ' + (x.item.unit || 'PCS') + ' first']);
  for (const x of al.low) alertRows.push(['ok', x.item, 'Low stock: ' + x.qty + ' left (minimum ' + x.item.minQty + ')']);
  const items = DB.data.items.filter((it) => !q || it.name.toLowerCase().includes(q) || (it.hsn || '').includes(q)).sort((a, b) => a.name.localeCompare(b.name));
  const stockValue = DB.data.items.reduce((s, it) => s + itemQty(it) * (Number(it.costPrice) || 0), 0);
  return '<div class="btns"><button class="btn primary" data-act="price-list">' + ic('file') + 'Price list</button>' +
    '<button class="btn" data-act="new-purchase">' + ic('box') + 'Stock in (purchase)</button><button class="btn" data-act="new-item">' + ic('plus') + 'New item</button></div>' +
    (alertRows.length ? '<div class="section"><div class="section-head"><h2>Alerts</h2><span class="small muted">Expiry alert: ' + DB.data.settings.expiryAlertDays + ' days before</span></div><div class="list">' +
      alertRows.map(([k, it, msg]) => '<button class="item" data-act="open-item" data-id="' + it.id + '"><span class="grow"><span class="t" style="display:block">' + esc(it.name) + '</span><span class="chip ' + k + '">' + esc(msg) + '</span></span></button>').join('') + '</div></div>' : '') +
    '<div class="section"><div class="section-head"><h2>All stock</h2><span class="small muted num">Value at cost ' + money(stockValue) + '</span></div>' +
    '<div class="search field">' + ic('search') + '<input id="stock-q" type="search" placeholder="Search items" value="' + esc(UI.stockQ) + '" aria-label="Search items"></div>' +
    '<div class="list" id="stock-list">' + (items.length ? items.map(itemRow).join('') : '<div class="empty">No items yet. Tap "New item".</div>') + '</div></div>';
}
function itemRow(it) {
  const tracked = tracksStock(it);
  const q = itemQty(it);
  const exp = (it.batches || []).filter((b) => b.expiry && b.qty > 0).map((b) => b.expiry).sort()[0];
  const low = tracked && q <= (Number(it.minQty) || 0);
  return '<button class="item" data-act="open-item" data-id="' + it.id + '"><span class="grow"><span class="t" style="display:block">' + esc(it.name) + '</span>' +
    '<span class="s">' + money(it.salePrice) + (it.wholesalePrice ? ' · Wholesale ' + money(it.wholesalePrice) : '') + ' · GST ' + it.gstRate + '%' + (exp ? ' · expires ' + fmtDateShort(exp) : '') + '</span></span>' +
    '<span class="amt ' + (low ? 'neg' : '') + '">' + (tracked ? q : '—') + '<small>' + (tracked ? esc(it.unit || 'PCS') + (low ? ' · low' : '') : 'no stock') + '</small></span></button>';
}
// Price for a customer's price type; falls back to the retail price
function itemPrice(it, type) {
  return type === 'wholesale' && Number(it.wholesalePrice) > 0 ? Number(it.wholesalePrice) : Number(it.salePrice) || 0;
}

const GST_RATES = [0, 5, 18, 40];
// ret = { which: 'bill' | 'purchase', index } when the item is created from inside a bill/purchase line
function itemSheet(id, ret) {
  const it = id ? DB.get('items', id) : Object.assign({ unit: currentPreset().units[0], gstRate: currentPreset().gst, minQty: 5, batches: [], trackStock: !['SERVICE', 'PLATE', 'CUP', 'HOUR'].includes(currentPreset().units[0]) }, ret && ret.name ? { name: ret.name } : {});
  const tracked = it.trackStock !== false;
  const batches = (it.batches || []).slice().sort((a, b) => (a.expiry || '9999').localeCompare(b.expiry || '9999'));
  const retAttr = ret ? ' data-ret="' + ret.which + ':' + ret.index + '"' : '';
  return {
    title: id ? it.name : 'New item',
    body:
      (ret ? '<p class="small muted">After saving, this item will be added to your ' + (ret.which === 'bill' ? 'bill' : 'purchase') + '.</p>' : '') +
      '<form class="stack" data-form="item" data-id="' + (id || '') + '"' + retAttr + '>' +
      '<label class="field"><span>Item name</span><input name="name" required value="' + esc(it.name || '') + '"></label>' +
      '<div class="fields"><label class="field"><span>Unit</span><select name="unit">' + presetUnits().concat(presetUnits().includes(it.unit) ? [] : [it.unit]).map((u) => '<option' + (u === it.unit ? ' selected' : '') + '>' + u + '</option>').join('') + '</select></label>' +
      '<label class="field"><span>HSN code</span><input name="hsn" inputmode="numeric" value="' + esc(it.hsn || '') + '"></label>' +
      '<label class="field"><span>GST %</span><select name="gstRate">' + GST_RATES.map((g) => '<option value="' + g + '"' + (Number(it.gstRate) === g ? ' selected' : '') + '>' + g + '%</option>').join('') + '</select></label></div>' +
      '<div class="fields"><label class="field"><span>Purchase price (excl. GST)</span><input name="costPrice" type="number" step="0.01" min="0" value="' + (it.costPrice ?? '') + '"></label>' +
      '<label class="field"><span>Retail price' + (DB.data.settings.pricesIncludeGst ? ' (incl. GST)' : '') + '</span><input name="salePrice" type="number" step="0.01" min="0" required value="' + (it.salePrice ?? '') + '"></label>' +
      '<label class="field"><span>Wholesale price (optional)</span><input name="wholesalePrice" type="number" step="0.01" min="0" value="' + (it.wholesalePrice || '') + '"></label></div>' +
      '<label class="check"><input type="checkbox" name="trackStock" id="item-track"' + (tracked ? ' checked' : '') + '>Track stock for this item (turn off for services)</label>' +
      '<div class="fields" id="item-stock-fields"' + (tracked ? '' : ' hidden') + '><label class="field"><span>Low-stock alert at (qty)</span><input name="minQty" type="number" step="1" min="0" value="' + (it.minQty ?? 0) + '"></label>' +
      (id || (ret && ret.which === 'purchase') ? '' : '<label class="field"><span>Opening stock</span><input name="openQty" type="number" step="1" min="0" value="0"></label>' +
        '<label class="field"><span>Expiry date (if any)</span><input name="openExpiry" type="date"></label>') + '</div>' +
      '<button class="btn primary block" type="submit">' + (ret ? 'Save and add to ' + (ret.which === 'bill' ? 'bill' : 'purchase') : 'Save') + '</button></form>' +
      (id && tracked ? '<div class="section"><div class="section-head"><h3>In stock: ' + itemQty(it) + ' ' + esc(it.unit) + '</h3></div>' +
        (batches.length ? '<div class="list">' + batches.map((b) => {
          const left = b.expiry ? daysBetween(today(), b.expiry) : null;
          const chip = left == null ? '<span class="chip">No expiry</span>' : left < 0 ? '<span class="chip bad">Expired ' + fmtDateShort(b.expiry) + '</span>' : left <= DB.data.settings.expiryAlertDays ? '<span class="chip ok">' + left + ' days left · ' + fmtDateShort(b.expiry) + '</span>' : '<span class="chip good">' + fmtDate(b.expiry) + '</span>';
          return '<div class="item"><span class="grow">' + chip + '</span><span class="amt">' + b.qty + '</span><button class="btn sm" data-act="batch-remove" data-id="' + it.id + '" data-b="' + b.id + '">Remove</button></div>';
        }).join('') + '</div>' : '') +
        '<form class="card stack" data-form="stock-add" data-id="' + it.id + '"><span class="label">Adjust stock</span><div class="fields">' +
        '<label class="field"><span>Qty (use minus to reduce)</span><input name="qty" type="number" step="1" required></label>' +
        '<label class="field"><span>Expiry (when adding)</span><input name="expiry" type="date"></label></div><button class="btn" type="submit">Update stock</button></form></div>' : '') +
      (id ? '<button class="btn gave" data-act="del-item" data-id="' + it.id + '">' + (UI.confirm === 'item:' + it.id ? 'Tap again to delete' : 'Delete item') + '</button>' : ''),
    mount: (sh) => { if (!id) { const i = sh.querySelector('input[name=name]'); if (i && !i.value) i.focus(); } },
  };
}

/* ---------- Bill (sale) & purchase ---------- */
function computeDoc(st, isPurchase) {
  const s = DB.data.settings;
  const inter = !!(st.pos && s.stateCode && st.pos !== s.stateCode);
  const lines = st.lines.filter((l) => l.itemId && Number(l.qty) > 0 && DB.get('items', l.itemId)).map((l) => {
    const it = DB.get('items', l.itemId);
    const g = isPurchase ? Number(l.gstRate) : Number(it.gstRate) || 0;
    const line = calcLine(it, Number(l.qty), Number(l.rate) || 0, g, st.inclusive, inter);
    if (isPurchase) line.expiry = l.expiry || '';
    else line.cost = Number(it.costPrice) || 0;
    return line;
  });
  const sum = lines.reduce((a, l) => ({ taxable: a.taxable + l.taxable, cgst: a.cgst + l.cgst, sgst: a.sgst + l.sgst, igst: a.igst + l.igst, total: a.total + l.total }), { taxable: 0, cgst: 0, sgst: 0, igst: 0, total: 0 });
  for (const k in sum) sum[k] = r2(sum[k]);
  const rounded = Math.round(sum.total);
  return { lines, sum, inter, rounded, roundOff: r2(rounded - sum.total) };
}
function totalsHtml(which) {
  const isP = which === 'purchase';
  const c = computeDoc(isP ? UI.purchase : UI.bill, isP);
  const row = (k, v, cls) => '<span class="' + (cls || 'muted') + '">' + k + '</span><span class="' + (cls || '') + '">' + money(v) + '</span>';
  return row('Taxable value', c.sum.taxable) + (c.inter ? row('IGST', c.sum.igst) : row('CGST', c.sum.cgst) + row('SGST', c.sum.sgst)) +
    (c.roundOff ? row('Round off', c.roundOff) : '') + row('Total', c.rounded, 'grand');
}
function docLinesHtml(which) {
  const isP = which === 'purchase';
  const st = isP ? UI.purchase : UI.bill;
  const itemOpts = (sel) => '<option value="">Choose item</option><option value="__new">+ Create new item</option>' + DB.data.items.slice().sort((a, b) => a.name.localeCompare(b.name))
    .map((it) => '<option value="' + it.id + '"' + (it.id === sel ? ' selected' : '') + '>' + esc(it.name) + (isP ? '' : ' · ' + money(itemPrice(it, st.priceType)) + (tracksStock(it) ? ' (' + itemQty(it) + ' in stock)' : '')) + '</option>').join('');
  return st.lines.map((l, i) => {
    const it = l.itemId && DB.get('items', l.itemId);
    const warn = !isP && it && tracksStock(it) && Number(l.qty) > itemQty(it) ? '<span class="chip bad full">Only ' + itemQty(it) + ' in stock</span>' : '';
    const listPrice = !isP && it ? itemPrice(it, st.priceType) : null;
    const edited = listPrice != null && Number(l.rate) !== listPrice ? '<span class="chip ok full">Price changed from list price ' + money(listPrice) + '</span>' : '';
    return '<div class="line"><label class="field full"><span>Item</span><select data-bind="' + which + '.lines.' + i + '.itemId" data-rerender>' + itemOpts(l.itemId) + '</select></label>' +
      '<label class="field"><span>Qty</span><input type="number" step="1" min="0" inputmode="numeric" data-bind="' + which + '.lines.' + i + '.qty" data-num value="' + l.qty + '"></label>' +
      '<label class="field"><span>Rate' + (isP ? ' (excl. GST)' : '') + '</span><input type="number" step="0.01" min="0" inputmode="decimal" data-bind="' + which + '.lines.' + i + '.rate" data-num value="' + l.rate + '"></label>' +
      (isP ? '<label class="field"><span>GST %</span><select data-bind="' + which + '.lines.' + i + '.gstRate" data-num>' + GST_RATES.map((g) => '<option value="' + g + '"' + (Number(l.gstRate) === g ? ' selected' : '') + '>' + g + '%</option>').join('') + '</select></label>' +
        '<label class="field"><span>Expiry</span><input type="date" data-bind="' + which + '.lines.' + i + '.expiry" value="' + (l.expiry || '') + '"></label>' : '<span></span>') +
      '<button type="button" class="btn sm" data-act="line-del" data-w="' + which + '" data-i="' + i + '" aria-label="Remove line">' + ic('x') + '</button>' + warn + edited + '</div>';
  }).join('');
}
function docLineButtons(which) {
  return '<div class="btns"><button class="btn" data-act="line-add" data-w="' + which + '">' + ic('plus') + 'Add line</button>' +
    '<button class="btn" data-act="line-new-item" data-w="' + which + '">' + ic('box') + 'Create new item</button></div>';
}
function stateSelect(bind, val) {
  return '<select data-bind="' + bind + '" data-rerender>' + Object.entries(STATES).map(([c, n]) => '<option value="' + c + '"' + (val === c ? ' selected' : '') + '>' + c + ' ' + n + '</option>').join('') + '</select>';
}
function openItemFromLine(which, index) {
  openSheet(() => itemSheet(null, { which, index }));
}

function billSheet() {
  const b = UI.bill;
  const custs = DB.data.parties.filter((p) => p.type === 'customer').sort((a, c) => a.name.localeCompare(c.name));
  return {
    title: 'New invoice · ' + DB.data.settings.invoicePrefix + DB.data.seq.invoice,
    body:
      '<label class="field"><span>Customer</span><select data-bind="bill.partyId" data-rerender><option value="">Walk-in customer</option>' +
      custs.map((p) => '<option value="' + p.id + '"' + (p.id === b.partyId ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') + '</select></label>' +
      (b.partyId ? '' : '<div class="fields"><label class="field"><span>Customer name (optional)</span><input data-bind="bill.customerName" value="' + esc(b.customerName) + '"></label>' +
        '<label class="field"><span>Mobile (to send on WhatsApp)</span><input type="tel" inputmode="tel" data-bind="bill.customerPhone" value="' + esc(b.customerPhone || '') + '" placeholder="10 digits"></label></div>') +
      '<div class="row"><span class="label grow">Price list</span><div class="seg" style="flex:0 0 auto">' +
      [['retail', 'Retail'], ['wholesale', 'Wholesale']].map(([k, l]) => '<button class="' + (b.priceType === k ? 'on' : '') + '" data-act="price-type" data-v="' + k + '">' + l + '</button>').join('') + '</div></div>' +
      '<div class="fields"><label class="field"><span>Customer GSTIN (for B2B)</span><input data-bind="bill.gstin" maxlength="15" style="text-transform:uppercase" value="' + esc(b.gstin) + '"></label>' +
      '<label class="field"><span>Place of supply</span>' + stateSelect('bill.pos', b.pos) + '</label>' +
      '<label class="field"><span>Date</span><input type="date" data-bind="bill.date" value="' + b.date + '"></label></div>' +
      '<div class="lines">' + docLinesHtml('bill') + '</div>' + docLineButtons('bill') +
      '<label class="check"><input type="checkbox" data-bind="bill.inclusive" data-rerender' + (b.inclusive ? ' checked' : '') + '>Rates include GST</label>' +
      '<div class="card totals" id="totals-bill">' + totalsHtml('bill') + '</div>' +
      '<div class="seg">' + ['cash', 'upi', 'udhaar'].map((m) => '<button class="' + (b.payMode === m ? 'on' : '') + '" data-act="paymode" data-w="bill" data-v="' + m + '">' + PAY_LABEL[m] + '</button>').join('') + '</div>' +
      (b.payMode === 'udhaar' && !b.partyId ? '<p class="small muted">For a credit sale, choose a customer or type a name. A new name creates a new party.</p>' : '') +
      '<p class="small muted">Rates come from your price list. You can change any rate for this invoice.</p>' +
      '<button class="btn primary block" data-act="save-bill">' + ic('receipt') + 'Create invoice</button>',
  };
}

function applyPriceType(type) {
  const b = UI.bill;
  if (!b) return;
  b.priceType = type;
  for (const l of b.lines) {
    const it = l.itemId && DB.get('items', l.itemId);
    if (it) l.rate = itemPrice(it, type);
  }
}

/* ---------- Invoices tab ---------- */
function invoiceListHtml() {
  const q = (UI.invQ || '').trim().toLowerCase();
  const list = DB.data.sales.filter((s) => !q || (s.no || '').toLowerCase().includes(q) || (s.customerName || '').toLowerCase().includes(q))
    .sort((a, b) => b.date.localeCompare(a.date) || (b.createdAt || '').localeCompare(a.createdAt || '')).slice(0, 150);
  if (!list.length) return '<div class="empty">' + (q ? 'No invoice matches.' : 'No invoices yet. Tap "New invoice" to create your first one.') + '</div>';
  return list.map((s) => {
    const st = invoiceStatus(s);
    return '<button class="item" data-act="inv-open" data-id="' + s.id + '"><span class="avatar ' + avatarClass(s.customerName || s.no) + '">' + ic('receipt').replace('<svg', '<svg width="20" height="20"') + '</span>' +
      '<span class="grow"><span class="t" style="display:block">' + esc(s.no) + ' · ' + esc(s.customerName || 'Walk-in') + '</span><span class="s">' + fmtDate(s.date) + ' · <span class="chip ' + st.cls + '">' + esc(st.label) + '</span></span></span>' +
      '<span class="amt' + (s.cancelled ? ' muted' : '') + '"' + (s.cancelled ? ' style="text-decoration:line-through"' : '') + '>' + money(s.total) + '<small>' + s.lines.length + (s.lines.length === 1 ? ' item' : ' items') + '</small></span></button>';
  }).join('');
}
function invoicesView() {
  const ym = today().slice(0, 7);
  const month = activeSales().filter((s) => inMonth(s.date, ym));
  const total = month.reduce((a, s) => a + s.total, 0);
  const credit = month.filter((s) => s.payMode === 'udhaar').reduce((a, s) => a + s.total, 0);
  const todays = activeSales().filter((s) => s.date === today()).reduce((a, s) => a + s.total, 0);
  return '<button class="hero-cta" data-act="new-bill">' + ic('receipt') + '<span><b>New invoice</b><span>Price list rates fill in automatically · PDF on WhatsApp in one tap</span></span></button>' +
    '<div class="tiles three"><div class="tile"><span class="label">Today</span><span class="v" data-count="' + todays + '">' + money(todays) + '</span></div>' +
    '<div class="tile"><span class="label">This month</span><span class="v" data-count="' + total + '">' + money(total) + '</span><span class="small muted">' + month.length + ' invoices</span></div>' +
    '<div class="tile"><span class="label">On credit</span><span class="v neg" data-count="' + credit + '">' + money(credit) + '</span><span class="small muted">this month</span></div></div>' +
    '<div class="section"><div class="section-head"><h2>All invoices</h2><button class="btn sm" data-act="price-list">' + ic('file') + 'Price list</button></div>' +
    '<div class="search field">' + ic('search') + '<input id="inv-q" type="search" placeholder="Search invoice no. or customer" value="' + esc(UI.invQ || '') + '" aria-label="Search invoices"></div>' +
    '<div class="list" id="inv-list">' + invoiceListHtml() + '</div></div>';
}

function invoiceSheet(id, justCreated) {
  const inv = DB.get('sales', id);
  if (!inv) return { title: 'Invoice', body: '<div class="empty">Invoice not found.</div>' };
  const phone = invoicePhone(inv);
  const text = invoiceText(inv);
  const wa = phone ? waLink(phone, text) : 'https://wa.me/?text=' + encodeURIComponent(text);
  const st = invoiceStatus(inv);
  return {
    title: (justCreated ? 'Invoice created · ' : 'Invoice ') + inv.no,
    body:
      pendingVerifyBanner(inv) +
      (justCreated ? '<div class="card hero-bal"><span class="label">Total</span><div class="big">' + money(inv.total) + '</div><span class="small muted">' + esc(inv.customerName || 'Walk-in customer') + ' · ' + esc(st.label) + '</span></div>' : '') +
      '<div class="inv-actions"><button class="btn wa" data-act="inv-pdf" data-id="' + inv.id + '">' + ic('send') + 'Share PDF</button>' +
      '<a class="btn primary" target="_blank" rel="noopener" href="' + wa + '">' + ic('chat') + (phone ? 'WhatsApp details' : 'WhatsApp text') + '</a></div>' +
      '<p class="small muted">' + (phone ? '"WhatsApp details" opens the chat with +91 ' + esc(phone) + '. ' : 'Add the customer\'s mobile number to open their chat directly. ') +
      '"Share PDF" opens the share menu: pick WhatsApp, then the customer.</p>' +
      '<div class="iv-preview" id="iv-preview">' + invoiceHtml(inv) + '</div>' +
      '<div class="btns"><button class="btn" data-act="new-bill-again">' + ic('plus') + 'New invoice</button>' +
      (inv.cancelled ? '' : '<button class="btn gave" data-act="inv-cancel" data-id="' + inv.id + '">' + (UI.confirm === 'inv:' + inv.id ? 'Tap again to cancel invoice' : 'Cancel invoice') + '</button>') + '</div>',
    mount: (sh) => {
      loadScript('js/vendor/qrcode.min.js').then(() => {
        const box = sh.querySelector('#iv-preview');
        if (!box) return;
        box.innerHTML = invoiceHtml(inv);
        const doc = box.firstChild;
        const k = box.clientWidth / 794;
        doc.style.transform = 'scale(' + k + ')';
        box.style.height = Math.ceil(doc.offsetHeight * k) + 'px';
      }).catch(() => {});
      const box = sh.querySelector('#iv-preview');
      const doc = box.firstChild;
      const k = box.clientWidth / 794;
      doc.style.transform = 'scale(' + k + ')';
      box.style.height = Math.ceil(doc.offsetHeight * k) + 'px';
    },
  };
}

function pendingVerifyBanner(inv) {
  const t = DB.data.txns.find((x) => x.refType === 'sale' && x.refId === inv.id && x.verifyStatus === 'pending');
  return t ? '<div class="banner">Ask the customer to confirm this credit.<button class="btn sm" data-act="verify-open" data-id="' + t.id + '">Send confirmation</button></div>' : '';
}
// Cancelling keeps the invoice number (GST rule: no gaps) but reverses stock and the customer's credit
function cancelInvoice(id) {
  const inv = DB.get('sales', id);
  if (!inv || inv.cancelled) return;
  for (const l of inv.lines) {
    const it = l.itemId && DB.get('items', l.itemId);
    if (it && tracksStock(it)) DB.update('items', it.id, { batches: (it.batches || []).concat([{ id: DB.id(), qty: l.qty, expiry: '' }]) });
  }
  DB.data.txns.filter((t) => t.refType === 'sale' && t.refId === id).forEach((t) => DB.remove('txns', t.id));
  DB.update('sales', id, { cancelled: true, cancelledAt: new Date().toISOString() });
}

/* ---------- Price list ---------- */
function priceRowsHtml() {
  const q = (UI.priceQ || '').trim().toLowerCase();
  const items = DB.data.items.filter((it) => !q || it.name.toLowerCase().includes(q)).sort((a, b) => a.name.localeCompare(b.name));
  if (!items.length) return '<div class="empty">' + (q ? 'No item matches.' : 'No items yet. Add your first item.') + '</div>';
  return items.map((it) => '<div class="price-row"><span><span class="t" style="display:block">' + esc(it.name) + '</span><span class="small muted">' + esc(it.unit || '') + ' · GST ' + it.gstRate + '%</span></span>' +
    '<input type="number" step="0.01" min="0" inputmode="decimal" data-price="' + it.id + ':salePrice" value="' + (it.salePrice || '') + '" aria-label="Retail price of ' + esc(it.name) + '">' +
    '<input type="number" step="0.01" min="0" inputmode="decimal" data-price="' + it.id + ':wholesalePrice" value="' + (it.wholesalePrice || '') + '" placeholder="—" aria-label="Wholesale price of ' + esc(it.name) + '"></div>').join('');
}
function priceListSheet() {
  return {
    title: 'Price list',
    body: '<p class="small muted">Set a fixed price for each item. Invoices fill these in automatically (wholesale for customers marked Wholesale), and you can still change a rate on any invoice. Changes save as you type.</p>' +
      '<div class="search field">' + ic('search') + '<input id="price-q" type="search" placeholder="Search items" value="' + esc(UI.priceQ || '') + '" aria-label="Search items"></div>' +
      '<div class="list"><div class="price-row price-head"><span>Item</span><span>Retail ₹</span><span>Wholesale ₹</span></div><div id="price-rows">' + priceRowsHtml() + '</div></div>' +
      '<button class="btn block" data-act="new-item">' + ic('plus') + 'Add item</button>',
  };
}

function purchaseSheet() {
  const b = UI.purchase;
  const sups = DB.data.parties.filter((p) => p.type === 'supplier').sort((a, c) => a.name.localeCompare(c.name));
  return {
    title: 'Stock in (purchase)',
    body:
      '<label class="field"><span>Supplier</span><select data-bind="purchase.partyId" data-rerender><option value="">New / unnamed</option>' +
      sups.map((p) => '<option value="' + p.id + '"' + (p.id === b.partyId ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') + '</select></label>' +
      (b.partyId ? '' : '<label class="field"><span>Supplier name</span><input data-bind="purchase.supplierName" value="' + esc(b.supplierName) + '"></label>') +
      '<div class="fields"><label class="field"><span>Supplier GSTIN (for ITC)</span><input data-bind="purchase.gstin" maxlength="15" style="text-transform:uppercase" value="' + esc(b.gstin) + '"></label>' +
      '<label class="field"><span>Supplier bill no.</span><input data-bind="purchase.invNo" value="' + esc(b.invNo) + '"></label>' +
      '<label class="field"><span>Supplier state</span>' + stateSelect('purchase.pos', b.pos) + '</label>' +
      '<label class="field"><span>Date</span><input type="date" data-bind="purchase.date" value="' + b.date + '"></label></div>' +
      '<div class="lines">' + docLinesHtml('purchase') + '</div>' + docLineButtons('purchase') +
      '<div class="card totals" id="totals-purchase">' + totalsHtml('purchase') + '</div>' +
      '<div class="seg">' + ['cash', 'upi', 'udhaar'].map((m) => '<button class="' + (b.payMode === m ? 'on' : '') + '" data-act="paymode" data-w="purchase" data-v="' + m + '">' + { cash: 'Paid cash', upi: 'Paid UPI', udhaar: 'On credit' }[m] + '</button>').join('') + '</div>' +
      '<button class="btn primary block" data-act="save-purchase">Save purchase</button>',
  };
}

/* ================= Expenses tab ================= */
function shiftMonth(ym, n) {
  const d = new Date(Number(ym.slice(0, 4)), Number(ym.slice(5, 7)) - 1 + n, 1);
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1);
}
function monthLabel(ym) { return MONTHS[Number(ym.slice(5, 7)) - 1] + ' ' + ym.slice(0, 4); }
function kharchaView() {
  const ym = UI.expMonth;
  const list = DB.data.expenses.filter((e) => inMonth(e.date, ym)).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));
  const total = r2(list.reduce((s, e) => s + e.amount, 0));
  const prevTotal = r2(DB.data.expenses.filter((e) => inMonth(e.date, shiftMonth(ym, -1))).reduce((s, e) => s + e.amount, 0));
  const byCat = {};
  for (const e of list) byCat[e.category] = (byCat[e.category] || 0) + e.amount;
  const cats = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
  const max = cats.length ? cats[0][1] : 1;
  return '<div class="row"><button class="btn sm" data-act="exp-month" data-n="-1" aria-label="Previous month">' + ic('back') + '</button>' +
    '<h2 class="grow" style="text-align:center">' + monthLabel(ym) + '</h2><button class="btn sm" data-act="exp-month" data-n="1" aria-label="Next month" ' + (ym >= today().slice(0, 7) ? 'disabled' : '') + '><span style="display:inline-block;transform:scaleX(-1)">' + ic('back') + '</span></button></div>' +
    '<div class="tiles"><div class="tile"><span class="label">This month</span><span class="v neg">' + money(total) + '</span></div>' +
    '<div class="tile"><span class="label">Last month</span><span class="v">' + money(prevTotal) + '</span><span class="small muted">' + (prevTotal ? (total >= prevTotal ? '+' : '−') + Math.abs(Math.round(((total - prevTotal) / prevTotal) * 100)) + '% vs last month' : '') + '</span></div></div>' +
    '<form class="card stack" data-form="expense"><span class="label">Add expense</span>' +
    '<div class="fields"><label class="field"><span>Amount (₹)</span><input name="amount" type="number" step="0.01" min="0.01" required inputmode="decimal"></label>' +
    '<label class="field"><span>Category</span><select name="category">' + expenseCats().map((c) => '<option>' + esc(c) + '</option>').join('') + '</select></label>' +
    '<label class="field"><span>Date</span><input name="date" type="date" value="' + today() + '"></label>' +
    '<label class="field"><span>Paid by</span><select name="mode"><option value="cash">Cash</option><option value="upi">UPI / Bank</option></select></label></div>' +
    '<label class="field"><span>Note (optional)</span><input name="note" placeholder="e.g. Shop rent for September"></label>' +
    '<button class="btn primary" type="submit">Add expense</button><span class="small muted">Tip: on the Ledger tab you can also tap the mic and say "Electricity bill 2400 expense".</span></form>' +
    (cats.length ? '<div class="card stack"><span class="label">By category</span>' + cats.map(([c, v]) =>
      '<div class="bar-row"><span>' + esc(c) + '</span><span class="track"><span class="fill" style="display:block;width:' + Math.max(3, (v / max) * 100) + '%"></span></span><span class="num">' + money(v) + '</span></div>').join('') + '</div>' : '') +
    '<div class="list">' + (list.length ? list.map((e) =>
      '<div class="item"><span class="grow"><span class="t" style="display:block">' + esc(e.category) + (e.note ? ' · <span class="muted">' + esc(e.note) + '</span>' : '') + '</span><span class="s">' + fmtDate(e.date) + ' · ' + (e.mode === 'upi' ? 'UPI' : 'Cash') + '</span></span>' +
      '<span class="amt neg">' + money(e.amount) + '</span><button class="btn sm" data-act="del-exp" data-id="' + e.id + '" aria-label="Delete">' + (UI.confirm === 'exp:' + e.id ? 'Delete?' : ic('x')) + '</button></div>').join('') : '<div class="empty">No expenses this month.</div>') + '</div>';
}

/* ================= Reports tab ================= */
function shortMoney(v) {
  const a = Math.abs(v), sign = v < 0 ? '−' : '';
  if (a >= 100000) return sign + '₹' + r2(a / 100000) + 'L';
  if (a >= 1000) return sign + '₹' + Math.round(a / 100) / 10 + 'k';
  return sign + '₹' + Math.round(a);
}
function niceStep(range) {
  const raw = range / 4 || 1;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / mag;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * mag;
}
function profitChart(series) {
  const W = 640, H = 240, L = 56, R = 12, T = 14, B = 30;
  const hi = Math.max(0, ...series.map((s) => Math.max(s.net, s.sales)));
  const lo = Math.min(0, ...series.map((s) => s.net));
  const step = niceStep(hi - lo);
  const top = Math.ceil(hi / step) * step || step;
  const bot = Math.floor(lo / step) * step;
  const y = (v) => T + ((top - v) / (top - bot)) * (H - T - B);
  const n = series.length;
  const bw = (W - L - R) / n;
  let g = '';
  for (let v = bot; v <= top + 0.001; v += step) {
    g += '<line class="grid" x1="' + L + '" x2="' + (W - R) + '" y1="' + y(v) + '" y2="' + y(v) + '"/><text x="' + (L - 6) + '" y="' + (y(v) + 4) + '" text-anchor="end">' + shortMoney(v) + '</text>';
  }
  let bars = '', pts = [], labels = '';
  const every = n > 10 ? 2 : 1;
  series.forEach((s, i) => {
    const cx = L + bw * i + bw / 2, w = bw * 0.5;
    const y0 = y(0), y1 = y(s.net);
    bars += '<rect class="' + (s.net >= 0 ? 'bar-pos' : 'bar-neg') + '" x="' + (cx - w / 2) + '" y="' + Math.min(y0, y1) + '" width="' + w + '" height="' + Math.max(1, Math.abs(y1 - y0)) + '" rx="3"><title>' + s.label + ': net ' + money(s.net, true) + ', sales ' + money(s.sales) + '</title></rect>';
    pts.push(cx + ',' + y(s.sales));
    if (i % every === (n - 1) % every) labels += '<text x="' + cx + '" y="' + (H - 10) + '" text-anchor="middle">' + esc(s.label) + '</text>';
  });
  const dots = series.map((s, i) => '<circle class="dot" cx="' + (L + bw * i + bw / 2) + '" cy="' + y(s.sales) + '" r="' + (i === n - 1 ? 4 : 2.5) + '"/>').join('');
  const defs = '<defs><linearGradient id="gPos" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--got)"/><stop offset="1" stop-color="var(--got)" stop-opacity="0.55"/></linearGradient>' +
    '<linearGradient id="gNeg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--gave)" stop-opacity="0.55"/><stop offset="1" stop-color="var(--gave)"/></linearGradient></defs>';
  return '<div class="chart"><svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Profit chart">' + defs + g +
    '<line class="zero" x1="' + L + '" x2="' + (W - R) + '" y1="' + y(0) + '" y2="' + y(0) + '"/>' + bars +
    '<polyline class="sales" points="' + pts.join(' ') + '"/>' + dots + labels + '</svg></div>' +
    '<div class="legend"><span><i style="background:var(--got)"></i>Net profit</span><span><i style="background:var(--gave)"></i>Loss</span><span><i style="background:var(--accent)"></i>Sales (excl. GST)</span></div>';
}

function reportView() {
  const gran = UI.gran;
  const series = profitSeries(gran);
  const sum = series.reduce((a, s) => ({ sales: a.sales + s.sales, cogs: a.cogs + s.cogs, expense: a.expense + s.expense, net: a.net + s.net }), { sales: 0, cogs: 0, expense: 0, net: 0 });
  const last = series[series.length - 1];
  const rangeLabel = { day: 'Last 14 days', week: 'Last 8 weeks', month: 'Last 6 months' }[gran];
  const lastLabel = { day: 'Today\'s', week: 'This week\'s', month: 'This month\'s' }[gran];
  const ym = UI.gstMonth;
  const g3 = gstr3b(ym);
  const g1 = gstr1(ym);
  const s = DB.data.settings;
  return '<div class="section"><div class="section-head"><h2>Profit &amp; loss</h2><span class="small muted">' + rangeLabel + '</span></div>' +
    '<div class="seg">' + [['day', 'Daily'], ['week', 'Weekly'], ['month', 'Monthly']].map(([k, l]) => '<button class="' + (gran === k ? 'on' : '') + '" data-act="gran" data-v="' + k + '">' + l + '</button>').join('') + '</div>' +
    '<div class="tiles"><div class="tile"><span class="label">' + lastLabel + ' profit</span><span class="v ' + (last.net >= 0 ? 'pos' : 'neg') + '">' + money(last.net, true) + '</span><span class="small muted">Sales ' + money(last.sales) + '</span></div>' +
    '<div class="tile"><span class="label">Total sales</span><span class="v">' + money(sum.sales) + '</span><span class="small muted">excl. GST</span></div>' +
    '<div class="tile"><span class="label">Cost of goods</span><span class="v">' + money(sum.cogs) + '</span></div>' +
    '<div class="tile"><span class="label">Expenses</span><span class="v neg">' + money(sum.expense) + '</span></div>' +
    '<div class="tile"><span class="label">Net profit</span><span class="v ' + (sum.net >= 0 ? 'pos' : 'neg') + '">' + money(sum.net, true) + '</span></div></div>' +
    '<div class="card">' + profitChart(series) + '</div>' +
    '<p class="small muted">Net profit = Sales − Cost of goods − Expenses. Only sales made through invoices count here; direct credit entries in the ledger do not.</p></div>' +

    '<div class="section"><div class="section-head"><h2>GST reports</h2><input type="month" class="inp" style="width:auto" id="gst-month" value="' + ym + '" aria-label="GST month"></div>' +
    (!s.gstin || !s.stateCode ? '<div class="banner">Add your GSTIN and state in Settings for correct reports.<button class="btn sm" data-act="open-settings">Settings</button></div>' : '') +
    '<div class="card"><span class="label">GSTR-3B summary · ' + monthLabel(ym) + '</span><div class="table-wrap"><table><thead><tr><th></th><th class="r">Taxable</th><th class="r">IGST</th><th class="r">CGST</th><th class="r">SGST</th></tr></thead><tbody>' +
    '<tr><td>3.1(a) Outward supplies</td><td class="r">' + money(g3.out.taxable) + '</td><td class="r">' + money(g3.out.igst) + '</td><td class="r">' + money(g3.out.cgst) + '</td><td class="r">' + money(g3.out.sgst) + '</td></tr>' +
    '<tr><td>4(A)(5) ITC</td><td class="r">' + money(g3.itc.taxable) + '</td><td class="r">' + money(g3.itc.igst) + '</td><td class="r">' + money(g3.itc.cgst) + '</td><td class="r">' + money(g3.itc.sgst) + '</td></tr>' +
    '<tr><td><b>Payable in cash</b></td><td></td><td class="r"><b>' + money(g3.pay.igst) + '</b></td><td class="r"><b>' + money(g3.pay.cgst) + '</b></td><td class="r"><b>' + money(g3.pay.sgst) + '</b></td></tr>' +
    '</tbody></table></div></div>' +
    '<div class="card stack"><span class="label">GSTR-1 · ' + g1.count + ' bills</span>' +
    '<div class="row wrap small"><span class="chip">B2B: ' + (g1.b2b.length - 1) + ' rows</span><span class="chip">B2CL: ' + (g1.b2cl.length - 1) + '</span><span class="chip">B2CS: ' + (g1.b2cs.length - 1) + '</span><span class="chip">HSN: ' + (g1.hsn.length - 1) + '</span></div>' +
    '<span class="small muted">Files use the GST Offline Tool CSV format (b2b, b2cl, b2cs, hsn). ITC counts only purchase bills with a supplier GSTIN.</span></div>' +
    '<div class="btns"><button class="btn primary" data-act="gst-share">' + ic('send') + 'Send to CA' + (s.caName ? ' (' + esc(s.caName) + ')' : '') + '</button><button class="btn" data-act="gst-download">' + ic('file') + 'Download files</button></div>' +
    '<p class="small muted">This summary is built from your bills. Have your CA review it before filing.</p></div>';
}

function gstFiles(ym) {
  const g1 = gstr1(ym), g3 = gstr3b(ym);
  const tag = ym.replace('-', '');
  const r3 = [['Section', 'Taxable Value', 'IGST', 'CGST', 'SGST'],
    ['3.1(a) Outward taxable supplies', g3.out.taxable, g3.out.igst, g3.out.cgst, g3.out.sgst],
    ['4(A)(5) All other ITC', g3.itc.taxable, g3.itc.igst, g3.itc.cgst, g3.itc.sgst],
    ['Payable in cash (estimate)', '', g3.pay.igst, g3.pay.cgst, g3.pay.sgst]];
  return [
    makeFile('GSTR1_b2b_' + tag + '.csv', toCSV(g1.b2b)), makeFile('GSTR1_b2cl_' + tag + '.csv', toCSV(g1.b2cl)),
    makeFile('GSTR1_b2cs_' + tag + '.csv', toCSV(g1.b2cs)), makeFile('GSTR1_hsn_' + tag + '.csv', toCSV(g1.hsn)),
    makeFile('GSTR3B_summary_' + tag + '.csv', toCSV(r3)),
  ];
}
function caMessage(ym) {
  const s = DB.data.settings, g3 = gstr3b(ym);
  return 'Hello ' + (s.caName || 'CA') + ', sharing the GST files of ' + s.shopName + (s.gstin ? ' (' + s.gstin + ')' : '') + ' for ' + monthLabel(ym) + ' (GSTR-1 CSVs + GSTR-3B summary).\n' +
    'Taxable sales: ' + money(g3.out.taxable) + ', output tax: ' + money(g3.out.igst + g3.out.cgst + g3.out.sgst) + ', ITC: ' + money(g3.itc.igst + g3.itc.cgst + g3.itc.sgst) + '.';
}

/* ================= More tab ================= */
function moreView() {
  const card = (act, icon, t, d) => '<button data-act="' + act + '">' + ic(icon) + '<strong>' + t + '</strong><span>' + d + '</span></button>';
  return '<div class="menu">' +
    card('offers', 'chat', 'Bulk WhatsApp offers', 'Festival sales or new stock news to all customers') +
    card('reminders', 'bell', 'Smart reminders', 'Who to remind, and when') +
    card('verifications', 'shield', 'Customer confirmations', 'Pending and disputed entries') +
    card('exports', 'file', 'Tally / Zoho export', 'Files for your accounting software') +
    card('backup', 'cloud', 'Backup', 'Daily automatic backup to Google Drive') +
    card('tab" data-tab="kharcha', 'wallet', 'Expenses', 'Rent, electricity, salary and more') +
    card('price-list', 'file', 'Price list', 'Fixed retail and wholesale prices') +
    card('open-settings', 'gear', 'Settings', 'Shop, GST, UPI, verification') +
    '</div>' +
    '<div class="card row"><span class="grow"><b>BahiKhata+ v' + esc(APP_VERSION) + '</b><br><span class="small muted">' + (isNative() ? 'The app checks for updates every time it opens.' : 'Web version') + '</span></span>' +
    (isNative() ? '<button class="btn sm" data-act="check-update">Check for updates</button>' : '') + '</div>' +
    '<div class="card stack small"><b>Offline mode</b><span class="muted">All data is saved on this device, so entries, bills and reports work without internet. When you are back online, the Drive backup (and server sync, if set up) runs automatically.' +
    (DB.data.settings.syncUrl ? ' Sync: ' + (DB.data.outbox.length ? DB.data.outbox.length + ' changes pending.' : 'all synced (' + relTime(DB.data.meta.lastSync) + ').') : '') + '</span>' +
    (DB.data.settings.syncUrl ? '<button class="btn sm" data-act="sync-now">Sync now</button>' : '') + '</div>';
}

/* ---------- Bulk WhatsApp offers ---------- */
function offerRecipients(aud) {
  return DB.data.parties.filter((p) => p.phone && p.type === 'customer').filter((p) => {
    if (aud === 'good') return partyStats(p.id).rating === 'good';
    if (aud === 'clear') return partyBalance(p.id) <= 0;
    return true;
  }).sort((a, b) => a.name.localeCompare(b.name));
}
function offerText(tpl, p) {
  return tpl.replace(/\{name\}/g, p.name.split(' ')[0]).replace(/\{shop\}/g, DB.data.settings.shopName);
}
function offersSheet() {
  const o = UI.offer;
  const rec = offerRecipients(o.aud);
  const sentN = rec.filter((p) => o.sent[p.id]).length;
  const next = rec.find((p) => !o.sent[p.id]);
  return {
    title: 'Bulk WhatsApp offers',
    body:
      '<div class="examples" style="justify-content:flex-start">' + presetOffers().map(([t], i) => '<button data-act="offer-tpl" data-i="' + i + '"' + (o.tpl === i ? ' style="border-style:solid;color:var(--accent)"' : '') + '>' + t + '</button>').join('') + '</div>' +
      '<label class="field"><span>Message ({name} = customer\'s first name, {shop} = your shop)</span><textarea data-bind="offer.text" id="offer-text">' + esc(o.text) + '</textarea></label>' +
      '<label class="field"><span>Send to</span><select data-bind="offer.aud" data-rerender>' +
      [['all', 'All customers'], ['good', 'Only customers who pay on time'], ['clear', 'Customers with no pending credit']].map(([k, l]) => '<option value="' + k + '"' + (o.aud === k ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></label>' +
      '<div class="row"><b class="grow">Sent to ' + sentN + ' of ' + rec.length + '</b><button class="btn sm" data-act="copy-numbers">Copy numbers</button>' + (sentN ? '<button class="btn sm" data-act="offer-reset">Reset</button>' : '') + '</div>' +
      (next ? '<a class="btn primary block" target="_blank" rel="noopener" data-act="offer-sent" data-id="' + next.id + '" href="' + waLink(next.phone, offerText(o.text, next)) + '">' + ic('chat') + 'Send next: ' + esc(next.name) + '</a>' : (rec.length ? '<div class="banner">Sent to everyone.</div>' : '<div class="banner">No customer in this list has a phone number.</div>')) +
      '<div class="list">' + rec.map((p) => '<div class="item"><span class="grow"><span class="t" style="display:block">' + esc(p.name) + '</span><span class="s">' + esc(p.phone) + '</span></span>' +
        (o.sent[p.id] ? '<span class="chip good">Sent</span>' : '<a class="btn sm" target="_blank" rel="noopener" data-act="offer-sent" data-id="' + p.id + '" href="' + waLink(p.phone, offerText(o.text, p)) + '">Send</a>') + '</div>').join('') + '</div>' +
      '<p class="small muted">WhatsApp opens for each customer with the message filled in; just tap Send. Sending to everyone in one click needs the WhatsApp Business API (e.g. Interakt, AiSensy, Gupshup), which can be connected later.</p>',
  };
}

/* ---------- Exports ---------- */
function fyStart() {
  const d = new Date();
  const y = d.getMonth() >= 3 ? d.getFullYear() : d.getFullYear() - 1;
  return y + '-04-01';
}
function exportsSheet() {
  const from = UI.exFrom || today().slice(0, 8) + '01';
  const to = UI.exTo || today();
  return {
    title: 'Tally / Zoho export',
    body:
      '<div class="fields"><label class="field"><span>From</span><input type="date" id="ex-from" value="' + from + '"></label><label class="field"><span>To</span><input type="date" id="ex-to" value="' + to + '"></label></div>' +
      '<div class="btns"><button class="btn sm" data-act="ex-range" data-v="month">This month</button><button class="btn sm" data-act="ex-range" data-v="last">Last month</button><button class="btn sm" data-act="ex-range" data-v="fy">This financial year</button></div>' +
      '<div class="card stack"><h3>Tally Prime / ERP 9</h3><span class="small muted">Import Masters (ledgers) first, then Vouchers. In Tally: Gateway › Import › Masters / Transactions › choose the file.</span>' +
      '<div class="btns"><button class="btn" data-act="ex-tally" data-v="masters">1. Masters XML</button><button class="btn primary" data-act="ex-tally" data-v="vouchers">2. Vouchers XML</button></div></div>' +
      '<div class="card stack"><h3>Zoho Books</h3><span class="small muted">In Zoho Books, open each module\'s list page › ⋯ › Import and upload the CSV. Import Contacts first.</span>' +
      '<div class="btns">' + [['contacts', 'Contacts'], ['invoices', 'Invoices'], ['bills', 'Bills (purchases)'], ['payments', 'Customer payments'], ['expenses', 'Expenses']]
        .map(([k, l]) => '<button class="btn sm" data-act="ex-zoho" data-v="' + k + '">' + l + '</button>').join('') + '</div>' +
      '<button class="btn" data-act="ex-zoho" data-v="all">All Zoho files at once</button></div>',
  };
}
function readRange() {
  UI.exFrom = $('#ex-from').value;
  UI.exTo = $('#ex-to').value;
  if (!UI.exFrom || !UI.exTo || UI.exFrom > UI.exTo) { toast('Choose a valid date range.', 'bad'); return null; }
  return [UI.exFrom, UI.exTo];
}

/* ---------- Backup ---------- */
function backupSheet() {
  const s = DB.data.settings, m = DB.data.meta;
  const isFile = location.protocol === 'file:';
  const files = UI.driveFiles;
  return {
    title: 'Backup',
    body:
      '<div class="card stack"><div class="row"><h3 class="grow">Google Drive (daily, automatic)</h3>' + (s.driveAutoBackup ? '<span class="chip good">On</span>' : '<span class="chip">Off</span>') + '</div>' +
      '<span class="small">Last backup: <b>' + relTime(m.lastDriveBackup) + '</b>. Folder: "' + Drive.FOLDER + '". Keeps the last ' + s.driveKeep + ' days of backups.</span>' +
      (m.lastDriveError ? '<span class="chip bad" style="white-space:normal">Last attempt: ' + esc(m.lastDriveError) + '</span>' : '') +
      (isFile ? '<div class="banner">To use Drive backup, open the app via start.bat (http://localhost:8080) or from its website.</div>' : '') +
      (!googleClientId() ? '<div class="banner">Google Drive backup is not switched on in this version yet. Use the backup file below.</div>' : '') +
      '<label class="check"><input type="checkbox" id="drive-auto"' + (s.driveAutoBackup ? ' checked' : '') + '>Back up automatically once a day</label>' +
      '<div class="btns"><button class="btn primary" data-act="drive-backup">' + ic('cloud') + 'Back up now</button><button class="btn" data-act="drive-list">Restore from Drive</button></div>' +
      (files ? '<div class="list">' + (files.length ? files.map((f) => '<div class="item"><span class="grow"><span class="t" style="display:block">' + esc(f.name) + '</span><span class="s">' + relTime(f.modifiedTime) + ' · ' + Math.round((Number(f.size) || 0) / 1024) + ' KB</span></span>' +
        '<button class="btn sm" data-act="drive-restore" data-id="' + f.id + '">' + (UI.confirm === 'drive:' + f.id ? 'Tap again: replaces current data' : 'Restore') + '</button></div>').join('') : '<div class="empty">No backups found in Drive.</div>') + '</div>' : '') +
      '<span class="small muted">A web app can\'t run while the browser is closed. The day\'s backup runs the first time you open the app and tap the screen.</span></div>' +
      '<div class="card stack"><h3>Backup file on this device</h3><span class="small muted">Download a backup file to keep in Drive or on a pen drive. Last: ' + relTime(m.lastLocalBackup) + '</span>' +
      '<div class="btns"><button class="btn" data-act="local-backup">' + ic('file') + 'Download backup file</button>' +
      '<label class="btn">Restore from file<input type="file" accept=".json,application/json" id="restore-file" hidden></label></div></div>',
  };
}

/* ---------- Settings ---------- */
function settingsSheet() {
  const s = DB.data.settings;
  const f = (name, label, attrs) => '<label class="field"><span>' + label + '</span><input name="' + name + '" value="' + esc(s[name] ?? '') + '" ' + (attrs || '') + '></label>';
  return {
    title: 'Settings',
    body:
      '<form class="stack" data-form="settings">' +
      '<span class="label">Business profile</span>' + f('shopName', 'Business name', 'required') +
      '<label class="field"><span>Business type</span><select name="businessType">' + BUSINESS_TYPES.map((t) => '<option value="' + t.id + '"' + (s.businessType === t.id ? ' selected' : '') + '>' + esc(t.label) + '</option>').join('') + '</select></label>' +
      '<div class="fields">' + f('ownerName', 'Owner name') + f('phone', 'Mobile', 'type="tel"') + f('city', 'City') + '</div>' +
      '<div class="fields">' + f('gstin', 'GSTIN', 'maxlength="15" style="text-transform:uppercase"') +
      '<label class="field"><span>State</span><select name="stateCode"><option value="">Choose</option>' + Object.entries(STATES).map(([c, n]) => '<option value="' + c + '"' + (s.stateCode === c ? ' selected' : '') + '>' + c + ' ' + n + '</option>').join('') + '</select></label></div>' +
      '<div class="fields">' + f('upi', 'UPI ID (for payment links in reminders)', 'placeholder="shop@upi"') + f('invoicePrefix', 'Bill number prefix') + '</div>' +
      '<label class="check"><input type="checkbox" name="pricesIncludeGst"' + (s.pricesIncludeGst ? ' checked' : '') + '>Selling prices include GST</label>' +
      '<span class="label">Customer verification</span>' +
      '<label class="field"><span>Send confirmation to customer on each entry</span><select name="verifyMode">' +
      '<option value="smart"' + (s.verifyMode === 'smart' ? ' selected' : '') + '>Smart: only customers who don\'t pay on time (recommended)</option>' +
      '<option value="all"' + (s.verifyMode === 'all' ? ' selected' : '') + '>All customers</option>' +
      '<option value="off"' + (s.verifyMode === 'off' ? ' selected' : '') + '>Off</option></select></label>' +
      '<div class="fields"><label class="field"><span>Credit period (days)</span><input name="creditDays" type="number" min="1" value="' + s.creditDays + '"></label>' +
      '<label class="field"><span>Expiry alert (days before)</span><input name="expiryAlertDays" type="number" min="1" value="' + s.expiryAlertDays + '"></label></div>' +
      '<span class="label">CA (for sending GST files)</span>' +
      '<div class="fields">' + f('caName', 'CA name') + f('caPhone', 'CA WhatsApp number', 'type="tel"') + f('caEmail', 'CA email', 'type="email"') + '</div>' +
      '<span class="label">Backup and sync</span>' +
      f('googleClientId', 'Google OAuth Client ID (for Drive backup)', 'placeholder="xxxx.apps.googleusercontent.com" autocomplete="off"') +
      '<label class="field"><span>Days of Drive backups to keep</span><input name="driveKeep" type="number" min="3" max="365" value="' + s.driveKeep + '"></label>' +
      f('syncUrl', 'Sync server URL (optional)', 'type="url" placeholder="https://..."') +
      f('updateUrl', 'App update URL (leave empty for default)', 'type="url" placeholder="' + UPDATE_URL + '"') +
      '<label class="field"><span>Theme</span><select name="theme"><option value="">Follow device</option><option value="light"' + (s.theme === 'light' ? ' selected' : '') + '>Light</option><option value="dark"' + (s.theme === 'dark' ? ' selected' : '') + '>Dark</option></select></label>' +
      '<button class="btn primary block" type="submit">Save settings</button></form>' +
      '<div class="card stack"><span class="label">Security</span><span class="small muted">' + (s.pinHash ? 'A 4-digit PIN is asked every time the app opens.' : 'No PIN set. Anyone with your phone can open the app.') + '</span>' +
      '<div class="btns"><button class="btn" data-act="pin-change">' + (s.pinHash ? 'Change PIN' : 'Set PIN') + '</button>' +
      (s.pinHash ? '<button class="btn" data-act="pin-remove">' + (UI.confirm === 'pin' ? 'Tap again to remove' : 'Remove PIN') + '</button>' : '') + '</div></div>' +
      (DB.data.demo ? '<button class="btn gave" data-act="clear-demo">Remove demo data</button>' : '') +
      '<button class="btn" data-act="wipe">' + (UI.confirm === 'wipe' ? 'Tap again: all data will be erased (take a backup first)' : 'Erase all data') + '</button>',
  };
}

/* ================= Views map ================= */
const VIEWS = { khata: khataView, bills: invoicesView, stock: stockView, kharcha: kharchaView, report: reportView, more: moreView };

/* ================= Actions ================= */
function newBillState() {
  return { date: today(), partyId: '', customerName: '', customerPhone: '', priceType: 'retail', gstin: '', pos: DB.data.settings.stateCode || '07', payMode: 'cash', inclusive: !!DB.data.settings.pricesIncludeGst, lines: [{ itemId: '', qty: 1, rate: 0 }] };
}
function newPurchaseState() {
  return { date: today(), partyId: '', supplierName: '', gstin: '', invNo: '', pos: DB.data.settings.stateCode || '07', payMode: 'udhaar', inclusive: false, lines: [{ itemId: '', qty: 1, rate: 0, gstRate: 18, expiry: '' }] };
}
function emptyLine(which) {
  return which === 'purchase' ? { itemId: '', qty: 1, rate: 0, gstRate: 18, expiry: '' } : { itemId: '', qty: 1, rate: 0 };
}
function setLineItem(which, index, it) {
  const line = UI[which].lines[index];
  if (!line) return;
  line.itemId = it.id;
  line.rate = which === 'bill' ? itemPrice(it, UI.bill.priceType) : Number(it.costPrice) || 0;
  if (which === 'purchase') line.gstRate = Number(it.gstRate) || 0;
}
function setConfirm(key) {
  if (UI.confirm === key) return true;
  UI.confirm = key;
  clearTimeout(setConfirm.t);
  setConfirm.t = setTimeout(() => { UI.confirm = null; }, 5000);
  return false;
}
function rerenderAll() { if (UI.stack.length) refreshSheet(); render(); }

function saveBill() {
  const b = UI.bill;
  const c = computeDoc(b, false);
  if (!c.lines.length) return toast('Add at least one item with a quantity.', 'bad');
  let party = b.partyId ? DB.get('parties', b.partyId) : null;
  const phone = (b.customerPhone || '').trim();
  if (phone && cleanPhone(phone).length !== 12) return toast('Mobile number must be 10 digits.', 'bad');
  if (b.payMode === 'udhaar' && !party) {
    const nm = (b.customerName || '').trim();
    if (!nm) return toast('A credit sale needs the customer\'s name.', 'bad');
    party = DB.add('parties', { name: nm, phone, type: 'customer', verify: 'auto', gstin: (b.gstin || '').toUpperCase(), priceType: b.priceType });
  }
  const no = DB.data.settings.invoicePrefix + DB.data.seq.invoice;
  const inv = DB.add('sales', {
    no, date: b.date, partyId: party ? party.id : null, customerName: party ? party.name : b.customerName.trim(), customerGstin: (b.gstin || '').toUpperCase().trim(),
    pos: b.pos, inclusive: b.inclusive, lines: c.lines, total: c.rounded, roundOff: c.roundOff, payMode: b.payMode,
    customerPhone: party ? '' : phone, priceType: b.priceType,
  });
  DB.data.seq.invoice++;
  for (const l of c.lines) {
    const it = DB.get('items', l.itemId);
    consumeStock(it, l.qty);
    DB.update('items', it.id, { batches: it.batches });
  }
  let t = null;
  if (b.payMode === 'udhaar') t = createTxn(party, { kind: 'gave', amount: inv.total, date: inv.date, note: 'Invoice ' + no, refType: 'sale', refId: inv.id });
  DB.save();
  toast('Invoice ' + no + ' created.', 'good');
  replaceSheet(() => invoiceSheet(inv.id, true));
  render();
}
function savePurchase() {
  const b = UI.purchase;
  const c = computeDoc(b, true);
  if (!c.lines.length) return toast('Add at least one item with a quantity.', 'bad');
  let party = b.partyId ? DB.get('parties', b.partyId) : null;
  const nm = (b.supplierName || '').trim();
  if (!party && nm) party = DB.add('parties', { name: nm, phone: '', type: 'supplier', verify: 'never', gstin: (b.gstin || '').toUpperCase(), state: b.pos });
  if (b.payMode === 'udhaar' && !party) return toast('A credit purchase needs the supplier\'s name.', 'bad');
  const p = DB.add('purchases', {
    date: b.date, partyId: party ? party.id : null, supplierName: party ? party.name : nm, supplierGstin: (b.gstin || '').toUpperCase().trim(),
    invNo: b.invNo, pos: b.pos, lines: c.lines, total: c.rounded, payMode: b.payMode,
  });
  for (const l of c.lines) {
    const it = DB.get('items', l.itemId);
    it.batches = (it.batches || []).concat([{ id: DB.id(), qty: l.qty, expiry: l.expiry || '' }]);
    DB.update('items', it.id, { batches: it.batches, costPrice: l.rate });
  }
  if (b.payMode === 'udhaar') createTxn(party, { kind: 'got', amount: p.total, date: p.date, note: 'Purchase ' + (b.invNo || ''), refType: 'purchase', refId: p.id });
  toast('Stock added. Purchase of ' + money(p.total) + ' saved.', 'good');
  closeAll();
}

const ACT = {
  tab: (el) => { UI.tab = el.dataset.tab; UI.stack = []; UI.animate = true; renderSheet(); render(); window.scrollTo(0, 0); },
  filter: (el) => { UI.filter = el.dataset.v; render(); },
  backdrop: (el, e) => { if (e.target === el) closeAll(); },
  'close-sheet': () => closeSheet(),
  'close-all': () => closeAll(),
  'open-party': (el) => openSheet(() => partySheet(el.dataset.id)),
  'new-party': () => openSheet(() => partyFormSheet(null)),
  'edit-party': (el) => openSheet(() => partyFormSheet(el.dataset.id)),
  ptype: (el) => {
    const form = el.closest('form');
    form.querySelector('[name=type]').value = el.dataset.v;
    form.querySelectorAll('[data-act=ptype]').forEach((b) => b.classList.toggle('on', b === el));
  },
  'add-txn': (el) => openSheet(() => txnFormSheet(el.dataset.id, el.dataset.kind)),
  'quick-txn': (el) => { UI.pickQ = ''; openSheet(() => pickPartySheet(el.dataset.kind)); },
  'pick-party': (el) => replaceSheet(() => txnFormSheet(el.dataset.id, el.dataset.kind)),
  'open-txn': (el) => openSheet(() => txnSheet(el.dataset.id)),
  'verify-open': (el) => openSheet(() => verifySheet(el.dataset.id)),
  'verify-set': (el) => {
    DB.update('txns', el.dataset.id, { verifyStatus: el.dataset.v, verifiedAt: new Date().toISOString() });
    toast(el.dataset.v === 'confirmed' ? 'Confirmed by customer.' : 'Marked as disputed. Talk to the customer.', el.dataset.v === 'confirmed' ? 'good' : 'warn');
    closeSheet();
  },
  'del-txn': (el) => {
    if (!setConfirm('txn:' + el.dataset.id)) return refreshSheet();
    DB.remove('txns', el.dataset.id);
    toast('Entry deleted.');
    closeSheet();
  },
  'del-party': (el) => {
    const id = el.dataset.id;
    if (!setConfirm('party:' + id)) return refreshSheet();
    DB.data.txns.filter((t) => t.partyId === id).forEach((t) => DB.remove('txns', t.id));
    DB.remove('parties', id);
    toast('Party deleted.');
    closeAll();
  },
  'mark-reminded': (el) => { DB.update('parties', el.dataset.id, { lastReminded: today() }); setTimeout(refreshSheet, 300); },
  reminders: () => openSheet(remindersSheet),
  verifications: () => openSheet(verificationsSheet),
  copy: (el) => {
    const ta = document.getElementById(el.dataset.target);
    const text = ta.value || ta.textContent;
    const done = () => toast('Copied.', 'good');
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(done, () => { ta.select(); document.execCommand('copy'); done(); });
    else { ta.select(); document.execCommand('copy'); done(); }
  },

  voice: () => { UI.voice = { listening: false, text: '', draft: null, error: null }; openSheet(voiceSheet); setTimeout(toggleMic, 150); },
  mic: () => toggleMic(),
  'v-lang': (el) => {
    DB.data.settings.voiceLang = el.dataset.v;
    DB.save();
    if (UI.voice.listening && recognizer) recognizer.abort();
    UI.voice.listening = false;
    refreshSheet();
  },
  'v-example': (el) => applyVoiceText(el.dataset.t),
  'v-kind': (el) => { readDraftForm(); UI.voice.draft.kind = el.dataset.v; UI.voice.draft.kindGuessed = false; refreshSheet(); },
  'v-switch': (el) => {
    readDraftForm();
    const d = UI.voice.draft;
    if (el.dataset.v === 'expense') UI.voice.draft = { type: 'expense', amount: d.amount, category: 'Other', note: UI.voice.text };
    else UI.voice.draft = { type: 'khata', kind: 'gave', amount: d.amount, partyId: '', newName: '', date: today(), note: d.note };
    refreshSheet();
  },

  'new-item': () => openSheet(() => itemSheet(null)),
  'open-item': (el) => openSheet(() => itemSheet(el.dataset.id)),
  'del-item': (el) => {
    if (!setConfirm('item:' + el.dataset.id)) return refreshSheet();
    DB.remove('items', el.dataset.id);
    toast('Item deleted.');
    closeSheet();
  },
  'batch-remove': (el) => {
    const it = DB.get('items', el.dataset.id);
    DB.update('items', it.id, { batches: it.batches.filter((b) => b.id !== el.dataset.b) });
    toast('Batch removed.');
    rerenderAll();
  },
  'new-bill': () => { UI.bill = newBillState(); openSheet(billSheet); },
  'new-bill-again': () => { UI.bill = newBillState(); replaceSheet(billSheet); },
  'new-purchase': () => { UI.purchase = newPurchaseState(); openSheet(purchaseSheet); },
  'line-add': (el) => { UI[el.dataset.w].lines.push(emptyLine(el.dataset.w)); refreshSheet(); },
  'line-new-item': (el) => {
    const which = el.dataset.w;
    const lines = UI[which].lines;
    let index = lines.findIndex((l) => !l.itemId);
    if (index < 0) { lines.push(emptyLine(which)); index = lines.length - 1; }
    openItemFromLine(which, index);
  },
  'line-del': (el) => {
    const st = UI[el.dataset.w];
    st.lines.splice(Number(el.dataset.i), 1);
    if (!st.lines.length) st.lines.push(emptyLine(el.dataset.w));
    refreshSheet();
  },
  paymode: (el) => { UI[el.dataset.w].payMode = el.dataset.v; refreshSheet(); },
  'save-bill': () => saveBill(),
  'price-type': (el) => { applyPriceType(el.dataset.v); refreshSheet(); },
  'price-list': () => { UI.priceQ = ''; openSheet(priceListSheet); },
  'inv-open': (el) => openSheet(() => invoiceSheet(el.dataset.id)),
  'inv-pdf': async (el) => {
    const inv = DB.get('sales', el.dataset.id);
    const label = el.innerHTML;
    el.disabled = true; el.textContent = 'Making PDF…';
    try {
      const r = await shareInvoicePdf(inv);
      if (r === 'downloaded') toast('PDF downloaded. Attach it in WhatsApp.', 'good');
    } catch (e) { toast('Could not make the PDF: ' + e.message, 'bad'); }
    el.disabled = false; el.innerHTML = label;
  },
  'inv-cancel': (el) => {
    if (!setConfirm('inv:' + el.dataset.id)) return refreshSheet();
    cancelInvoice(el.dataset.id);
    toast('Invoice cancelled. Stock and credit were reversed.', 'warn');
    refreshSheet(); render();
  },
  'save-purchase': () => savePurchase(),

  'exp-month': (el) => { UI.expMonth = shiftMonth(UI.expMonth, Number(el.dataset.n)); render(); },
  'del-exp': (el) => {
    if (!setConfirm('exp:' + el.dataset.id)) return render();
    DB.remove('expenses', el.dataset.id);
    toast('Expense deleted.');
    render();
  },
  gran: (el) => { UI.gran = el.dataset.v; render(); },
  'gst-download': () => { downloadFiles(gstFiles(UI.gstMonth)); if (!isNative()) toast('Downloading 5 files.'); },
  'gst-share': async () => {
    const s = DB.data.settings;
    const files = gstFiles(UI.gstMonth);
    const msg = caMessage(UI.gstMonth);
    const r = await shareOrDownload(files, msg);
    if (r === 'downloaded') {
      if (s.caPhone) window.open(waLink(s.caPhone, msg + '\n(Attaching the files separately.)'), '_blank');
      else if (s.caEmail) location.href = 'mailto:' + s.caEmail + '?subject=' + encodeURIComponent('GST files ' + monthLabel(UI.gstMonth)) + '&body=' + encodeURIComponent(msg);
      toast('Files downloaded. Attach them in WhatsApp or email to send to your CA.');
    }
  },

  offers: () => { UI.offer = UI.offer || { tpl: 0, text: presetOffers()[0][1], aud: 'all', sent: {} }; openSheet(offersSheet); },
  'offer-tpl': (el) => { const i = Number(el.dataset.i); UI.offer.tpl = i; UI.offer.text = presetOffers()[i][1]; refreshSheet(); },
  'offer-sent': (el) => { UI.offer.sent[el.dataset.id] = true; setTimeout(refreshSheet, 300); },
  'offer-reset': () => { UI.offer.sent = {}; refreshSheet(); },
  'copy-numbers': () => {
    const nums = offerRecipients(UI.offer.aud).map((p) => '+' + cleanPhone(p.phone)).join(', ');
    const done = () => toast('Numbers copied. You can paste them into a WhatsApp broadcast list.', 'good');
    if (navigator.clipboard) navigator.clipboard.writeText(nums).then(done, () => toast(nums));
    else toast(nums);
  },

  exports: () => openSheet(exportsSheet),
  'ex-range': (el) => {
    const v = el.dataset.v;
    if (v === 'month') { UI.exFrom = today().slice(0, 8) + '01'; UI.exTo = today(); }
    if (v === 'last') { const ym = shiftMonth(today().slice(0, 7), -1); UI.exFrom = ym + '-01'; UI.exTo = addDays(today().slice(0, 8) + '01', -1); }
    if (v === 'fy') { UI.exFrom = fyStart(); UI.exTo = today(); }
    refreshSheet();
  },
  'ex-tally': (el) => {
    const r = readRange(); if (!r) return;
    const x = tallyExport(r[0], r[1]);
    const tag = r[0].replace(/-/g, '') + '_' + r[1].replace(/-/g, '');
    if (el.dataset.v === 'masters') downloadFile(makeFile('Tally_Masters_' + tag + '.xml', x.masters, 'application/xml'));
    else { downloadFile(makeFile('Tally_Vouchers_' + tag + '.xml', x.vouchers, 'application/xml')); toast(x.count + ' vouchers exported.', 'good'); }
  },
  'ex-zoho': (el) => {
    const r = readRange(); if (!r) return;
    const z = zohoExport(r[0], r[1]);
    const tag = r[0].replace(/-/g, '') + '_' + r[1].replace(/-/g, '');
    const keys = el.dataset.v === 'all' ? Object.keys(z) : [el.dataset.v];
    downloadFiles(keys.map((k) => makeFile('Zoho_' + k + '_' + tag + '.csv', toCSV(z[k]))));
    if (!isNative()) toast('Downloading ' + keys.length + (keys.length > 1 ? ' files.' : ' file.'));
  },

  backup: () => { UI.driveFiles = null; openSheet(backupSheet); },
  'drive-backup': async (el) => {
    el.disabled = true; el.textContent = 'Backing up…';
    try {
      await Drive.getToken(!Drive.token);
      const name = await Drive.backup();
      toast('Saved to Drive: ' + name, 'good');
    } catch (e) {
      DB.data.meta.lastDriveError = e.message; DB.save();
      toast(e.message, 'bad');
    }
    rerenderAll();
  },
  'drive-list': async (el) => {
    el.disabled = true; el.textContent = 'Looking…';
    try { await Drive.getToken(!Drive.token); UI.driveFiles = await Drive.list(); } catch (e) { toast(e.message, 'bad'); }
    refreshSheet();
  },
  'drive-restore': async (el) => {
    if (!setConfirm('drive:' + el.dataset.id)) return refreshSheet();
    try {
      const data = await Drive.download(el.dataset.id);
      DB.restore(data);
      applyTheme();
      toast('Data restored from backup.', 'good');
      closeAll();
    } catch (e) { toast(e.message, 'bad'); }
  },
  'local-backup': () => {
    downloadFile(makeFile('bahikhata-backup-' + today() + '.json', JSON.stringify(DB.snapshot()), 'application/json'));
    DB.data.meta.lastLocalBackup = new Date().toISOString(); DB.save();
    refreshSheet();
  },
  'sync-now': () => syncNow(true),
  'check-update': () => Updater.check(true),
  'upd-install': () => Updater.install(),

  'open-settings': () => openSheet(settingsSheet),
  'pin-change': () => { closeAll(); openPinChange(); },
  'pin-remove': () => {
    if (!setConfirm('pin')) return refreshSheet();
    delete DB.data.settings.pinHash; DB.save();
    toast('PIN removed.');
    refreshSheet();
  },
  'clear-demo': () => {
    const keep = DB.data.settings;
    DB.data = DB.empty();
    DB.data.settings = keep;
    DB.data.welcomed = true;
    DB.data.onboarded = true;
    DB.save();
    toast('Demo data removed. Start your own ledger.', 'good');
    closeAll();
  },
  wipe: () => {
    if (!setConfirm('wipe')) return refreshSheet();
    DB.data = DB.empty(); DB.save();
    location.reload();
  },
  'welcome-start': () => {
    const nm = ($('#w-shop').value || '').trim();
    if (nm) DB.data.settings.shopName = nm;
    DB.data.welcomed = true; DB.save(); render();
    openSheet(settingsSheet);
  },
  'welcome-demo': () => {
    const nm = ($('#w-shop').value || '').trim();
    if (nm) DB.data.settings.shopName = nm;
    seedDemo();
    toast('Demo data loaded. Tap the mic and say "Gave 500 to Ramesh".', 'good');
    render();
  },
};

function readDraftForm() {
  const f = $('form[data-form=voice-save]');
  const d = UI.voice && UI.voice.draft;
  if (!f || !d) return;
  const fd = new FormData(f);
  if (fd.get('amount')) d.amount = Number(fd.get('amount'));
  if (fd.has('note')) d.note = fd.get('note');
  if (fd.has('date')) d.date = fd.get('date');
  if (fd.has('party')) { const v = fd.get('party'); d.partyId = v === '__new' ? '' : v; }
  if (fd.has('category')) d.category = fd.get('category');
}

const FORMS = {
  txn: (f, fd) => {
    const p = DB.get('parties', f.dataset.id);
    const amount = Number(fd.get('amount'));
    if (!(amount > 0)) return toast('Enter a valid amount.', 'bad');
    const t = createTxn(p, { kind: f.dataset.kind, amount, date: fd.get('date'), note: fd.get('note').trim(), mode: fd.get('mode') });
    afterTxn(t, true);
  },
  party: (f, fd) => {
    const rec = {
      name: fd.get('name').trim(), phone: fd.get('phone').trim(), type: fd.get('type'), gstin: fd.get('gstin').trim().toUpperCase(),
      state: fd.get('state'), verify: fd.get('verify'), priceType: fd.get('priceType') || 'retail',
    };
    if (!rec.name) return toast('Enter a name.', 'bad');
    if (rec.phone && cleanPhone(rec.phone).length !== 12) return toast('Mobile number must be 10 digits.', 'bad');
    if (f.dataset.id) { DB.update('parties', f.dataset.id, rec); toast('Party updated.', 'good'); closeSheet(); }
    else {
      const p = DB.add('parties', rec);
      UI.filter = p.type;
      toast(p.name + ' added.', 'good');
      replaceSheet(() => partySheet(p.id));
      render();
    }
  },
  'voice-text': (f, fd) => {
    const t = (fd.get('t') || '').trim();
    if (!t) return;
    UI.voice.typed = '';
    applyVoiceText(t);
  },
  'voice-save': () => {
    readDraftForm();
    const d = UI.voice.draft;
    if (!(d.amount > 0)) return toast('Enter the amount.', 'bad');
    if (d.type === 'expense') {
      DB.add('expenses', { date: today(), category: d.category, amount: r2(d.amount), mode: 'cash', note: d.note || '' });
      toast('Expense of ' + money(d.amount) + ' (' + d.category + ') saved.', 'good');
      closeAll();
      return;
    }
    let p = d.partyId ? DB.get('parties', d.partyId) : null;
    if (!p) {
      if (!d.newName) return toast('Choose a party.', 'bad');
      p = DB.add('parties', { name: d.newName, phone: '', type: 'customer', verify: 'auto' });
    }
    const t = createTxn(p, { kind: d.kind, amount: d.amount, date: d.date, note: d.note || 'Voice entry' });
    UI.stack = [() => partySheet(p.id)];
    afterTxn(t, false);
    render();
  },
  item: (f, fd) => {
    const rec = {
      name: fd.get('name').trim(), unit: fd.get('unit'), hsn: fd.get('hsn').trim(), gstRate: Number(fd.get('gstRate')),
      costPrice: Number(fd.get('costPrice')) || 0, salePrice: Number(fd.get('salePrice')) || 0, minQty: Number(fd.get('minQty')) || 0,
      wholesalePrice: Number(fd.get('wholesalePrice')) || 0, trackStock: fd.get('trackStock') === 'on',
    };
    if (!rec.name) return toast('Enter the item name.', 'bad');
    if (f.dataset.id) { DB.update('items', f.dataset.id, rec); toast('Item updated.', 'good'); closeSheet(); return; }
    const dup = DB.data.items.find((x) => x.name.trim().toLowerCase() === rec.name.toLowerCase());
    if (dup) return toast('"' + dup.name + '" already exists. Choose it from the list instead.', 'warn');
    const q = Number(fd.get('openQty')) || 0;
    rec.batches = q > 0 ? [{ id: DB.id(), qty: q, expiry: fd.get('openExpiry') || '' }] : [];
    const it = DB.add('items', rec);
    // Created from inside a bill/purchase: put it straight into that line
    if (f.dataset.ret) {
      const [which, index] = f.dataset.ret.split(':');
      if (UI[which]) setLineItem(which, Number(index), it);
      toast(it.name + ' created and added.', 'good');
    } else toast(it.name + ' added.', 'good');
    closeSheet();
  },
  'stock-add': (f, fd) => {
    const it = DB.get('items', f.dataset.id);
    const q = Number(fd.get('qty'));
    if (!q) return toast('Enter a quantity.', 'bad');
    if (q > 0) it.batches = (it.batches || []).concat([{ id: DB.id(), qty: q, expiry: fd.get('expiry') || '' }]);
    else consumeStock(it, -q);
    DB.update('items', it.id, { batches: it.batches });
    toast('Stock updated: ' + itemQty(it) + ' ' + it.unit, 'good');
    rerenderAll();
  },
  expense: (f, fd) => {
    const amount = Number(fd.get('amount'));
    if (!(amount > 0)) return toast('Enter a valid amount.', 'bad');
    DB.add('expenses', { date: fd.get('date') || today(), category: fd.get('category'), amount: r2(amount), mode: fd.get('mode'), note: fd.get('note').trim() });
    toast('Expense added.', 'good');
    render();
  },
  settings: (f, fd) => {
    const s = DB.data.settings;
    for (const k of ['shopName', 'ownerName', 'phone', 'city', 'businessType', 'gstin', 'stateCode', 'upi', 'invoicePrefix', 'verifyMode', 'caName', 'caPhone', 'caEmail', 'googleClientId', 'syncUrl', 'updateUrl', 'theme'])
      s[k] = (fd.get(k) || '').trim();
    s.gstin = s.gstin.toUpperCase();
    s.defaultGst = currentPreset().gst;
    s.pricesIncludeGst = fd.get('pricesIncludeGst') === 'on';
    s.creditDays = Number(fd.get('creditDays')) || 15;
    s.expiryAlertDays = Number(fd.get('expiryAlertDays')) || 30;
    s.driveKeep = Number(fd.get('driveKeep')) || 30;
    if (s.gstin && s.gstin.length !== 15) toast('A GSTIN has 15 characters. Please check it.', 'warn');
    else toast('Settings saved.', 'good');
    DB.save();
    applyTheme();
    armDailyBackup();
    closeSheet();
  },
};

/* ---------- Event wiring ---------- */
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  // The dimmed backdrop wraps every panel: only a tap on the backdrop itself closes it.
  // Clicks inside the panel (Save buttons, checkboxes, links) must keep their normal behaviour.
  if (el.dataset.act === 'backdrop') { if (e.target === el) closeAll(); return; }
  const fn = ACT[el.dataset.act];
  if (!fn) return;
  if (el.tagName !== 'A') e.preventDefault();
  fn(el, e);
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && UI.stack.length) closeAll();
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('.tx[data-act]')) { e.preventDefault(); ACT[e.target.dataset.act](e.target, e); }
});
document.addEventListener('submit', (e) => {
  const f = e.target.closest('form[data-form]');
  if (!f) return;
  e.preventDefault();
  FORMS[f.dataset.form](f, new FormData(f));
});
function setPath(path, value) {
  const parts = path.split('.');
  let o = UI;
  for (let i = 0; i < parts.length - 1; i++) o = o[parts[i]];
  o[parts[parts.length - 1]] = value;
}
function onBind(el) {
  const lineItem = el.dataset.bind.match(/^(bill|purchase)\.lines\.(\d+)\.itemId$/);
  // "+ Create new item" chosen in a line: open the item form, then drop the new item into this line
  if (lineItem && el.value === '__new') {
    el.value = UI[lineItem[1]].lines[Number(lineItem[2])].itemId || '';
    openItemFromLine(lineItem[1], Number(lineItem[2]));
    return;
  }
  let v = el.type === 'checkbox' ? el.checked : el.value;
  if (el.hasAttribute('data-num')) v = Number(v) || 0;
  const root = el.dataset.bind.split('.')[0];
  if (lineItem && v) {
    setLineItem(lineItem[1], Number(lineItem[2]), DB.get('items', v));
  } else setPath(el.dataset.bind, v);
  if (el.dataset.bind === 'bill.partyId') {
    const p = v && DB.get('parties', v);
    if (p) { UI.bill.gstin = p.gstin || ''; UI.bill.pos = p.state || DB.data.settings.stateCode || UI.bill.pos; }
    applyPriceType(p && p.priceType === 'wholesale' ? 'wholesale' : 'retail');
  }
  if (el.dataset.bind === 'purchase.partyId' && v) {
    const p = DB.get('parties', v);
    UI.purchase.gstin = p.gstin || ''; UI.purchase.pos = p.state || DB.data.settings.stateCode || UI.purchase.pos;
  }
  if (el.hasAttribute('data-rerender')) return refreshSheet();
  const tEl = document.getElementById('totals-' + root);
  if (tEl) tEl.innerHTML = totalsHtml(root);
}
document.addEventListener('input', (e) => {
  const el = e.target;
  if (el.id === 'party-q') { UI.q = el.value; $('#party-list').innerHTML = partyListHtml(); return; }
  if (el.id === 'inv-q') { UI.invQ = el.value; $('#inv-list').innerHTML = invoiceListHtml(); return; }
  if (el.id === 'price-q') { UI.priceQ = el.value; $('#price-rows').innerHTML = priceRowsHtml(); return; }
  if (el.id === 'pick-q') { UI.pickQ = el.value; refreshSheet(); const i = $('#pick-q'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } return; }
  if (el.id === 'stock-q') {
    UI.stockQ = el.value;
    const q = el.value.trim().toLowerCase();
    const items = DB.data.items.filter((it) => !q || it.name.toLowerCase().includes(q) || (it.hsn || '').includes(q)).sort((a, b) => a.name.localeCompare(b.name));
    $('#stock-list').innerHTML = items.length ? items.map(itemRow).join('') : '<div class="empty">Nothing found.</div>';
    return;
  }
  if (el.matches('[data-bind]') && el.tagName !== 'SELECT' && el.type !== 'checkbox' && el.type !== 'date') onBind(el);
  if (el.name === 't' && UI.voice) UI.voice.typed = el.value;
});
document.addEventListener('change', async (e) => {
  const el = e.target;
  if (el.matches('[data-bind]') && (el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'date')) onBind(el);
  if (el.id === 'gst-month' && el.value) { UI.gstMonth = el.value; render(); }
  if (el.id === 'item-track') { const f = document.getElementById('item-stock-fields'); if (f) f.hidden = !el.checked; }
  if (el.matches('[data-price]')) {
    const [id, field] = el.dataset.price.split(':');
    const v = Math.max(0, Number(el.value) || 0);
    DB.update('items', id, { [field]: v });
    el.value = v || '';
    toast('Price saved.', 'good');
  }
  if (el.id === 'drive-auto') {
    DB.data.settings.driveAutoBackup = el.checked;
    DB.save();
    toast(el.checked ? 'Daily Drive backup is on.' : 'Daily Drive backup is off.');
    armDailyBackup();
    rerenderAll();
  }
  if (el.id === 'restore-file' && el.files[0]) {
    try {
      const data = JSON.parse(await el.files[0].text());
      DB.restore(data);
      applyTheme();
      toast('Data restored from backup file.', 'good');
      closeAll();
    } catch (err) { toast(err.message, 'bad'); }
  }
});

/* ---------- Daily Drive backup ---------- */
// Browsers only allow the Google sign-in pop-up after a tap, so the day's backup runs on the first tap.
function armDailyBackup() {
  const s = DB.data.settings;
  if (!s.driveAutoBackup || !googleClientId() || location.protocol === 'file:') return;
  if (isNative()) { Drive.autoCheck(); return; } // the phone's Google account signs in silently
  Drive.loadGis().catch(() => {});
  const last = DB.data.meta.lastDriveBackup;
  if (last && ymd(new Date(last)) === today()) return;
  if (UI.armed.backup) return;
  UI.armed.backup = true;
  const onTap = () => {
    document.removeEventListener('pointerdown', onTap, true);
    UI.armed.backup = false;
    Drive.autoCheck();
  };
  document.addEventListener('pointerdown', onTap, true);
}

/* ---------- Start ---------- */
DB.load();
if (location.hash === '#demo' && !DB.data.onboarded) {
  Object.assign(DB.data.settings, { businessType: 'kirana', shopName: 'Sharma General Store', ownerName: 'Rakesh Sharma', phone: '9000000099', stateCode: '07', city: 'Delhi' });
  DB.data.onboarded = true;
  seedDemo();
}
applyTheme();
UI.animate = true;
if (startAuth()) { render(); afterUnlock(); }
initNative();
window.addEventListener('online', () => { renderHeader(); syncNow(false); armDailyBackup(); });
window.addEventListener('offline', renderHeader);
setInterval(() => { armDailyBackup(); syncNow(false); }, 60 * 60 * 1000);
syncNow(false);
if ('serviceWorker' in navigator && location.protocol.startsWith('http') && !isNative()) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}

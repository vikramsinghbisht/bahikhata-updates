// Business logic: hisaab, smart reminders, voice parsing, munafa, GST, Tally/Zoho export.

/* ---------- Chhote helpers ---------- */
const pad2 = (n) => String(n).padStart(2, '0');
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
function ymd(d) {
  d = d instanceof Date ? d : new Date(d);
  return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
}
const today = () => ymd(new Date());
function parseYmd(s) {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, m - 1, d);
}
function addDays(s, n) {
  const d = parseYmd(s);
  d.setDate(d.getDate() + n);
  return ymd(d);
}
function daysBetween(a, b) {
  return Math.round((parseYmd(b) - parseYmd(a)) / 86400000);
}
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
function fmtDate(s) {
  const d = parseYmd(s);
  return d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
}
function fmtDateShort(s) {
  const d = parseYmd(s);
  return d.getDate() + ' ' + MONTHS[d.getMonth()];
}
function money(n, withSign) {
  const v = Math.abs(Number(n) || 0);
  const str = '₹' + v.toLocaleString('en-IN', { maximumFractionDigits: 2 });
  if (withSign && n < 0) return '−' + str;
  return str;
}
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function mode(arr) {
  const c = {};
  let best = null;
  for (const v of arr) {
    c[v] = (c[v] || 0) + 1;
    if (best === null || c[v] > c[best]) best = v;
  }
  return best;
}
function cleanPhone(p) {
  const d = String(p || '').replace(/\D/g, '');
  if (d.length === 10) return '91' + d;
  if (d.length === 12 && d.startsWith('91')) return d;
  if (d.length === 11 && d.startsWith('0')) return '91' + d.slice(1);
  return d;
}

const STATES = {
  '01': 'Jammu and Kashmir', '02': 'Himachal Pradesh', '03': 'Punjab', '04': 'Chandigarh', '05': 'Uttarakhand',
  '06': 'Haryana', '07': 'Delhi', '08': 'Rajasthan', '09': 'Uttar Pradesh', '10': 'Bihar', '11': 'Sikkim',
  '12': 'Arunachal Pradesh', '13': 'Nagaland', '14': 'Manipur', '15': 'Mizoram', '16': 'Tripura', '17': 'Meghalaya',
  '18': 'Assam', '19': 'West Bengal', '20': 'Jharkhand', '21': 'Odisha', '22': 'Chhattisgarh', '23': 'Madhya Pradesh',
  '24': 'Gujarat', '26': 'Dadra and Nagar Haveli and Daman and Diu', '27': 'Maharashtra', '29': 'Karnataka',
  '30': 'Goa', '31': 'Lakshadweep', '32': 'Kerala', '33': 'Tamil Nadu', '34': 'Puducherry',
  '35': 'Andaman and Nicobar Islands', '36': 'Telangana', '37': 'Andhra Pradesh', '38': 'Ladakh', '97': 'Other Territory',
};
const posLabel = (code) => (code && STATES[code] ? code + '-' + STATES[code] : '');

const EXPENSE_CATS = ['Rent', 'Electricity', 'Transport', 'Staff salary', 'Tea & snacks', 'Packing', 'Phone/Internet', 'Repair', 'Other'];
// Categories for the chosen business type (plus one the voice parser produced, if missing)
function expenseCats(extra) {
  const list = (typeof currentPreset === 'function' ? currentPreset().expenses : EXPENSE_CATS).slice();
  if (extra && !list.includes(extra)) list.splice(list.length - 1, 0, extra);
  return list;
}
function googleClientId() {
  return (DB.data && DB.data.settings.googleClientId) || (typeof DEFAULT_GOOGLE_CLIENT_ID !== 'undefined' ? DEFAULT_GOOGLE_CLIENT_ID : '');
}
// Categories for the chosen business type (plus one the voice parser produced, if missing)
function expenseCats(extra) {
  const list = (typeof currentPreset === 'function' ? currentPreset().expenses : EXPENSE_CATS).slice();
  if (extra && !list.includes(extra)) list.splice(list.length - 1, 0, extra);
  return list;
}
function googleClientId() {
  return (DB.data && DB.data.settings.googleClientId) || (typeof DEFAULT_GOOGLE_CLIENT_ID !== 'undefined' ? DEFAULT_GOOGLE_CLIENT_ID : '');
}

/* ---------- Khata balance ---------- */
// balance > 0  => party se lena hai;  balance < 0 => party ko dena hai
function partyTxns(pid) {
  return DB.data.txns
    .filter((t) => t.partyId === pid)
    .sort((a, b) => (a.date === b.date ? a.createdAt.localeCompare(b.createdAt) : a.date.localeCompare(b.date)));
}
function partyBalance(pid) {
  let b = 0;
  for (const t of DB.data.txns) if (t.partyId === pid) b += t.kind === 'gave' ? t.amount : -t.amount;
  return r2(b);
}
function totals() {
  let lena = 0, dena = 0;
  for (const p of DB.data.parties) {
    const b = partyBalance(p.id);
    if (b > 0) lena += b;
    else dena -= b;
  }
  return { lena: r2(lena), dena: r2(dena) };
}

/* ---------- Smart reminders: customer kab aur kitni der mein paise deta hai ---------- */
function partyStats(pid) {
  const credit = Number(DB.data.settings.creditDays) || 15;
  const tx = partyTxns(pid);
  const queue = [];
  const paidDays = [];
  const payDows = [];
  const payHours = [];
  for (const t of tx) {
    if (t.kind === 'gave') {
      queue.push({ left: t.amount, date: t.date });
    } else {
      const at = new Date(t.createdAt);
      payDows.push(parseYmd(t.date).getDay());
      payHours.push(at.getHours());
      let amt = t.amount;
      while (amt > 0.001 && queue.length) {
        const g = queue[0];
        const use = Math.min(g.left, amt);
        g.left -= use;
        amt -= use;
        if (g.left <= 0.001) {
          paidDays.push(Math.max(0, daysBetween(g.date, t.date)));
          queue.shift();
        }
      }
    }
  }
  const outstanding = r2(queue.reduce((s, g) => s + g.left, 0));
  const oldest = queue.length ? queue[0].date : null;
  const age = oldest ? daysBetween(oldest, today()) : 0;
  const avgDays = paidDays.length ? Math.round(paidDays.reduce((a, b) => a + b, 0) / paidDays.length) : null;
  const onTime = paidDays.length ? paidDays.filter((d) => d <= credit).length / paidDays.length : null;

  let rating = 'new';
  if (paidDays.length >= 2) {
    if (avgDays <= credit && onTime >= 0.7) rating = 'good';
    else if (avgDays <= credit * 2) rating = 'ok';
    else rating = 'late';
  }
  // Abhi ka purana udhaar bhi dekho: bahut der ho gayi to rating neeche
  if (outstanding > 0 && age > credit * 3) rating = 'late';

  const bestDow = payDows.length >= 2 ? Number(mode(payDows)) : null;
  const bestHour = payHours.length >= 2 ? Number(mode(payHours)) : null;
  const typical = avgDays != null ? Math.max(avgDays, 3) : credit;
  const due = outstanding > 0 && age >= Math.min(typical, credit);
  const overdueBy = outstanding > 0 ? age - typical : 0;
  const score = outstanding > 0 ? outstanding * (1 + Math.max(0, age) / 30) * (rating === 'late' ? 1.5 : 1) : 0;

  // Reminder kab bhejein: jis din/samay woh aam taur par paise deta hai, usse ~1 ghanta pehle
  let when = null;
  if (outstanding > 0) {
    let d = new Date();
    if (bestDow != null) {
      const diff = (bestDow - d.getDay() + 7) % 7;
      d.setDate(d.getDate() + diff);
    }
    const hour = bestHour != null ? Math.max(9, bestHour - 1) : 11;
    const isToday = ymd(d) === today();
    if (isToday && new Date().getHours() >= hour + 2 && bestDow != null) d.setDate(d.getDate() + 7);
    when = { date: ymd(d), hour, isToday: ymd(d) === today() };
  }

  return { outstanding, oldest, age, avgDays, onTime, rating, bestDow, bestHour, due, overdueBy, score, when, payments: paidDays.length };
}

const RATING_LABEL = { good: 'Pays on time', ok: 'Slightly late', late: 'Late payer', new: 'New customer' };

function reminderList() {
  return DB.data.parties
    .filter((p) => p.type === 'customer')
    .map((p) => ({ party: p, stats: partyStats(p.id) }))
    .filter((x) => x.stats.outstanding > 0)
    .sort((a, b) => b.stats.score - a.stats.score);
}

function reminderAdvice(st) {
  const parts = [];
  if (st.avgDays != null) parts.push('Usually pays in ' + st.avgDays + ' days');
  else parts.push('Not enough payment history yet');
  if (st.bestDow != null) {
    const h = st.bestHour;
    const slot = h == null ? '' : h < 12 ? ' mornings' : h < 16 ? ' afternoons' : h < 20 ? ' evenings' : ' nights';
    parts.push('mostly pays on ' + DAYS[st.bestDow] + slot);
  }
  let action;
  if (!st.due) action = 'No reminder needed yet. You can wait until ' + fmtDateShort(addDays(st.oldest, st.avgDays || DB.data.settings.creditDays)) + '.';
  else if (st.when.isToday) action = 'Send a reminder today at ' + hourLabel(st.when.hour) + '.';
  else action = 'Send a reminder on ' + DAYS[parseYmd(st.when.date).getDay()] + ' (' + fmtDateShort(st.when.date) + ') at ' + hourLabel(st.when.hour) + '.';
  return { reason: parts.join(', ') + '.', action };
}
function hourLabel(h) {
  const hh = h % 12 === 0 ? 12 : h % 12;
  return hh + (h < 12 ? ' AM' : ' PM');
}

/* ---------- Dono taraf verification (optional) ---------- */
function needsVerify(party) {
  if (!party || party.type !== 'customer') return false;
  if (party.verify === 'always') return true;
  if (party.verify === 'never') return false;
  const m = DB.data.settings.verifyMode;
  if (m === 'off') return false;
  if (m === 'all') return true;
  return partyStats(party.id).rating !== 'good'; // smart: time pe dene walon ko skip
}
function verifyMessage(t, party) {
  const s = DB.data.settings;
  const what = t.kind === 'gave' ? 'credit (udhaar) of ' + money(t.amount) + ' was added' : 'payment of ' + money(t.amount) + ' was received';
  const bal = partyBalance(party.id);
  return (
    s.shopName + ': Hello ' + party.name + ', a ' + what + ' in your account' +
    ' (' + fmtDate(t.date) + (t.note ? ', ' + t.note : '') + '). Total due: ' + money(Math.max(bal, 0)) +
    '. If this is correct, reply OK ' + t.code + '. If not, reply NO ' + t.code + '.'
  );
}

function reminderMessage(party) {
  const s = DB.data.settings;
  const bal = partyBalance(party.id);
  let msg = 'Hello ' + party.name + ', a payment of ' + money(bal) + ' is due at ' + s.shopName + '. Please pay at your earliest convenience.';
  if (s.upi) {
    msg += '\nPay by UPI: ' + s.upi +
      '\nLink: upi://pay?pa=' + encodeURIComponent(s.upi) + '&pn=' + encodeURIComponent(s.shopName) + '&am=' + r2(bal) + '&cu=INR';
  }
  msg += '\nThank you!';
  return msg;
}

/* ---------- Voice entry parser (English + Hindi + Hinglish) ---------- */
const DEV_DIGITS = '०१२३४५६७८९';
const NUM_WORDS = {
  ek: 1, एक: 1, do: 2, दो: 2, teen: 3, तीन: 3, char: 4, chaar: 4, चार: 4, paanch: 5, panch: 5, पांच: 5, पाँच: 5,
  chhe: 6, che: 6, chah: 6, छह: 6, छः: 6, saat: 7, सात: 7, aath: 8, आठ: 8, nau: 9, नौ: 9, das: 10, दस: 10,
  one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, twenty: 20, fifty: 50,
  bees: 20, बीस: 20, tees: 30, तीस: 30, chalis: 40, चालीस: 40, pachas: 50, pachaas: 50, पचास: 50,
  dedh: 1.5, डेढ़: 1.5, डेढ: 1.5, dhai: 2.5, dhaai: 2.5, ढाई: 2.5,
};
const MULT = {
  sau: 100, सौ: 100, hundred: 100, hazar: 1000, hazaar: 1000, hajar: 1000, hajaar: 1000, हजार: 1000, हज़ार: 1000,
  thousand: 1000, k: 1000, lakh: 100000, lac: 100000, लाख: 100000,
};
const KW = {
  gave: ['udhaar', 'udhar', 'udhari', 'उधार', 'उधारी', 'baaki', 'baki', 'बाकी', 'बकाया', 'credit', 'lent', 'owes', 'owe', 'due'],
  give: ['diya', 'diye', 'di', 'de', 'दिया', 'दिए', 'दिये', 'दी', 'दे'],
  got: ['liya', 'liye', 'li', 'लिया', 'लिए', 'लिये', 'ली', 'mila', 'mile', 'मिला', 'मिले', 'jama', 'जमा', 'wapas', 'vapas', 'वापस',
    'chukaya', 'चुकाया', 'chukaye', 'aaya', 'aaye', 'aya', 'आया', 'आए', 'आये', 'received', 'receive', 'got', 'collected', 'returned', 'payment', 'पेमेंट', 'bhare', 'bhara'],
  ko: ['ko', 'को', 'to'],
  ne: ['ne', 'ने'],
  se: ['se', 'से', 'from'],
  filler: ['aaj', 'आज', 'maine', 'मैंने', 'mene', 'humne', 'हमने', 'rupaye', 'rupees', 'rupay', 'rupya', 'रुपये', 'रुपए', 'रूपये', 'rs', 'ka', 'ki', 'ke', 'का', 'की',
    'के', 'hai', 'है', 'the', 'thi', 'tha', 'था', 'थे', 'ji', 'जी', 'ek', 'kar', 'कर', 'gaya', 'गया', 'gaye', 'गए', 'hain', 'हैं', 'please', 'likho', 'लिखो', 'likh', 'daal', 'डाल', 'do',
    'i', 'we', 'rupee', 'rupees', 'inr', 'a', 'an', 'of', 'for', 'on', 'today', 'by', 'in', 'cash', 'upi', 'amount', 'has', 'have', 'was', 'is', 'mr', 'mrs', 'and'],
};
const EXPENSE_WORDS = {
  Rent: ['kiraya', 'किराया', 'rent'],
  Electricity: ['bijli', 'बिजली', 'light', 'electricity'],
  Transport: ['transport', 'ट्रांसपोर्ट', 'bhada', 'bhaada', 'भाड़ा', 'भाडा', 'auto', 'ऑटो', 'petrol', 'पेट्रोल', 'diesel', 'tempo'],
  'Staff salary': ['salary', 'सैलरी', 'tankhwah', 'तनख्वाह', 'पगार', 'pagar'],
  'Tea & snacks': ['chai', 'चाय', 'nashta', 'नाश्ता', 'tea', 'snacks', 'coffee'],
  Packing: ['packing', 'पैकिंग', 'polythene', 'thaili'],
  'Phone/Internet': ['recharge', 'रिचार्ज', 'internet', 'wifi'],
  Repair: ['repair', 'रिपेयर', 'marammat', 'मरम्मत'],
};
const EXPENSE_TRIGGER = ['kharcha', 'kharch', 'खर्चा', 'खर्च', 'expense', 'expenses', 'spent', 'spend'];
// English: "Gave 500 to Ramesh" = you gave; "Ramesh paid 500" = you got
const EN_GIVE = ['gave', 'give', 'given', 'paid', 'pay', 'pays'];

function parseAmount(tokens) {
  // "2 हज़ार 500", "do hazar", "1.5 lakh", "2500"
  let total = 0, cur = null, found = false, used = new Set();
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];
    let n = null;
    if (/^\d+(\.\d+)?$/.test(t)) n = parseFloat(t);
    else if (/^\d+(\.\d+)?k$/.test(t)) n = parseFloat(t) * 1000;
    else if (NUM_WORDS[t] != null && !(t === 'do' && !isNumberish(tokens[i + 1]))) n = NUM_WORDS[t];
    if (n != null) {
      if (cur != null) total += cur;
      cur = n;
      found = true;
      used.add(i);
      continue;
    }
    if (MULT[t] && (cur != null || t !== 'k')) {
      cur = (cur == null ? 1 : cur) * MULT[t];
      if (MULT[t] >= 1000) { total += cur; cur = null; }
      found = true;
      used.add(i);
      continue;
    }
    if (found && cur == null && total > 0) continue;
  }
  if (cur != null) total += cur;
  return { amount: found ? r2(total) : null, used };
}
function isNumberish(t) {
  return t != null && (MULT[t] != null || /^\d/.test(t));
}

function normalizeSpeech(text) {
  // Nukta hatao taaki "हज़ार" aur "हजार" dono ek jaise samjhe jaayein
  let s = String(text || '').toLowerCase().normalize('NFD').replace(/़/g, '').normalize('NFC');
  s = s.replace(/[०-९]/g, (d) => String(DEV_DIGITS.indexOf(d)));
  s = s.replace(/(\d),(?=\d)/g, '$1');
  s = s.replace(/₹\s*/g, ' ').replace(/[.?!,।]+(\s|$)/g, ' ');
  s = s.replace(/(\d)\s*(rs|रु)\.?/g, '$1 ');
  s = s.replace(/(\d)(hazar|hazaar|हजार|हज़ार|sau|सौ|lakh|लाख)/g, '$1 $2');
  return s.replace(/\s+/g, ' ').trim();
}

function parseVoice(text) {
  const norm = normalizeSpeech(text);
  const tokens = norm.split(' ').filter(Boolean);
  const has = (list) => tokens.some((t) => list.includes(t));
  const { amount, used } = parseAmount(tokens);

  // Kharcha?
  let expenseCat = null;
  for (const [cat, words] of Object.entries(EXPENSE_WORDS)) if (has(words)) { expenseCat = cat; break; }
  const isExpense = has(EXPENSE_TRIGGER) || (expenseCat && !has(KW.ko) && !has(KW.ne) && !has(KW.se));
  if (isExpense) {
    return { type: 'expense', amount, category: expenseCat || 'Other', note: text, raw: text };
  }

  // Kaun sa marker (ko/ne/se) pehle aaya -> uske pehle ke shabd naam hain
  const markerIdx = tokens.findIndex((t) => KW.ko.includes(t) || KW.ne.includes(t) || KW.se.includes(t));
  const marker = markerIdx >= 0 ? tokens[markerIdx] : null;

  let kind = null;
  const gotWord = has(KW.got);
  const giveWord = has(KW.give);
  if (has(KW.gave)) kind = 'gave';
  if (gotWord) kind = 'got';
  if (marker && KW.ne.includes(marker) && giveWord) kind = 'got'; // "Ramesh ne 500 diye"
  if (marker && KW.se.includes(marker) && (gotWord || giveWord || !kind)) kind = 'got'; // "Ramesh se 500 liye"
  if (!kind && marker && KW.ko.includes(marker) && giveWord) kind = 'gave'; // "Ramesh ko 500 diye"
  if (has(KW.gave) && !(marker && (KW.ne.includes(marker) || KW.se.includes(marker)))) kind = 'gave';

  const skip = new Set([].concat(KW.gave, KW.give, KW.got, KW.ko, KW.ne, KW.se, KW.filler, EN_GIVE, EXPENSE_TRIGGER, Object.keys(MULT)));
  const isName = (t) => !skip.has(t) && !/^\d/.test(t) && !(NUM_WORDS[t] && t !== 'do');

  // English: "gave/paid 500 to X" = you gave, "X gave/paid 500" = you got
  const enIdx = tokens.findIndex((t) => EN_GIVE.includes(t));
  if (enIdx >= 0 && !gotWord) {
    if (marker === 'to') kind = 'gave';
    else if (marker === 'from') kind = 'got';
    else kind = tokens.slice(0, enIdx).some(isName) ? 'got' : 'gave';
  }

  let nameTokens;
  if (marker === 'to' || marker === 'from') {
    nameTokens = tokens.slice(markerIdx + 1).filter(isName);
    if (!nameTokens.length) nameTokens = tokens.slice(0, markerIdx);
  } else if (markerIdx > 0) nameTokens = tokens.slice(0, markerIdx);
  else nameTokens = tokens.filter((t, i) => !used.has(i));
  nameTokens = nameTokens.filter(isName);
  const name = nameTokens.join(' ').trim();

  return { type: 'khata', kind, amount, name, raw: text };
}

// Devanagari naam ko Roman mein badal kar existing party se milana ("रमेश" -> Ramesh)
const DEV_MAP = {
  'अ': 'a', 'आ': 'a', 'इ': 'i', 'ई': 'i', 'उ': 'u', 'ऊ': 'u', 'ए': 'e', 'ऐ': 'ai', 'ओ': 'o', 'औ': 'au', 'ऋ': 'ri',
  'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'n', 'च': 'ch', 'छ': 'chh', 'ज': 'j', 'झ': 'jh', 'ञ': 'n',
  'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh', 'ण': 'n', 'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n',
  'प': 'p', 'फ': 'f', 'ब': 'b', 'भ': 'bh', 'म': 'm', 'य': 'y', 'र': 'r', 'ल': 'l', 'व': 'v', 'श': 'sh', 'ष': 'sh',
  'स': 's', 'ह': 'h', 'ड़': 'd', 'ढ़': 'dh', 'क़': 'k', 'ख़': 'kh', 'ग़': 'g', 'ज़': 'z', 'फ़': 'f',
  'ा': 'a', 'ि': 'i', 'ी': 'i', 'ु': 'u', 'ू': 'u', 'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au', 'ृ': 'ri',
  'ं': 'n', 'ँ': 'n', 'ः': 'h', '्': '', '़': '',
};
function translit(s) {
  let out = '';
  for (const ch of String(s).normalize('NFC')) out += DEV_MAP[ch] != null ? DEV_MAP[ch] : ch;
  return out;
}
function nameKey(s) {
  let t = translit(s).toLowerCase().replace(/[^a-z ]/g, '');
  t = t.replace(/ph/g, 'f').replace(/w/g, 'v').replace(/z/g, 'j').replace(/sh/g, 's').replace(/ee/g, 'i').replace(/oo/g, 'u')
    .replace(/[aeiou]/g, (c, i) => (i === 0 ? c : '')).replace(/h/g, '').replace(/(.)\1+/g, '$1').replace(/\s+/g, ' ').trim();
  return t;
}
function lev(a, b) {
  const m = a.length, n = b.length;
  const d = Array.from({ length: m + 1 }, (_, i) => [i].concat(Array(n).fill(0)));
  for (let j = 1; j <= n; j++) d[0][j] = j;
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[m][n];
}
function matchParty(spoken) {
  if (!spoken) return null;
  const key = nameKey(spoken);
  const first = key.split(' ')[0];
  let best = null, bestScore = 99;
  for (const p of DB.data.parties) {
    const pk = nameKey(p.name);
    const pFirst = pk.split(' ')[0];
    let score = Math.min(lev(key, pk), lev(first, pFirst) + (key.includes(' ') && pk !== key ? 0.5 : 0));
    if (pk.startsWith(key) || key.startsWith(pk)) score = Math.min(score, 0.5);
    if (score < bestScore) { bestScore = score; best = p; }
  }
  const limit = first.length <= 3 ? 0.5 : 1;
  return bestScore <= limit ? best : null;
}
function titleCase(s) {
  const t = /[ऀ-ॿ]/.test(s) ? translit(s) : s;
  return t.replace(/\b\w/g, (c) => c.toUpperCase());
}

/* ---------- Stock: FEFO (jo pehle expire ho woh pehle bike) ---------- */
function itemQty(item) {
  return r2((item.batches || []).reduce((s, b) => s + b.qty, 0));
}
// Invoices that count (cancelled ones stay visible in the list but are left out of totals, GST and exports)
function activeSales() {
  return DB.data.sales.filter((x) => !x.cancelled);
}
function tracksStock(item) {
  return item.trackStock !== false;
}
function consumeStock(item, qty) {
  if (!tracksStock(item)) return;
  const batches = (item.batches || []).slice().sort((a, b) => (a.expiry || '9999').localeCompare(b.expiry || '9999'));
  let left = qty;
  for (const b of batches) {
    if (left <= 0) break;
    const use = Math.min(b.qty, left);
    b.qty = r2(b.qty - use);
    left = r2(left - use);
  }
  if (left > 0 && batches.length) batches[batches.length - 1].qty = r2(batches[batches.length - 1].qty - left);
  else if (left > 0) batches.push({ id: DB.id(), qty: -left, expiry: '' });
  item.batches = batches.filter((b) => b.qty !== 0);
}
function stockAlerts() {
  const days = Number(DB.data.settings.expiryAlertDays) || 30;
  const low = [], expiring = [], expired = [];
  const t = today();
  for (const it of DB.data.items) {
    if (!tracksStock(it)) continue;
    const q = itemQty(it);
    if (q <= (Number(it.minQty) || 0)) low.push({ item: it, qty: q });
    for (const b of it.batches || []) {
      if (!b.expiry || b.qty <= 0) continue;
      const left = daysBetween(t, b.expiry);
      if (left < 0) expired.push({ item: it, batch: b, left });
      else if (left <= days) expiring.push({ item: it, batch: b, left });
    }
  }
  expiring.sort((a, b) => a.left - b.left);
  return { low, expiring, expired };
}

/* ---------- Munafa / Nuksaan ---------- */
function periodKey(dateStr, gran) {
  if (gran === 'day') return dateStr;
  if (gran === 'month') return dateStr.slice(0, 7);
  const d = parseYmd(dateStr);
  const dow = (d.getDay() + 6) % 7; // Monday = 0
  d.setDate(d.getDate() - dow);
  return ymd(d);
}
function periodsFor(gran) {
  const keys = [];
  const now = new Date();
  if (gran === 'day') for (let i = 13; i >= 0; i--) keys.push(addDays(today(), -i));
  else if (gran === 'week') for (let i = 7; i >= 0; i--) keys.push(periodKey(addDays(today(), -7 * i), 'week'));
  else for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    keys.push(d.getFullYear() + '-' + pad2(d.getMonth() + 1));
  }
  return keys;
}
function periodLabel(key, gran) {
  if (gran === 'month') return MONTHS[Number(key.slice(5, 7)) - 1];
  return fmtDateShort(key);
}
function profitSeries(gran) {
  const keys = periodsFor(gran);
  const map = {};
  for (const k of keys) map[k] = { key: k, sales: 0, cogs: 0, expense: 0 };
  for (const s of activeSales()) {
    const k = periodKey(s.date, gran);
    if (!map[k]) continue;
    for (const l of s.lines) {
      map[k].sales += l.taxable;
      map[k].cogs += (l.cost || 0) * l.qty;
    }
  }
  for (const e of DB.data.expenses) {
    const k = periodKey(e.date, gran);
    if (map[k]) map[k].expense += e.amount;
  }
  return keys.map((k) => {
    const m = map[k];
    m.sales = r2(m.sales); m.cogs = r2(m.cogs); m.expense = r2(m.expense);
    m.gross = r2(m.sales - m.cogs);
    m.net = r2(m.gross - m.expense);
    m.label = periodLabel(k, gran);
    return m;
  });
}

/* ---------- GST ---------- */
function calcLine(item, qty, rate, gstRate, inclusive, interState) {
  const amount = r2(qty * rate);
  const taxable = inclusive ? r2(amount / (1 + gstRate / 100)) : amount;
  const tax = inclusive ? r2(amount - taxable) : r2((taxable * gstRate) / 100);
  const line = {
    itemId: item ? item.id : null, name: item ? item.name : '', hsn: item ? item.hsn || '' : '', unit: item ? item.unit || 'PCS' : 'PCS',
    qty, rate, gstRate, taxable, igst: 0, cgst: 0, sgst: 0, total: r2(taxable + tax),
  };
  if (interState) line.igst = tax;
  else { line.cgst = r2(tax / 2); line.sgst = r2(tax - line.cgst); }
  return line;
}
function inMonth(dateStr, ym) {
  return dateStr.slice(0, 7) === ym;
}
function gstFmtDate(s) {
  const d = parseYmd(s);
  return pad2(d.getDate()) + '-' + MONTHS[d.getMonth()] + '-' + String(d.getFullYear()).slice(2);
}
function gstr1(ym) {
  const s = DB.data.settings;
  const sales = activeSales().filter((x) => inMonth(x.date, ym));
  const b2b = [], b2cl = [], b2csMap = {}, hsnMap = {};
  for (const inv of sales) {
    const pos = inv.pos || s.stateCode;
    const byRate = {};
    for (const l of inv.lines) {
      byRate[l.gstRate] = byRate[l.gstRate] || { taxable: 0 };
      byRate[l.gstRate].taxable += l.taxable;
      const hk = (l.hsn || 'NA') + '|' + l.gstRate;
      const h = hsnMap[hk] || (hsnMap[hk] = { hsn: l.hsn || '', desc: l.name, uqc: (l.unit || 'PCS').toUpperCase(), qty: 0, value: 0, rate: l.gstRate, taxable: 0, igst: 0, cgst: 0, sgst: 0 });
      h.qty += l.qty; h.value += l.total; h.taxable += l.taxable; h.igst += l.igst; h.cgst += l.cgst; h.sgst += l.sgst;
    }
    const inter = pos && s.stateCode && pos !== s.stateCode;
    for (const [rate, v] of Object.entries(byRate)) {
      if (inv.customerGstin) {
        b2b.push([inv.customerGstin, inv.customerName || '', inv.no, gstFmtDate(inv.date), r2(inv.total), posLabel(pos), 'N', '', 'Regular B2B', '', rate, r2(v.taxable), 0]);
      } else if (inter && inv.total > 100000) {
        b2cl.push([inv.no, gstFmtDate(inv.date), r2(inv.total), posLabel(pos), '', rate, r2(v.taxable), 0, '']);
      } else {
        const k = pos + '|' + rate;
        b2csMap[k] = b2csMap[k] || ['OE', posLabel(pos), '', rate, 0, 0, ''];
        b2csMap[k][4] = r2(b2csMap[k][4] + v.taxable);
      }
    }
  }
  const hsn = Object.values(hsnMap).map((h) => [h.hsn, h.desc, h.uqc + '-' + uqcName(h.uqc), r2(h.qty), r2(h.value), h.rate, r2(h.taxable), r2(h.igst), r2(h.cgst), r2(h.sgst), 0]);
  return {
    b2b: [['GSTIN/UIN of Recipient', 'Receiver Name', 'Invoice Number', 'Invoice date', 'Invoice Value', 'Place Of Supply', 'Reverse Charge', 'Applicable % of Tax Rate', 'Invoice Type', 'E-Commerce GSTIN', 'Rate', 'Taxable Value', 'Cess Amount']].concat(b2b),
    b2cl: [['Invoice Number', 'Invoice date', 'Invoice Value', 'Place Of Supply', 'Applicable % of Tax Rate', 'Rate', 'Taxable Value', 'Cess Amount', 'E-Commerce GSTIN']].concat(b2cl),
    b2cs: [['Type', 'Place Of Supply', 'Applicable % of Tax Rate', 'Rate', 'Taxable Value', 'Cess Amount', 'E-Commerce GSTIN']].concat(Object.values(b2csMap)),
    hsn: [['HSN', 'Description', 'UQC', 'Total Quantity', 'Total Value', 'Rate', 'Taxable Value', 'Integrated Tax Amount', 'Central Tax Amount', 'State/UT Tax Amount', 'Cess Amount']].concat(hsn),
    count: sales.length,
  };
}
function uqcName(u) {
  return { PCS: 'PIECES', NOS: 'NUMBERS', KGS: 'KILOGRAMS', BOX: 'BOX', PAC: 'PACKS', MTR: 'METERS', SET: 'SETS', DOZ: 'DOZENS' }[u] || 'OTHERS';
}
function gstr3b(ym) {
  const out = { taxable: 0, igst: 0, cgst: 0, sgst: 0 };
  for (const inv of activeSales().filter((x) => inMonth(x.date, ym)))
    for (const l of inv.lines) { out.taxable += l.taxable; out.igst += l.igst; out.cgst += l.cgst; out.sgst += l.sgst; }
  const itc = { taxable: 0, igst: 0, cgst: 0, sgst: 0 };
  for (const p of DB.data.purchases.filter((x) => inMonth(x.date, ym) && x.supplierGstin))
    for (const l of p.lines) { itc.taxable += l.taxable; itc.igst += l.igst; itc.cgst += l.cgst; itc.sgst += l.sgst; }
  for (const o of [out, itc]) for (const k in o) o[k] = r2(o[k]);
  // Simple set-off (IGST credit pehle IGST, phir CGST, phir SGST). CA final check karein.
  let credit = { ...itc };
  const pay = { igst: out.igst, cgst: out.cgst, sgst: out.sgst };
  const use = (from, to) => { const u = Math.min(credit[from], pay[to]); credit[from] = r2(credit[from] - u); pay[to] = r2(pay[to] - u); };
  use('igst', 'igst'); use('igst', 'cgst'); use('igst', 'sgst'); use('cgst', 'cgst'); use('cgst', 'igst'); use('sgst', 'sgst'); use('sgst', 'igst');
  return { out, itc, pay, carry: credit };
}

/* ---------- CSV / file helpers ---------- */
function toCSV(rows) {
  return rows.map((r) => r.map((c) => {
    const v = c == null ? '' : String(c);
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }).join(',')).join('\r\n');
}
function makeFile(name, text, type) {
  return new File([text], name, { type: type || 'text/csv' });
}
function downloadFile(file) {
  if (isNative()) { nativeShareFiles([file]).catch((e) => toast(e.message, 'bad')); return; }
  const url = URL.createObjectURL(file);
  const a = document.createElement('a');
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function downloadFiles(files) {
  if (isNative()) { nativeShareFiles(files).catch((e) => toast(e.message, 'bad')); return; }
  files.forEach((f, i) => setTimeout(() => downloadFile(f), i * 400));
}
async function shareOrDownload(files, text) {
  if (isNative()) { await nativeShareFiles(files, text); return 'shared'; }
  try {
    if (navigator.canShare && navigator.canShare({ files })) {
      await navigator.share({ files, text, title: files[0].name });
      return 'shared';
    }
  } catch (e) {
    if (e.name === 'AbortError') return 'cancelled';
  }
  files.forEach((f, i) => setTimeout(() => downloadFile(f), i * 400));
  return 'downloaded';
}

/* ---------- Tally XML export ---------- */
function xmlEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]));
}
function tallyExport(from, to) {
  const s = DB.data.settings;
  const inRange = (d) => d >= from && d <= to;
  const tdate = (d) => d.replace(/-/g, '');
  const ledgers = new Map();
  const led = (name, parent) => { if (!ledgers.has(name)) ledgers.set(name, parent); return name; };
  led('Cash', 'Cash-in-Hand'); led('Bank', 'Bank Accounts'); led('Sales', 'Sales Accounts'); led('Purchase', 'Purchase Accounts');
  const vouchers = [];
  const entry = (name, amt) => // amt > 0 = Debit
    '<ALLLEDGERENTRIES.LIST><LEDGERNAME>' + xmlEsc(name) + '</LEDGERNAME><ISDEEMEDPOSITIVE>' + (amt > 0 ? 'Yes' : 'No') +
    '</ISDEEMEDPOSITIVE><AMOUNT>' + (-amt).toFixed(2) + '</AMOUNT></ALLLEDGERENTRIES.LIST>';
  const voucher = (type, date, no, party, narration, lines) => {
    vouchers.push('<TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER VCHTYPE="' + type + '" ACTION="Create" OBJVIEW="Accounting Voucher View"><DATE>' + tdate(date) +
      '</DATE><VOUCHERTYPENAME>' + type + '</VOUCHERTYPENAME>' + (no ? '<VOUCHERNUMBER>' + xmlEsc(no) + '</VOUCHERNUMBER>' : '') +
      (party ? '<PARTYLEDGERNAME>' + xmlEsc(party) + '</PARTYLEDGERNAME>' : '') + '<NARRATION>' + xmlEsc(narration) + '</NARRATION><PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>' +
      lines.filter((l) => Math.abs(l[1]) > 0.004).map((l) => entry(l[0], l[1])).join('') + '</VOUCHER></TALLYMESSAGE>');
  };
  const partyLedger = (pid, fallbackName, supplier) => {
    const p = pid && DB.get('parties', pid);
    const name = p ? p.name : fallbackName;
    return led(name, (p ? p.type === 'supplier' : supplier) ? 'Sundry Creditors' : 'Sundry Debtors');
  };
  const payLedger = (m) => (m === 'upi' || m === 'bank' ? 'Bank' : 'Cash');

  for (const inv of activeSales().filter((x) => inRange(x.date))) {
    const party = inv.payMode === 'udhaar' ? partyLedger(inv.partyId, inv.customerName || 'Customer', false) : payLedger(inv.payMode);
    const t = inv.lines.reduce((a, l) => ({ taxable: a.taxable + l.taxable, igst: a.igst + l.igst, cgst: a.cgst + l.cgst, sgst: a.sgst + l.sgst }), { taxable: 0, igst: 0, cgst: 0, sgst: 0 });
    voucher('Sales', inv.date, inv.no, party, 'Invoice ' + inv.no, [
      [party, inv.total], ['Sales', -r2(t.taxable)],
      [led('Output IGST', 'Duties & Taxes'), -r2(t.igst)], [led('Output CGST', 'Duties & Taxes'), -r2(t.cgst)], [led('Output SGST', 'Duties & Taxes'), -r2(t.sgst)],
      ['Round Off', r2(-(inv.total - t.taxable - t.igst - t.cgst - t.sgst))],
    ].map((l) => (l[0] === 'Round Off' ? [led('Round Off', 'Indirect Expenses'), l[1]] : l)));
  }
  for (const p of DB.data.purchases.filter((x) => inRange(x.date))) {
    const party = p.payMode === 'udhaar' ? partyLedger(p.partyId, p.supplierName || 'Supplier', true) : payLedger(p.payMode);
    const t = p.lines.reduce((a, l) => ({ taxable: a.taxable + l.taxable, igst: a.igst + l.igst, cgst: a.cgst + l.cgst, sgst: a.sgst + l.sgst }), { taxable: 0, igst: 0, cgst: 0, sgst: 0 });
    voucher('Purchase', p.date, p.invNo || '', party, 'Purchase ' + (p.invNo || ''), [
      ['Purchase', r2(t.taxable)], [led('Input IGST', 'Duties & Taxes'), r2(t.igst)], [led('Input CGST', 'Duties & Taxes'), r2(t.cgst)], [led('Input SGST', 'Duties & Taxes'), r2(t.sgst)],
      [led('Round Off', 'Indirect Expenses'), r2(p.total - t.taxable - t.igst - t.cgst - t.sgst)],
      [party, -p.total],
    ]);
  }
  for (const t of DB.data.txns.filter((x) => inRange(x.date) && !x.refType)) {
    const p = DB.get('parties', t.partyId);
    if (!p) continue;
    const party = partyLedger(p.id, p.name);
    const cashL = payLedger(t.mode);
    if (p.type === 'customer') {
      if (t.kind === 'got') voucher('Receipt', t.date, '', party, t.note || 'Khata payment', [[cashL, t.amount], [party, -t.amount]]);
      else voucher('Sales', t.date, '', party, t.note || 'Khata udhaar', [[party, t.amount], [led('Sales - Khata', 'Sales Accounts'), -t.amount]]);
    } else {
      if (t.kind === 'gave') voucher('Payment', t.date, '', party, t.note || 'Supplier payment', [[party, t.amount], [cashL, -t.amount]]);
      else voucher('Purchase', t.date, '', party, t.note || 'Khata maal', [[led('Purchase - Khata', 'Purchase Accounts'), t.amount], [party, -t.amount]]);
    }
  }
  for (const e of DB.data.expenses.filter((x) => inRange(x.date))) {
    const el = led(e.category, 'Indirect Expenses');
    voucher('Payment', e.date, '', payLedger(e.mode), e.note || e.category, [[el, e.amount], [payLedger(e.mode), -e.amount]]);
  }
  const ledgerXml = [...ledgers.entries()].map(([name, parent]) =>
    '<TALLYMESSAGE xmlns:UDF="TallyUDF"><LEDGER NAME="' + xmlEsc(name) + '" ACTION="Create"><NAME.LIST><NAME>' + xmlEsc(name) + '</NAME></NAME.LIST><PARENT>' + xmlEsc(parent) + '</PARENT></LEDGER></TALLYMESSAGE>').join('\n');
  const head = '<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>All Masters</REPORTNAME>' +
    '<STATICVARIABLES><SVCURRENTCOMPANY>' + xmlEsc(s.shopName) + '</SVCURRENTCOMPANY></STATICVARIABLES></REQUESTDESC><REQUESTDATA>\n';
  const tail = '\n</REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
  return {
    masters: head + ledgerXml + tail,
    vouchers: head.replace('All Masters', 'Vouchers') + vouchers.join('\n') + tail,
    count: vouchers.length,
  };
}

/* ---------- Zoho Books CSV export (Import wizard ke columns) ---------- */
function zohoExport(from, to) {
  const s = DB.data.settings;
  const inRange = (d) => d >= from && d <= to;
  const contacts = [['Display Name', 'Contact Name', 'Contact Type', 'Mobile Phone', 'GST Treatment', 'GST Identification Number (GSTIN)', 'Place of Contact']];
  for (const p of DB.data.parties)
    contacts.push([p.name, p.name, p.type === 'supplier' ? 'vendor' : 'customer', p.phone || '', p.gstin ? 'business_gst' : 'consumer', p.gstin || '', p.state || s.stateCode ? STATES[p.state || s.stateCode] || '' : '']);
  const invoices = [['Invoice Date', 'Invoice Number', 'Invoice Status', 'Customer Name', 'GST Treatment', 'GST Identification Number (GSTIN)', 'Place of Supply', 'Is Inclusive Tax', 'Item Name', 'HSN/SAC', 'Quantity', 'Item Price', 'Item Tax %', 'Usage unit', 'Payment Terms']];
  for (const inv of activeSales().filter((x) => inRange(x.date))) {
    for (const l of inv.lines)
      invoices.push([inv.date, inv.no, inv.payMode === 'udhaar' ? 'Sent' : 'Paid', inv.customerName || 'Walk-in Customer', inv.customerGstin ? 'business_gst' : 'consumer',
        inv.customerGstin || '', STATES[inv.pos || s.stateCode] || '', inv.inclusive ? 'true' : 'false', l.name, l.hsn, l.qty, l.rate, l.gstRate, l.unit, 'Due on Receipt']);
  }
  const bills = [['Bill Date', 'Bill Number', 'Vendor Name', 'GST Identification Number (GSTIN)', 'Source of Supply', 'Is Inclusive Tax', 'Item Name', 'HSN/SAC', 'Quantity', 'Rate', 'Tax Percentage']];
  for (const p of DB.data.purchases.filter((x) => inRange(x.date)))
    for (const l of p.lines)
      bills.push([p.date, p.invNo || p.id, p.supplierName || 'Supplier', p.supplierGstin || '', STATES[p.pos || s.stateCode] || '', 'false', l.name, l.hsn, l.qty, l.rate, l.gstRate]);
  const payments = [['Date', 'Customer Name', 'Amount', 'Payment Mode', 'Description']];
  for (const t of DB.data.txns.filter((x) => inRange(x.date) && x.kind === 'got' && !x.refType)) {
    const p = DB.get('parties', t.partyId);
    if (p && p.type === 'customer') payments.push([t.date, p.name, t.amount, t.mode === 'upi' ? 'Bank Transfer' : 'Cash', t.note || 'Khata payment']);
  }
  const expenses = [['Expense Date', 'Expense Account', 'Amount', 'Paid Through', 'Description']];
  for (const e of DB.data.expenses.filter((x) => inRange(x.date)))
    expenses.push([e.date, e.category, e.amount, e.mode === 'upi' ? 'Bank' : 'Petty Cash', e.note || '']);
  return { contacts, invoices, bills, payments, expenses };
}

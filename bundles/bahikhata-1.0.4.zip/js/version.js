// Updated automatically by publish-update.bat. Do not edit by hand.
const APP_VERSION = '1.0.4';
const UPDATE_URL = 'https://vikramsinghbisht.github.io/bahikhata-updates/';
// Web OAuth client ID from Google Cloud, shared by every user (see README). Empty = Drive backup off.
const DEFAULT_GOOGLE_CLIENT_ID = '';
// Google Apps Script web app that stores every company's daily backup in the owner's Drive (see release/cloud-backup). Empty = off.
const CLOUD_BACKUP_URL = '';

// Sample data for the chosen business type, so a new user can see every feature working.
// Phone numbers 90000000xx are fake. "Remove demo" in Settings clears it and keeps the business profile.

function seedDemo() {
  let seed = 20260926;
  const rand = () => { seed |= 0; seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const pick = (a) => a[Math.floor(rand() * a.length)];
  const ago = (n) => addDays(today(), -n);
  const at = (date, hour) => date + 'T' + pad2(hour) + ':' + pad2(Math.floor(rand() * 50)) + ':00';

  const settings = DB.data.settings;
  DB.data = DB.empty();
  DB.data.settings = settings;
  const s = settings;
  if (!s.stateCode) s.stateCode = '07';
  const home = s.stateCode;
  const other = home === '09' ? '07' : '09';
  DB.data.demo = true;
  DB.data.welcomed = true;
  DB.data.onboarded = true;
  const preset = currentPreset();

  const P = (name, phone, type, extra) => {
    const p = Object.assign({ id: DB.id(), name, phone, type, verify: 'auto', gstin: '', state: '', createdAt: new Date().toISOString() }, extra || {});
    DB.data.parties.push(p);
    return p;
  };
  const T = (p, kind, daysAgo, amount, hour, note, mode) => {
    const date = ago(daysAgo);
    DB.data.txns.push({ id: DB.id(), partyId: p.id, kind, amount, date, note: note || '', mode: mode || 'cash', refType: null, refId: null, verifyStatus: 'na', createdAt: at(date, hour || 12) });
  };
  const back = (dow) => (new Date().getDay() - dow + 7) % 7;

  const ramesh = P('Ramesh Kumar', '9000000001', 'customer');
  const sunita = P('Sunita Sharma', '9000000002', 'customer');
  const vikas = P('Vikas Traders', '9000000003', 'customer', { gstin: home + 'AAAPV1234C1Z2' });
  const pooja = P('Pooja Enterprises', '9000000004', 'customer', { gstin: other + 'AABCP5678D1Z8', state: other });
  const anil = P('Anil Verma', '9000000005', 'customer');
  const neha = P('Neha Gupta', '9000000006', 'customer');
  const sup1 = P('City Wholesale Suppliers', '9000000011', 'supplier', { gstin: home + 'AAFCD4321E1Z9', verify: 'never' });
  const sup2 = P('Metro Distributors', '9000000012', 'supplier', { gstin: home + 'AAGCS8765F1Z3', verify: 'never' });

  // Ramesh pays on time (about a week), usually Monday evening
  const rm = back(1);
  [[rm + 49, rm + 42], [rm + 35, rm + 28], [rm + 21, rm + 14], [rm + 11, rm + 7]].forEach(([g, p], i) => {
    const amt = [800, 1250, 600, 950][i];
    T(ramesh, 'gave', g, amt, 11, 'Goods on credit');
    T(ramesh, 'got', p, amt, 18, 'Payment', i % 2 ? 'upi' : 'cash');
  });
  T(ramesh, 'gave', 2, 700, 12, 'Goods on credit');
  // Sunita pays on time by UPI
  [[30, 24], [16, 10]].forEach(([g, p], i) => {
    const amt = [1500, 900][i];
    T(sunita, 'gave', g, amt, 13, 'Goods on credit');
    T(sunita, 'got', p, amt, 10, 'UPI', 'upi');
  });
  // Vikas is a late payer, pays on Saturdays
  const vk = back(6);
  T(vikas, 'gave', vk + 126, 4200, 11, 'Bulk order');
  T(vikas, 'got', vk + 84, 4200, 17, 'Cheque', 'upi');
  T(vikas, 'gave', vk + 91, 3000, 12, 'Bulk order');
  T(vikas, 'got', vk + 49, 3000, 16, 'Cash');
  T(vikas, 'gave', 48, 6200, 12, 'Bulk order');
  T(vikas, 'got', 20, 1500, 17, 'Part payment');
  // Pooja is a little late (~3 weeks)
  T(pooja, 'gave', 70, 5600, 12, 'Order');
  T(pooja, 'got', 47, 5600, 15, 'NEFT', 'upi');
  T(pooja, 'gave', 40, 3800, 12, 'Order');
  T(pooja, 'got', 17, 3800, 15, 'NEFT', 'upi');
  T(pooja, 'gave', 19, 4500, 12, 'Order');
  T(anil, 'gave', 4, 450, 19, 'Goods on credit');
  T(neha, 'gave', 25, 1100, 12, 'Goods on credit');
  T(neha, 'got', 21, 1100, 18, 'Cash');
  T(sup1, 'gave', 30, 8000, 11, 'Payment', 'upi');

  const items = preset.items.map(([name, unit, hsn, gstRate, costPrice, salePrice, minQty, qty, exp]) => {
    const batches = [];
    if (exp != null && qty > 3) {
      // Two batches so expiry alerts have something to show
      const first = Math.max(1, Math.round(qty / 3));
      batches.push({ id: DB.id(), qty: first, expiry: addDays(today(), exp) });
      batches.push({ id: DB.id(), qty: qty - first, expiry: addDays(today(), exp + 60) });
    } else batches.push({ id: DB.id(), qty, expiry: exp == null ? '' : addDays(today(), exp) });
    const it = { id: DB.id(), name, unit, hsn, gstRate, costPrice, salePrice, minQty, createdAt: new Date().toISOString(), batches };
    DB.data.items.push(it);
    return it;
  });
  if (preset.expiry && items.length) items[items.length - 1].batches.push({ id: DB.id(), qty: 2, expiry: addDays(today(), -3) });

  // Bills over the last 75 days (more units per bill for low-priced goods like groceries)
  const priced = items.filter((x) => x.salePrice);
  const avgSale = priced.reduce((t, x) => t + x.salePrice, 0) / Math.max(1, priced.length);
  const qtyMul = avgSale < 150 ? 5 : avgSale < 300 ? 2 : 1;
  const walkins = ['', '', '', 'Rahul', 'Priya', 'Aman', 'Kavita', 'Deepak'];
  let no = 1;
  for (let d = 75; d >= 0; d--) {
    const weekend = [0, 6].includes(parseYmd(ago(d)).getDay());
    const n = 3 + Math.floor(rand() * (weekend ? 7 : 4));
    for (let k = 0; k < n; k++) {
      const lines = [];
      const count = 1 + Math.floor(rand() * 3);
      for (let j = 0; j < count; j++) {
        const it = pick(items);
        if (!it.salePrice) continue;
        const qty = (1 + Math.floor(rand() * 3)) * qtyMul;
        const l = calcLine(it, qty, it.salePrice, it.gstRate, true, false);
        l.cost = it.costPrice;
        lines.push(l);
      }
      if (!lines.length) continue;
      const total = lines.reduce((a, l) => a + l.total, 0);
      const date = ago(d);
      DB.data.sales.push({ id: DB.id(), no: s.invoicePrefix + no++, date, partyId: null, customerName: pick(walkins), customerGstin: '', pos: home, inclusive: true, lines, total: Math.round(total), roundOff: r2(Math.round(total) - total), payMode: rand() < 0.55 ? 'upi' : 'cash', createdAt: at(date, 10 + Math.floor(rand() * 10)) });
    }
  }
  const b2b = (p, d, it, qty, pos) => {
    const l = calcLine(it, qty, it.salePrice, it.gstRate, true, pos !== home);
    l.cost = it.costPrice;
    const date = ago(d);
    DB.data.sales.push({ id: DB.id(), no: s.invoicePrefix + no++, date, partyId: p.id, customerName: p.name, customerGstin: p.gstin, pos, inclusive: true, lines: [l], total: Math.round(l.total), roundOff: r2(Math.round(l.total) - l.total), payMode: 'upi', createdAt: at(date, 12) });
  };
  const sellable = items.filter((it) => it.salePrice);
  b2b(vikas, 12, sellable[0], 20, home);
  b2b(pooja, 8, sellable[Math.min(2, sellable.length - 1)], 15, other);
  DB.data.seq.invoice = no;

  // Purchases with supplier GSTIN, so GST reports show input credit
  const buy = (sup, d, rows, payMode, invNo) => {
    const lines = rows.filter(([it]) => it.costPrice).map(([it, qty]) => calcLine(it, qty, it.costPrice, it.gstRate, false, false));
    if (!lines.length) return;
    const total = Math.round(lines.reduce((a, l) => a + l.total, 0));
    const date = ago(d);
    const p = { id: DB.id(), date, partyId: sup.id, supplierName: sup.name, supplierGstin: sup.gstin, invNo, pos: home, lines, total, payMode, createdAt: at(date, 11) };
    DB.data.purchases.push(p);
    if (payMode === 'udhaar') DB.data.txns.push({ id: DB.id(), partyId: sup.id, kind: 'got', amount: total, date, note: 'Purchase ' + invNo, mode: 'cash', refType: 'purchase', refId: p.id, verifyStatus: 'na', createdAt: at(date, 11) });
  };
  const it = (i) => items[i % items.length];
  buy(sup1, 40, [[it(0), 30], [it(1), 40], [it(2), 30]], 'udhaar', 'CWS/1182');
  buy(sup1, 12, [[it(3), 20], [it(4), 20]], 'udhaar', 'CWS/1247');
  buy(sup2, 9, [[it(5), 10], [it(6), 20]], 'upi', 'MD/5521');
  buy(sup2, 35, [[it(7), 25]], 'cash', 'MD/5390');

  // Expenses in this business type's categories
  const cats = preset.expenses;
  const E = (d, category, amount, note, mode) => {
    const date = ago(d);
    DB.data.expenses.push({ id: DB.id(), date, category, amount, mode: mode || 'cash', note: note || '', createdAt: at(date, 14) });
  };
  for (let m = 0; m < 3; m++) {
    const first = new Date();
    first.setMonth(first.getMonth() - m, 1);
    const d = daysBetween(ymd(first), today());
    E(d, 'Rent', 12000, 'Shop rent', 'upi');
    E(Math.max(0, d - 6), 'Electricity', 1800 + Math.round(rand() * 900), 'Electricity bill', 'upi');
    E(Math.max(0, d - 1), 'Staff salary', 8000, 'Helper salary', 'cash');
    E(Math.max(0, d - 10), 'Phone/Internet', 499, 'WiFi', 'upi');
  }
  for (let d = 75; d >= 0; d -= 3) E(d, 'Tea & snacks', 50 + Math.round(rand() * 60));
  for (let d = 74; d >= 0; d -= 7) E(d, 'Transport', 150 + Math.round(rand() * 350), pick(['Stock pickup', 'Auto', 'Delivery']));
  const special = cats.filter((c) => !BASE_EXPENSES.includes(c) && c !== 'Other');
  special.forEach((c, i) => E(8 + i * 11, c, 400 + Math.round(rand() * 900)));

  DB.save();
}

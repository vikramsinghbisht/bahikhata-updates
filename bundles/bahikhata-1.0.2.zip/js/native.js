// Android app (Capacitor) support: in-app updates, native voice, file sharing, Google sign-in, back button.
// In a normal browser none of this runs and the web versions are used instead.

function isNative() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}
function nativePlugin(name) {
  return window.Capacitor && window.Capacitor.Plugins ? window.Capacitor.Plugins[name] : null;
}
function cmpVer(a, b) {
  const pa = String(a || '0').split('.').map(Number), pb = String(b || '0').split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d > 0 ? 1 : -1;
  }
  return 0;
}

/* ---------- Files: save to the phone and open the share sheet ---------- */
async function nativeShareFiles(files, text) {
  const FS = nativePlugin('Filesystem'), SH = nativePlugin('Share');
  const uris = [];
  for (const f of files) {
    const r = await FS.writeFile({ path: f.name, data: await f.text(), directory: 'CACHE', encoding: 'utf8' });
    uris.push(r.uri);
  }
  try {
    await SH.share({ title: files[0].name, text: text || '', files: uris, dialogTitle: 'Save or send' });
  } catch (e) {
    if (!/cancel/i.test(e.message || '')) throw e;
  }
}

/* ---------- Voice: Android's own speech recogniser ---------- */
async function nativeListen(lang) {
  const SR = nativePlugin('SpeechRecognition');
  if (!SR) throw new Error('Voice is not available in this app build.');
  const perm = await SR.requestPermissions();
  if (perm.speechRecognition !== 'granted') throw new Error('Microphone permission was denied. Allow it in Android Settings › Apps › BahiKhata+.');
  const { available } = await SR.available();
  if (!available) throw new Error('Speech recognition is not available on this phone. Install or update the Google app.');
  const r = await SR.start({ language: lang, maxResults: 4, partialResults: false, popup: false });
  return (r && r.matches) || [];
}
function nativeStopListening() {
  const SR = nativePlugin('SpeechRecognition');
  if (SR) SR.stop().catch(() => {});
}

/* ---------- In-app updates ---------- */
const Updater = {
  info: null,
  progress: null,
  error: null,
  lastCheck: 0,
  nativeVersion: null,

  baseUrl() {
    return ((DB.data && DB.data.settings.updateUrl) || UPDATE_URL).replace(/\/?$/, '/');
  },

  async check(manual) {
    if (!isNative()) {
      if (manual) toast('Updates apply to the Android app. In a browser, just reload the page.');
      return;
    }
    if (!navigator.onLine) {
      if (manual) toast('You are offline. Connect to the internet to check for updates.', 'warn');
      return;
    }
    this.lastCheck = Date.now();
    try {
      const base = this.baseUrl();
      const res = await fetch(base + 'version.json?t=' + Date.now(), { cache: 'no-store' });
      if (!res.ok) throw new Error('server returned ' + res.status);
      const info = await res.json();
      if (cmpVer(info.version, APP_VERSION) > 0) {
        info.zipUrl = new URL(info.url, base).href;
        info.apkUrl = info.apk ? new URL(info.apk, base).href : null;
        info.needsApk = !!(info.minNative && this.nativeVersion && cmpVer(this.nativeVersion, info.minNative) < 0);
        this.info = info;
        this.error = null;
        this.progress = null;
        if (!UI.stack.some((fn) => fn === updateSheet)) openSheet(updateSheet);
      } else if (manual) {
        toast('You have the latest version (v' + APP_VERSION + ').', 'good');
      }
    } catch (e) {
      if (manual) toast('Could not check for updates: ' + e.message, 'bad');
    }
  },

  async install() {
    const U = nativePlugin('CapacitorUpdater');
    if (!U || !this.info) return;
    this.progress = 0;
    this.error = null;
    refreshSheet();
    let handle = null;
    try {
      handle = await U.addListener('download', (s) => {
        this.progress = Math.round(s.percent || 0);
        const bar = document.getElementById('upd-bar');
        const pct = document.getElementById('upd-pct');
        if (bar) bar.style.width = this.progress + '%';
        if (pct) pct.textContent = this.progress + '%';
      });
      DB.save();
      if (!this.info.checksum) throw new Error('This update has no checksum. Publish it again with the latest release tool.');
      const bundle = await U.download({ url: this.info.zipUrl, version: this.info.version, checksum: this.info.checksum });
      this.progress = 100;
      await U.set({ id: bundle.id }); // the app restarts on the new version here
    } catch (e) {
      this.progress = null;
      this.error = (e.message || String(e)) + (e.data && e.data.message ? ' (' + e.data.message + ')' : '');
      refreshSheet();
    } finally {
      if (handle && handle.remove) handle.remove();
    }
  },
};

function updateSheet() {
  const i = Updater.info;
  if (!i) return { title: 'Update', body: '<div class="empty">No update found.</div>' };
  const notes = (Array.isArray(i.notes) ? i.notes : String(i.notes || '').split('\n')).filter(Boolean);
  const busy = Updater.progress != null;
  let action;
  if (i.needsApk) {
    action = '<div class="banner">This update needs the new app file (APK). Download and install it once; your data stays.</div>' +
      (i.apkUrl ? '<a class="btn primary block" href="' + esc(i.apkUrl) + '" target="_blank" rel="noopener">Download new APK</a>' : '');
  } else if (busy) {
    action = '<div class="stack"><div class="row"><span class="grow">Downloading update…</span><b id="upd-pct" class="num">' + Updater.progress + '%</b></div>' +
      '<div class="bar-row" style="grid-template-columns:1fr"><span class="track"><span class="fill" id="upd-bar" style="display:block;width:' + Updater.progress + '%"></span></span></div>' +
      '<span class="small muted">The app will restart by itself when the update is ready. Your data is safe.</span></div>';
  } else {
    action = (Updater.error ? '<div class="banner">Update failed: ' + esc(Updater.error) + '</div>' : '') +
      '<div class="btns"><button class="btn primary" data-act="upd-install">' + (Updater.error ? 'Try again' : 'Update now') + '</button>' +
      (i.mandatory ? '' : '<button class="btn" data-act="close-sheet">Later</button>') + '</div>';
  }
  return {
    title: 'Update available',
    body:
      '<div class="card hero-bal"><span class="label">New version</span><div class="big">v' + esc(i.version) + '</div>' +
      '<span class="small muted">You have v' + esc(APP_VERSION) + (i.date ? ' · released ' + esc(i.date) : '') + '</span></div>' +
      (notes.length ? '<div class="card stack"><span class="label">What\'s new</span>' + notes.map((n) => '<span>• ' + esc(n) + '</span>').join('') + '</div>' : '') +
      action,
  };
}

/* ---------- Google Drive sign-in inside the app ---------- */
// Google blocks its web sign-in pop-up inside apps, so the Android app uses the phone's Google account instead.
function patchDriveForNative() {
  const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';
  Drive.loadGis = () => Promise.resolve();
  Drive.getToken = async function (interactive) {
    if (this.token && Date.now() < this.tokenExp - 60000) return this.token;
    const cid = googleClientId();
    if (!cid) throw new Error('Add your Google Client ID in Settings.');
    const GA = nativePlugin('GoogleAuth');
    if (!GA) throw new Error('Google sign-in is not available in this app build.');
    await GA.initialize({ clientId: cid, scopes: DRIVE_SCOPE, grantOfflineAccess: false });
    let auth = null;
    try {
      auth = await GA.refresh();
    } catch (e) {
      if (!interactive) throw new Error('Sign in to Google once from More › Backup › Back up now.');
      const user = await GA.signIn();
      auth = user && user.authentication;
    }
    if (!auth || !auth.accessToken) throw new Error('Google did not return access. Try Back up now again.');
    this.token = auth.accessToken;
    this.tokenExp = Date.now() + 50 * 60 * 1000;
    return this.token;
  };
}

/* ---------- Start-up ---------- */
async function initNative() {
  if (!isNative()) return;
  document.documentElement.classList.add('native');
  const U = nativePlugin('CapacitorUpdater');
  if (U) {
    // Tells the updater this version started fine; otherwise it rolls back to the previous one.
    U.notifyAppReady().catch(() => {});
    U.current().then((c) => { Updater.nativeVersion = c && c.native; }).catch(() => {});
  }
  patchDriveForNative();

  const App = nativePlugin('App');
  if (App) {
    App.addListener('backButton', () => {
      if (isLocked()) { App.exitApp(); return; }
      if (isLocked()) { App.exitApp(); return; }
      if (UI.voice && UI.voice.listening) nativeStopListening();
      if (UI.stack.length) closeSheet();
      else if (UI.tab !== 'khata') { UI.tab = 'khata'; render(); }
      else App.exitApp();
    });
    App.addListener('resume', () => {
      if (Date.now() - Updater.lastCheck > 30 * 60 * 1000) Updater.check(false);
      Drive.autoCheck();
    });
  }
  setTimeout(() => Updater.check(false), 2500);
}

// Updated automatically by publish-update.bat. Do not edit by hand.
const APP_VERSION = '1.0.1';
const UPDATE_URL = 'https://vikramsinghbisht.github.io/bahikhata-updates/';
// Web OAuth client ID from Google Cloud, shared by every user (see README). Empty = Drive backup off.
const DEFAULT_GOOGLE_CLIENT_ID = '';
